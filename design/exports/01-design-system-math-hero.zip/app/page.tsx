import { BrandHeader } from "@/components/showcase/brand-header"
import { Section } from "@/components/showcase/section"
import { MascotShowcase } from "@/components/showcase/mascot-showcase"
import { ColorPalette } from "@/components/showcase/color-palette"
import { TypographyScale } from "@/components/showcase/typography-scale"
import { ButtonShowcase } from "@/components/showcase/button-showcase"
import { CardShowcase } from "@/components/showcase/card-showcase"
import { ProgressShowcase } from "@/components/showcase/progress-showcase"
import { GamificationIcons } from "@/components/showcase/gamification-icons"
import { BadgeShowcase } from "@/components/showcase/badge-showcase"
import { TrophyShowcase } from "@/components/showcase/trophy-showcase"
import { LevelShowcase } from "@/components/showcase/level-showcase"
import { AchievementShowcase } from "@/components/showcase/achievement-showcase"
import { StatusShowcase } from "@/components/showcase/status-showcase"
import { Globe } from "lucide-react"

const nav = [
  ["mascote", "Mascote"],
  ["cores", "Cores"],
  ["tipografia", "Tipografia"],
  ["botoes", "Botões"],
  ["cards", "Cards"],
  ["progresso", "Progresso"],
  ["icones", "Ícones"],
  ["medalhas", "Medalhas"],
  ["trofeus", "Troféus"],
  ["niveis", "Níveis"],
  ["conquistas", "Conquistas"],
  ["status", "Status"],
]

export default function Home() {
  return (
    <div className="min-h-screen font-sans">
      <nav className="sticky top-0 z-20 border-b border-border bg-background/80 backdrop-blur">
        <div className="mx-auto flex max-w-5xl items-center gap-1 overflow-x-auto px-4 py-3">
          {nav.map(([id, label]) => (
            <a
              key={id}
              href={`#${id}`}
              className="whitespace-nowrap rounded-full px-3 py-1.5 text-sm font-bold text-muted-foreground transition-colors hover:bg-primary-100 hover:text-primary-700"
            >
              {label}
            </a>
          ))}
        </div>
      </nav>

      <main className="mx-auto flex max-w-5xl flex-col gap-16 px-4 py-8 sm:px-6">
        <BrandHeader />

        <Section
          id="mascote"
          eyebrow="Mascote"
          title="Conheça o Milo"
          description="Um jovem mago explorador, amigável e neutro de gênero, que acompanha as crianças em cada etapa — comemorando vitórias, explicando erros e incentivando a sequência diária."
        >
          <MascotShowcase />
        </Section>

        <Section
          id="cores"
          eyebrow="Cores"
          title="Sistema de cores"
          description="Escalas completas de 50 a 900 para cada papel semântico, mais o dourado especial para troféus e conquistas."
        >
          <ColorPalette />
        </Section>

        <Section
          id="tipografia"
          eyebrow="Tipografia"
          title="Escala tipográfica"
          description="Fontes do sistema, com pesos fortes e tamanhos generosos, fáceis de ler para crianças."
        >
          <TypographyScale />
        </Section>

        <Section
          id="botoes"
          eyebrow="Componentes"
          title="Botões"
          description="Variações primária, secundária, sucesso, contorno, desativado e carregando."
        >
          <ButtonShowcase />
        </Section>

        <Section
          id="cards"
          eyebrow="Componentes"
          title="Cards"
          description="Lição, desafio, missão diária, conquista, amigo e estado bloqueado."
        >
          <CardShowcase />
        </Section>

        <Section
          id="progresso"
          eyebrow="Componentes"
          title="Progresso"
          description="Barra de XP, progresso diário, semanal e de nível."
        >
          <ProgressShowcase />
        </Section>

        <Section
          id="icones"
          eyebrow="Gamificação"
          title="Ícones de gamificação"
          description="XP, moedas, gemas, sequência e troféu."
        >
          <GamificationIcons />
        </Section>

        <Section
          id="medalhas"
          eyebrow="Recompensas"
          title="Medalhas"
          description="Quatro níveis de raridade: bronze, prata, ouro e diamante."
        >
          <BadgeShowcase />
        </Section>

        <Section
          id="trofeus"
          eyebrow="Recompensas"
          title="Troféus"
          description="Diário, semanal, mensal e o grande troféu de campeão."
        >
          <TrophyShowcase />
        </Section>

        <Section
          id="niveis"
          eyebrow="Progressão"
          title="Sistema de níveis"
          description="A representação visual fica cada vez mais épica conforme a criança evolui do Nível 1 ao 50."
        >
          <LevelShowcase />
        </Section>

        <Section
          id="conquistas"
          eyebrow="Recompensas"
          title="Conquistas"
          description="Distintivos colecionáveis que celebram cada marco da jornada."
        >
          <AchievementShowcase />
        </Section>

        <Section
          id="status"
          eyebrow="Feedback"
          title="Estados de status"
          description="Sucesso, erro, vazio e carregando — sempre com o tom positivo do Milo."
        >
          <StatusShowcase />
        </Section>

        <footer className="rounded-4xl bg-primary-600 px-6 py-10 text-center text-white">
          <p className="flex items-center justify-center gap-2 text-sm font-bold text-primary-100">
            <Globe className="h-4 w-4" />
            Pronto para múltiplos idiomas
          </p>
          <p className="mx-auto mt-3 max-w-xl text-pretty leading-relaxed text-primary-100">
            Todos os componentes foram desenhados com áreas de texto flexíveis para suportar traduções mais longas em
            inglês, português, espanhol e francês.
          </p>
          <div className="mt-4 flex flex-wrap justify-center gap-2">
            {["English", "Português", "Español", "Français"].map((lang) => (
              <span key={lang} className="rounded-full bg-white/15 px-4 py-1.5 text-sm font-semibold backdrop-blur">
                {lang}
              </span>
            ))}
          </div>
        </footer>
      </main>
    </div>
  )
}
