import { Zap, Coins, Gem, Flame, Trophy } from "lucide-react"

const icons = [
  { Icon: Zap, label: "XP", bg: "bg-primary-100", fg: "text-primary-600", fill: "fill-primary-500" },
  { Icon: Coins, label: "Moedas", bg: "bg-gold-100", fg: "text-gold-600", fill: "fill-gold-400" },
  { Icon: Gem, label: "Gemas", bg: "bg-[#ccfbf1]", fg: "text-teal-600", fill: "fill-teal-400" },
  { Icon: Flame, label: "Sequência", bg: "bg-secondary-100", fg: "text-secondary-600", fill: "fill-secondary-500" },
  { Icon: Trophy, label: "Troféu", bg: "bg-warning-100", fg: "text-warning-600", fill: "fill-warning-400" },
]

export function GamificationIcons() {
  return (
    <div className="flex flex-wrap gap-4">
      {icons.map(({ Icon, label, bg, fg, fill }) => (
        <div
          key={label}
          className="flex flex-1 basis-32 flex-col items-center gap-2 rounded-3xl border border-border bg-card p-5 shadow-sm"
        >
          <span className={`flex h-16 w-16 items-center justify-center rounded-2xl ${bg} ${fg}`}>
            <Icon className={`h-8 w-8 ${fill}`} />
          </span>
          <span className="text-sm font-extrabold text-foreground">{label}</span>
        </div>
      ))}
    </div>
  )
}
