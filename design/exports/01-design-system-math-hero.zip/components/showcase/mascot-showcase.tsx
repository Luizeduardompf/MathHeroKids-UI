import Image from "next/image"

const states = [
  { src: "/milo/milo-happy.png", label: "Feliz", desc: "Estado padrão" },
  { src: "/milo/milo-excited.png", label: "Empolgado", desc: "Nova conquista" },
  { src: "/milo/milo-celebrating.png", label: "Comemorando", desc: "Lição concluída" },
  { src: "/milo/milo-thinking.png", label: "Pensando", desc: "Explicando" },
  { src: "/milo/milo-encouraging.png", label: "Incentivando", desc: "Motivação" },
  { src: "/milo/milo-sad.png", label: "Triste", desc: "Suave e amigável" },
  { src: "/milo/milo-trophy.png", label: "Troféu", desc: "Premiação" },
]

export function MascotShowcase() {
  return (
    <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
      {states.map((s) => (
        <div
          key={s.label}
          className="flex flex-col items-center gap-2 rounded-3xl border border-border bg-card p-5 text-center shadow-sm transition-transform hover:-translate-y-1"
        >
          <div className="flex h-32 w-full items-center justify-center rounded-2xl bg-primary-50">
            <Image
              src={s.src || "/placeholder.svg"}
              alt={`Milo no estado ${s.label}`}
              width={110}
              height={110}
              className="h-28 w-28 object-contain"
            />
          </div>
          <p className="text-base font-extrabold text-foreground">{s.label}</p>
          <p className="text-xs text-muted-foreground">{s.desc}</p>
        </div>
      ))}
      <div className="flex flex-col justify-center gap-2 rounded-3xl border-2 border-dashed border-primary-200 bg-primary-50/60 p-5 text-center">
        <p className="text-2xl font-black text-primary-700">Milo</p>
        <p className="text-sm font-medium leading-relaxed text-primary-700/80">
          Mago explorador, neutro de gênero, sempre positivo e não violento.
        </p>
      </div>
    </div>
  )
}
