import Image from "next/image"
import { Sparkles, Star } from "lucide-react"

export function BrandHeader() {
  return (
    <header className="relative overflow-hidden rounded-4xl bg-primary-600 px-6 py-12 text-white shadow-xl sm:px-12 sm:py-16">
      <div className="pointer-events-none absolute inset-0 opacity-20">
        <Star className="absolute left-8 top-10 h-10 w-10 fill-white" />
        <Star className="absolute right-16 top-20 h-6 w-6 fill-white" />
        <Sparkles className="absolute bottom-10 left-1/3 h-8 w-8" />
        <Star className="absolute bottom-16 right-10 h-12 w-12 fill-white" />
      </div>

      <div className="relative flex flex-col items-center gap-8 sm:flex-row sm:justify-between">
        <div className="flex flex-col items-center gap-4 text-center sm:items-start sm:text-left">
          <span className="inline-flex items-center gap-2 rounded-full bg-white/15 px-4 py-1.5 text-sm font-bold backdrop-blur">
            <Sparkles className="h-4 w-4" />
            Design System
          </span>
          <h1 className="text-balance text-5xl font-black leading-none tracking-tight sm:text-6xl">
            Math Hero Kids
          </h1>
          <p className="max-w-md text-pretty text-lg leading-relaxed text-primary-100">
            Identidade visual e biblioteca de componentes de um app de matemática gamificado, divertido e seguro para
            crianças de 6 a 12 anos.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-2 sm:justify-start">
            {["Divertido", "Seguro", "Colorido", "Motivador"].map((tag) => (
              <span key={tag} className="rounded-full bg-white/15 px-3 py-1 text-sm font-semibold backdrop-blur">
                {tag}
              </span>
            ))}
          </div>
        </div>

        <div className="relative shrink-0">
          <div className="absolute inset-0 -z-10 rounded-full bg-white/20 blur-2xl" />
          <Image
            src="/milo/milo-mascot-hero.png"
            alt="Milo, o mascote mago explorador do Math Hero Kids, acenando"
            width={260}
            height={260}
            className="animate-float drop-shadow-2xl"
            priority
          />
        </div>
      </div>
    </header>
  )
}
