const scale = [
  { name: "Hero", cls: "text-5xl sm:text-6xl font-black tracking-tight", spec: "60 / 800" },
  { name: "H1", cls: "text-4xl font-extrabold tracking-tight", spec: "36 / 800" },
  { name: "H2", cls: "text-3xl font-extrabold tracking-tight", spec: "30 / 800" },
  { name: "H3", cls: "text-2xl font-bold", spec: "24 / 700" },
  { name: "H4", cls: "text-xl font-bold", spec: "20 / 700" },
  { name: "Body Large", cls: "text-lg leading-relaxed", spec: "18 / 400" },
  { name: "Body", cls: "text-base leading-relaxed", spec: "16 / 400" },
  { name: "Caption", cls: "text-sm text-muted-foreground", spec: "14 / 400" },
  { name: "Small", cls: "text-xs text-muted-foreground", spec: "12 / 400" },
]

export function TypographyScale() {
  return (
    <div className="overflow-hidden rounded-3xl border border-border bg-card shadow-sm">
      {scale.map((t, i) => (
        <div
          key={t.name}
          className={`flex flex-col gap-1 px-5 py-4 sm:flex-row sm:items-baseline sm:gap-6 ${
            i !== 0 ? "border-t border-border" : ""
          }`}
        >
          <div className="flex w-32 shrink-0 items-baseline justify-between gap-2 sm:flex-col sm:justify-start">
            <span className="text-sm font-bold text-primary-600">{t.name}</span>
            <span className="font-mono text-xs text-muted-foreground">{t.spec}</span>
          </div>
          <p className={`text-pretty text-foreground ${t.cls}`}>Milo adora matemática</p>
        </div>
      ))}
    </div>
  )
}
