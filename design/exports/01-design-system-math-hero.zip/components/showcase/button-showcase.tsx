import { Loader2, Play, Check } from "lucide-react"

export function ButtonShowcase() {
  return (
    <div className="rounded-3xl border border-border bg-card p-6 shadow-sm">
      <div className="flex flex-wrap items-center gap-4">
        <button className="inline-flex items-center gap-2 rounded-2xl bg-primary-600 px-7 py-3.5 text-lg font-extrabold text-white shadow-md shadow-primary-600/30 transition-transform hover:-translate-y-0.5 active:translate-y-0.5">
          <Play className="h-5 w-5 fill-white" />
          Primário
        </button>

        <button className="inline-flex items-center gap-2 rounded-2xl bg-secondary-500 px-7 py-3.5 text-lg font-extrabold text-white shadow-md shadow-secondary-500/30 transition-transform hover:-translate-y-0.5 active:translate-y-0.5">
          Secundário
        </button>

        <button className="inline-flex items-center gap-2 rounded-2xl bg-success-500 px-7 py-3.5 text-lg font-extrabold text-white shadow-md shadow-success-500/30 transition-transform hover:-translate-y-0.5 active:translate-y-0.5">
          <Check className="h-5 w-5" />
          Sucesso
        </button>

        <button className="inline-flex items-center gap-2 rounded-2xl border-2 border-primary-200 bg-primary-50 px-7 py-3.5 text-lg font-extrabold text-primary-700 transition-colors hover:bg-primary-100">
          Contorno
        </button>

        <button
          disabled
          className="inline-flex cursor-not-allowed items-center gap-2 rounded-2xl bg-muted px-7 py-3.5 text-lg font-extrabold text-muted-foreground opacity-70"
        >
          Desativado
        </button>

        <button
          disabled
          className="inline-flex cursor-wait items-center gap-2 rounded-2xl bg-primary-600 px-7 py-3.5 text-lg font-extrabold text-white opacity-90"
        >
          <Loader2 className="h-5 w-5 animate-spin" />
          Carregando
        </button>
      </div>
      <p className="mt-4 text-sm text-muted-foreground">
        Alvos de toque grandes (mínimo 56&nbsp;px de altura) e cantos arredondados para mãos pequenas.
      </p>
    </div>
  )
}
