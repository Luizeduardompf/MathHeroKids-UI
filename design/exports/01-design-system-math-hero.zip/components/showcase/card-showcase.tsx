import Image from "next/image"
import { BookOpen, Swords, Target, Award, Lock, Star, Flame, Clock, ChevronRight } from "lucide-react"

export function CardShowcase() {
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {/* Lesson card */}
      <article className="flex flex-col gap-3 rounded-3xl border border-border bg-card p-5 shadow-sm transition-transform hover:-translate-y-1">
        <div className="flex items-center justify-between">
          <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-primary-100 text-primary-600">
            <BookOpen className="h-6 w-6" />
          </span>
          <span className="rounded-full bg-success-100 px-3 py-1 text-xs font-bold text-success-700">Lição 1</span>
        </div>
        <div>
          <h3 className="text-xl font-extrabold text-foreground">Somando até 10</h3>
          <p className="text-sm text-muted-foreground">Aprenda a somar números pequenos com o Milo.</p>
        </div>
        <div className="mt-1 flex items-center gap-1 text-gold-500">
          {[1, 2, 3].map((i) => (
            <Star key={i} className={`h-5 w-5 ${i <= 2 ? "fill-gold-400" : "fill-muted text-muted"}`} />
          ))}
        </div>
        <button className="mt-1 inline-flex items-center justify-center gap-1 rounded-2xl bg-primary-600 py-2.5 text-base font-extrabold text-white">
          Continuar <ChevronRight className="h-4 w-4" />
        </button>
      </article>

      {/* Challenge card */}
      <article className="flex flex-col gap-3 rounded-3xl border border-secondary-200 bg-secondary-50 p-5 shadow-sm transition-transform hover:-translate-y-1">
        <div className="flex items-center justify-between">
          <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-secondary-500 text-white">
            <Swords className="h-6 w-6" />
          </span>
          <span className="rounded-full bg-secondary-500 px-3 py-1 text-xs font-bold text-white">Desafio</span>
        </div>
        <div>
          <h3 className="text-xl font-extrabold text-secondary-800">Batalha da Tabuada</h3>
          <p className="text-sm text-secondary-700/80">Resolva 10 questões antes que o tempo acabe!</p>
        </div>
        <div className="flex items-center gap-2 text-secondary-700">
          <Clock className="h-4 w-4" />
          <span className="text-sm font-bold">02:00 min</span>
        </div>
        <button className="mt-1 rounded-2xl bg-secondary-500 py-2.5 text-base font-extrabold text-white">
          Aceitar desafio
        </button>
      </article>

      {/* Daily mission card */}
      <article className="flex flex-col gap-3 rounded-3xl border border-border bg-card p-5 shadow-sm transition-transform hover:-translate-y-1">
        <div className="flex items-center justify-between">
          <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-warning-100 text-warning-600">
            <Target className="h-6 w-6" />
          </span>
          <span className="flex items-center gap-1 rounded-full bg-warning-100 px-3 py-1 text-xs font-bold text-warning-700">
            <Flame className="h-3.5 w-3.5" /> Diária
          </span>
        </div>
        <div>
          <h3 className="text-xl font-extrabold text-foreground">Missão do dia</h3>
          <p className="text-sm text-muted-foreground">Complete 3 lições para ganhar bônus.</p>
        </div>
        <div className="h-3 w-full overflow-hidden rounded-full bg-muted">
          <div className="h-full w-2/3 rounded-full bg-warning-400" />
        </div>
        <p className="text-sm font-bold text-warning-600">2 de 3 concluídas</p>
      </article>

      {/* Achievement card */}
      <article className="flex flex-col items-center gap-2 rounded-3xl border border-gold-300 bg-gold-100 p-5 text-center shadow-sm transition-transform hover:-translate-y-1">
        <span className="flex h-16 w-16 items-center justify-center rounded-full bg-gold-400 text-white shadow-md shadow-gold-400/40">
          <Award className="h-8 w-8" />
        </span>
        <h3 className="text-xl font-extrabold text-gold-600">Herói da Matemática</h3>
        <p className="text-sm text-gold-600/80">Você desbloqueou uma nova conquista épica!</p>
        <span className="mt-1 rounded-full bg-gold-400 px-4 py-1 text-sm font-bold text-white">+500 XP</span>
      </article>

      {/* Friend card */}
      <article className="flex items-center gap-3 rounded-3xl border border-border bg-card p-5 shadow-sm transition-transform hover:-translate-y-1">
        <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-primary-50">
          <Image src="/milo/milo-happy.png" alt="Avatar do amigo" width={48} height={48} className="object-contain" />
        </div>
        <div className="min-w-0 flex-1">
          <h3 className="truncate text-lg font-extrabold text-foreground">Ana, a Exploradora</h3>
          <p className="flex items-center gap-1 text-sm text-muted-foreground">
            <Flame className="h-4 w-4 text-secondary-500" /> 12 dias de sequência
          </p>
        </div>
        <button className="rounded-2xl bg-primary-100 px-4 py-2 text-sm font-extrabold text-primary-700">Seguir</button>
      </article>

      {/* Locked lesson card */}
      <article className="flex flex-col items-center justify-center gap-2 rounded-3xl border-2 border-dashed border-border bg-muted/40 p-5 text-center">
        <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-muted text-muted-foreground">
          <Lock className="h-6 w-6" />
        </span>
        <h3 className="text-lg font-extrabold text-muted-foreground">Lição bloqueada</h3>
        <p className="text-sm text-muted-foreground">Conclua a lição anterior para liberar.</p>
      </article>
    </div>
  )
}
