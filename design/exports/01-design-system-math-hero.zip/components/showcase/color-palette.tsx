const scales = [
  {
    name: "Primary · Azul",
    token: "primary",
    shades: [
      ["50", "#eff6ff"], ["100", "#dbeafe"], ["200", "#bfdbfe"], ["300", "#93c5fd"], ["400", "#60a5fa"],
      ["500", "#3b82f6"], ["600", "#2563eb"], ["700", "#1d4ed8"], ["800", "#1e40af"], ["900", "#1e3a8a"],
    ],
  },
  {
    name: "Secondary · Laranja",
    token: "secondary",
    shades: [
      ["50", "#fff7ed"], ["100", "#ffedd5"], ["200", "#fed7aa"], ["300", "#fdba74"], ["400", "#fb923c"],
      ["500", "#f97316"], ["600", "#ea580c"], ["700", "#c2410c"], ["800", "#9a3412"], ["900", "#7c2d12"],
    ],
  },
  {
    name: "Success · Verde",
    token: "success",
    shades: [
      ["50", "#f0fdf4"], ["100", "#dcfce7"], ["200", "#bbf7d0"], ["300", "#86efac"], ["400", "#4ade80"],
      ["500", "#22c55e"], ["600", "#16a34a"], ["700", "#15803d"], ["800", "#166534"], ["900", "#14532d"],
    ],
  },
  {
    name: "Warning · Amarelo",
    token: "warning",
    shades: [
      ["50", "#fefce8"], ["100", "#fef9c3"], ["200", "#fef08a"], ["300", "#fde047"], ["400", "#facc15"],
      ["500", "#eab308"], ["600", "#ca8a04"], ["700", "#a16207"], ["800", "#854d0e"], ["900", "#713f12"],
    ],
  },
  {
    name: "Error · Vermelho",
    token: "error",
    shades: [
      ["50", "#fef2f2"], ["100", "#fee2e2"], ["200", "#fecaca"], ["300", "#fca5a5"], ["400", "#f87171"],
      ["500", "#ef4444"], ["600", "#dc2626"], ["700", "#b91c1c"], ["800", "#991b1b"], ["900", "#7f1d1d"],
    ],
  },
]

export function ColorPalette() {
  return (
    <div className="flex flex-col gap-6">
      {scales.map((scale) => (
        <div key={scale.token} className="rounded-3xl border border-border bg-card p-5 shadow-sm">
          <p className="mb-3 text-sm font-extrabold uppercase tracking-wide text-foreground">{scale.name}</p>
          <div className="grid grid-cols-5 gap-2 sm:grid-cols-10">
            {scale.shades.map(([shade, hex]) => (
              <div key={shade} className="flex flex-col gap-1">
                <div
                  className="h-14 w-full rounded-xl border border-black/5 shadow-inner"
                  style={{ backgroundColor: hex }}
                />
                <span className="text-center text-[11px] font-bold text-foreground">{shade}</span>
                <span className="text-center text-[9px] uppercase text-muted-foreground">{hex}</span>
              </div>
            ))}
          </div>
        </div>
      ))}

      <div className="rounded-3xl border border-gold-300 bg-gold-100 p-5 shadow-sm">
        <p className="mb-3 text-sm font-extrabold uppercase tracking-wide text-gold-600">Special · Gold (troféus)</p>
        <div className="grid grid-cols-5 gap-2">
          {[
            ["100", "#fef3c7"], ["300", "#fcd34d"], ["400", "#fbbf24"], ["500", "#f59e0b"], ["600", "#d97706"],
          ].map(([shade, hex]) => (
            <div key={shade} className="flex flex-col gap-1">
              <div className="h-14 w-full rounded-xl border border-black/5 shadow-inner" style={{ backgroundColor: hex }} />
              <span className="text-center text-[11px] font-bold text-gold-600">{shade}</span>
              <span className="text-center text-[9px] uppercase text-gold-600/70">{hex}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
