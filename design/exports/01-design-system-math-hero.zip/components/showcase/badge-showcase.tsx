import { Shield } from "lucide-react"

const badges = [
  { name: "Bronze", ring: "border-[#cd7f32]", bg: "bg-[#f5e0cc]", fg: "text-[#a05a23]", chip: "bg-[#cd7f32]" },
  { name: "Prata", ring: "border-[#b8c2cc]", bg: "bg-[#eef1f4]", fg: "text-[#6b7785]", chip: "bg-[#b8c2cc]" },
  { name: "Ouro", ring: "border-gold-400", bg: "bg-gold-100", fg: "text-gold-600", chip: "bg-gold-400" },
  { name: "Diamante", ring: "border-[#5eead4]", bg: "bg-[#d1fae9]", fg: "text-[#0f766e]", chip: "bg-[#5eead4]" },
]

export function BadgeShowcase() {
  return (
    <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
      {badges.map((b) => (
        <div
          key={b.name}
          className={`flex flex-col items-center gap-3 rounded-3xl border-2 ${b.ring} ${b.bg} p-5 text-center shadow-sm`}
        >
          <span className={`flex h-16 w-16 items-center justify-center rounded-full ${b.chip} text-white shadow-md`}>
            <Shield className="h-8 w-8 fill-white/30" />
          </span>
          <span className={`text-base font-extrabold ${b.fg}`}>{b.name}</span>
        </div>
      ))}
    </div>
  )
}
