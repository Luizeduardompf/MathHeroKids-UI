import { Zap, Calendar, CalendarDays, TrendingUp } from "lucide-react"

function Bar({ value, colorClass }: { value: number; colorClass: string }) {
  return (
    <div className="h-4 w-full overflow-hidden rounded-full bg-muted">
      <div className={`h-full rounded-full ${colorClass}`} style={{ width: `${value}%` }} />
    </div>
  )
}

export function ProgressShowcase() {
  return (
    <div className="grid gap-4 sm:grid-cols-2">
      {/* XP bar */}
      <div className="flex flex-col gap-3 rounded-3xl border border-border bg-card p-5 shadow-sm">
        <div className="flex items-center justify-between">
          <span className="flex items-center gap-2 text-base font-extrabold text-foreground">
            <span className="flex h-8 w-8 items-center justify-center rounded-full bg-primary-100 text-primary-600">
              <Zap className="h-4 w-4 fill-primary-500 text-primary-500" />
            </span>
            Barra de XP
          </span>
          <span className="text-sm font-bold text-primary-600">1.250 / 2.000 XP</span>
        </div>
        <Bar value={62} colorClass="bg-primary-500" />
        <p className="text-xs text-muted-foreground">Faltam 750 XP para o próximo nível.</p>
      </div>

      {/* Daily progress */}
      <div className="flex flex-col gap-3 rounded-3xl border border-border bg-card p-5 shadow-sm">
        <div className="flex items-center justify-between">
          <span className="flex items-center gap-2 text-base font-extrabold text-foreground">
            <span className="flex h-8 w-8 items-center justify-center rounded-full bg-secondary-100 text-secondary-600">
              <Calendar className="h-4 w-4" />
            </span>
            Progresso diário
          </span>
          <span className="text-sm font-bold text-secondary-600">80%</span>
        </div>
        <Bar value={80} colorClass="bg-secondary-500" />
        <p className="text-xs text-muted-foreground">4 de 5 lições do dia concluídas.</p>
      </div>

      {/* Weekly progress */}
      <div className="flex flex-col gap-3 rounded-3xl border border-border bg-card p-5 shadow-sm">
        <div className="flex items-center justify-between">
          <span className="flex items-center gap-2 text-base font-extrabold text-foreground">
            <span className="flex h-8 w-8 items-center justify-center rounded-full bg-success-100 text-success-600">
              <CalendarDays className="h-4 w-4" />
            </span>
            Progresso semanal
          </span>
          <span className="text-sm font-bold text-success-600">5 / 7 dias</span>
        </div>
        <div className="flex gap-1.5">
          {["S", "T", "Q", "Q", "S", "S", "D"].map((d, i) => (
            <div key={i} className="flex flex-1 flex-col items-center gap-1">
              <div className={`h-9 w-full rounded-xl ${i < 5 ? "bg-success-400" : "bg-muted"}`} />
              <span className="text-[10px] font-bold text-muted-foreground">{d}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Level progress */}
      <div className="flex flex-col gap-3 rounded-3xl border border-border bg-card p-5 shadow-sm">
        <div className="flex items-center justify-between">
          <span className="flex items-center gap-2 text-base font-extrabold text-foreground">
            <span className="flex h-8 w-8 items-center justify-center rounded-full bg-warning-100 text-warning-600">
              <TrendingUp className="h-4 w-4" />
            </span>
            Progresso de nível
          </span>
          <span className="text-sm font-bold text-warning-600">Nível 7</span>
        </div>
        <Bar value={45} colorClass="bg-warning-400" />
        <p className="text-xs text-muted-foreground">45% do caminho até o Nível 8.</p>
      </div>
    </div>
  )
}
