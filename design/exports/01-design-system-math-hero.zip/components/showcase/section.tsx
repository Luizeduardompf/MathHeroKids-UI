import type { ReactNode } from "react"

interface SectionProps {
  id: string
  eyebrow: string
  title: string
  description?: string
  children: ReactNode
}

export function Section({ id, eyebrow, title, description, children }: SectionProps) {
  return (
    <section id={id} className="scroll-mt-24">
      <div className="mb-6 flex flex-col gap-2">
        <span className="inline-flex w-fit items-center rounded-full bg-primary-100 px-3 py-1 text-xs font-bold uppercase tracking-wide text-primary-700">
          {eyebrow}
        </span>
        <h2 className="text-pretty text-3xl font-extrabold tracking-tight text-foreground sm:text-4xl">{title}</h2>
        {description ? <p className="max-w-2xl text-pretty leading-relaxed text-muted-foreground">{description}</p> : null}
      </div>
      {children}
    </section>
  )
}
