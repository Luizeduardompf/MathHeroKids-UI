import { Trophy, Crown } from "lucide-react"

const trophies = [
  { name: "Diário", desc: "Todo dia conta", bg: "bg-primary-50", chip: "bg-primary-500", fg: "text-primary-700" },
  { name: "Semanal", desc: "7 dias seguidos", bg: "bg-secondary-50", chip: "bg-secondary-500", fg: "text-secondary-700" },
  { name: "Mensal", desc: "Mês perfeito", bg: "bg-success-50", chip: "bg-success-500", fg: "text-success-700" },
  { name: "Campeão", desc: "O maior de todos", bg: "bg-gold-100", chip: "bg-gold-400", fg: "text-gold-600", champion: true },
]

export function TrophyShowcase() {
  return (
    <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
      {trophies.map((t) => (
        <div
          key={t.name}
          className={`relative flex flex-col items-center gap-2 rounded-3xl border border-border ${t.bg} p-6 text-center shadow-sm`}
        >
          {t.champion ? (
            <Crown className="absolute right-4 top-4 h-6 w-6 fill-gold-400 text-gold-500" />
          ) : null}
          <span
            className={`flex h-20 w-20 items-center justify-center rounded-full ${t.chip} text-white shadow-lg ${
              t.champion ? "animate-pop" : ""
            }`}
          >
            <Trophy className="h-10 w-10 fill-white/30" />
          </span>
          <span className={`text-lg font-extrabold ${t.fg}`}>{t.name}</span>
          <span className="text-xs text-muted-foreground">{t.desc}</span>
        </div>
      ))}
    </div>
  )
}
