import { LogIn, Sparkles, Flame, CalendarCheck, Star, X, Zap, CalendarHeart, CalendarRange } from "lucide-react"
import type { LucideIcon } from "lucide-react"

const achievements: {
  name: string
  desc: string
  Icon: LucideIcon
  bg: string
  fg: string
  unlocked: boolean
}[] = [
  { name: "Primeiro Acesso", desc: "Bem-vindo ao app!", Icon: LogIn, bg: "bg-primary-100", fg: "text-primary-600", unlocked: true },
  { name: "Dia Perfeito", desc: "100% em um dia", Icon: Sparkles, bg: "bg-success-100", fg: "text-success-600", unlocked: true },
  { name: "Sequência de 7 dias", desc: "Uma semana seguida", Icon: Flame, bg: "bg-secondary-100", fg: "text-secondary-600", unlocked: true },
  { name: "Sequência de 30 dias", desc: "Um mês imparável", Icon: CalendarCheck, bg: "bg-warning-100", fg: "text-warning-600", unlocked: false },
  { name: "Herói da Matemática", desc: "Conquista épica", Icon: Star, bg: "bg-gold-100", fg: "text-gold-600", unlocked: true },
  { name: "Mestre da Multiplicação", desc: "Tabuada completa", Icon: X, bg: "bg-primary-100", fg: "text-primary-600", unlocked: false },
  { name: "Campeão da Velocidade", desc: "Respostas relâmpago", Icon: Zap, bg: "bg-secondary-100", fg: "text-secondary-600", unlocked: true },
  { name: "Semana Perfeita", desc: "7 dias 100%", Icon: CalendarHeart, bg: "bg-success-100", fg: "text-success-600", unlocked: false },
  { name: "Mês Perfeito", desc: "30 dias 100%", Icon: CalendarRange, bg: "bg-gold-100", fg: "text-gold-600", unlocked: false },
]

export function AchievementShowcase() {
  return (
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
      {achievements.map((a) => {
        const { Icon } = a
        return (
          <div
            key={a.name}
            className={`flex flex-col items-center gap-2 rounded-3xl border border-border p-4 text-center shadow-sm ${
              a.unlocked ? "bg-card" : "bg-muted/50"
            }`}
          >
            <span
              className={`flex h-14 w-14 items-center justify-center rounded-full ${
                a.unlocked ? `${a.bg} ${a.fg}` : "bg-muted text-muted-foreground"
              }`}
            >
              <Icon className="h-7 w-7" />
            </span>
            <span className={`text-sm font-extrabold ${a.unlocked ? "text-foreground" : "text-muted-foreground"}`}>
              {a.name}
            </span>
            <span className="text-xs text-muted-foreground">{a.unlocked ? a.desc : "Bloqueada"}</span>
          </div>
        )
      })}
    </div>
  )
}
