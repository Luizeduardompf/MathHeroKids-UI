const levels = [
  { lvl: 1, title: "Iniciante", ring: "border-success-300", bg: "bg-success-50", chip: "bg-success-400", fg: "text-success-700", size: "h-16 w-16", text: "text-2xl" },
  { lvl: 5, title: "Aprendiz", ring: "border-primary-300", bg: "bg-primary-50", chip: "bg-primary-500", fg: "text-primary-700", size: "h-20 w-20", text: "text-3xl" },
  { lvl: 10, title: "Explorador", ring: "border-secondary-300", bg: "bg-secondary-50", chip: "bg-secondary-500", fg: "text-secondary-700", size: "h-24 w-24", text: "text-4xl" },
  { lvl: 25, title: "Mestre", ring: "border-warning-300", bg: "bg-warning-50", chip: "bg-warning-500", fg: "text-warning-700", size: "h-28 w-28", text: "text-5xl" },
  { lvl: 50, title: "Herói Lendário", ring: "border-gold-400", bg: "bg-gold-100", chip: "bg-gold-400", fg: "text-gold-600", size: "h-32 w-32", text: "text-6xl", epic: true },
]

export function LevelShowcase() {
  return (
    <div className="flex flex-wrap items-end justify-center gap-6 rounded-3xl border border-border bg-card p-6 shadow-sm sm:justify-between">
      {levels.map((l) => (
        <div key={l.lvl} className="flex flex-col items-center gap-2 text-center">
          <div
            className={`flex items-center justify-center rounded-full border-4 ${l.ring} ${l.bg} ${l.size} ${
              l.epic ? "shadow-xl shadow-gold-400/40 animate-pop" : "shadow-md"
            }`}
          >
            <span
              className={`flex h-3/4 w-3/4 items-center justify-center rounded-full ${l.chip} font-black text-white ${l.text}`}
            >
              {l.lvl}
            </span>
          </div>
          <span className={`text-sm font-extrabold ${l.fg}`}>Nível {l.lvl}</span>
          <span className="text-xs text-muted-foreground">{l.title}</span>
        </div>
      ))}
    </div>
  )
}
