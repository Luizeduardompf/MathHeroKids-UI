import Image from "next/image"
import { Loader2, Inbox } from "lucide-react"

export function StatusShowcase() {
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      {/* Success */}
      <div className="flex flex-col items-center gap-2 rounded-3xl border border-success-200 bg-success-50 p-5 text-center shadow-sm">
        <Image src="/milo/milo-celebrating.png" alt="Milo comemorando" width={90} height={90} className="object-contain" />
        <h3 className="text-lg font-extrabold text-success-700">Muito bem!</h3>
        <p className="text-sm text-success-700/80">Você acertou tudo. Continue assim!</p>
      </div>

      {/* Error */}
      <div className="flex flex-col items-center gap-2 rounded-3xl border border-error-200 bg-error-50 p-5 text-center shadow-sm">
        <Image src="/milo/milo-sad.png" alt="Milo triste, de forma amigável" width={90} height={90} className="object-contain" />
        <h3 className="text-lg font-extrabold text-error-700">Quase lá!</h3>
        <p className="text-sm text-error-700/80">Tente de novo, você consegue!</p>
      </div>

      {/* Empty */}
      <div className="flex flex-col items-center gap-2 rounded-3xl border border-border bg-card p-5 text-center shadow-sm">
        <span className="flex h-[90px] w-[90px] items-center justify-center rounded-full bg-muted text-muted-foreground">
          <Inbox className="h-10 w-10" />
        </span>
        <h3 className="text-lg font-extrabold text-foreground">Nada por aqui</h3>
        <p className="text-sm text-muted-foreground">Comece uma lição para ver seu progresso.</p>
      </div>

      {/* Loading */}
      <div className="flex flex-col items-center gap-2 rounded-3xl border border-border bg-card p-5 text-center shadow-sm">
        <span className="flex h-[90px] w-[90px] items-center justify-center rounded-full bg-primary-50 text-primary-500">
          <Loader2 className="h-10 w-10 animate-spin" />
        </span>
        <h3 className="text-lg font-extrabold text-foreground">Carregando…</h3>
        <p className="text-sm text-muted-foreground">Preparando a próxima aventura.</p>
      </div>
    </div>
  )
}
