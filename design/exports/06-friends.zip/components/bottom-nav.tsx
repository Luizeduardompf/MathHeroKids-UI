"use client"

import { Home, Calendar, Swords, Users } from "lucide-react"
import { cn } from "@/lib/utils"

const ITEMS = [
  { id: "home", label: "Início", icon: Home },
  { id: "calendar", label: "Calendário", icon: Calendar },
  { id: "challenge", label: "Desafio", icon: Swords },
  { id: "friends", label: "Amigos", icon: Users },
] as const

export function BottomNav({ active = "friends" }: { active?: string }) {
  return (
    <nav className="absolute inset-x-0 bottom-0 z-20 flex items-center justify-around border-t border-border bg-card px-2 pb-5 pt-2">
      {ITEMS.map((item) => {
        const isActive = item.id === active
        const Icon = item.icon
        return (
          <button
            key={item.id}
            className="flex flex-1 flex-col items-center gap-1 py-1"
            aria-current={isActive ? "page" : undefined}
          >
            <span
              className={cn(
                "flex size-10 items-center justify-center rounded-2xl transition",
                isActive ? "bg-brand-blue text-white shadow-sm" : "text-muted-foreground",
              )}
            >
              <Icon className="size-5" />
            </span>
            <span
              className={cn(
                "font-heading text-[11px] font-semibold",
                isActive ? "text-brand-blue" : "text-muted-foreground",
              )}
            >
              {item.label}
            </span>
          </button>
        )
      })}
    </nav>
  )
}
