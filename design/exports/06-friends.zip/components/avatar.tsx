import { initials, TONE_BG, type Friend } from "@/lib/friends-data"
import { cn } from "@/lib/utils"

export function Avatar({
  name,
  tone,
  size = "md",
  online,
  className,
}: {
  name: string
  tone: Friend["tone"]
  size?: "sm" | "md" | "lg" | "xl"
  online?: boolean
  className?: string
}) {
  const sizes = {
    sm: "size-9 text-xs",
    md: "size-12 text-sm",
    lg: "size-16 text-lg",
    xl: "size-24 text-2xl",
  }
  const dot = {
    sm: "size-2.5 ring-2",
    md: "size-3 ring-2",
    lg: "size-4 ring-[3px]",
    xl: "size-5 ring-4",
  }
  return (
    <div className={cn("relative shrink-0", className)}>
      <div
        className={cn(
          "flex items-center justify-center rounded-full font-heading font-bold text-white shadow-sm",
          TONE_BG[tone],
          sizes[size],
        )}
        aria-hidden="true"
      >
        {initials(name)}
      </div>
      {online && (
        <span
          className={cn(
            "absolute bottom-0 right-0 rounded-full bg-brand-green ring-card",
            dot[size],
          )}
          aria-label="online"
        />
      )}
    </div>
  )
}
