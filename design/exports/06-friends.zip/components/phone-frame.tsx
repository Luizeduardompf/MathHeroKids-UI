import type { ReactNode } from "react"

/** Reusable phone mockup frame, matching the Milo Special Moments demo style. */
export function PhoneFrame({ children, label }: { children: ReactNode; label?: string }) {
  return (
    <div className="w-full max-w-[360px]">
      {label && (
        <p className="mb-3 text-center font-heading text-sm font-semibold text-muted-foreground">
          {label}
        </p>
      )}
      <div className="relative aspect-[9/19] w-full overflow-hidden rounded-[2.5rem] border-8 border-foreground/90 bg-foreground shadow-2xl">
        <div className="absolute inset-0 overflow-hidden rounded-[2rem] bg-background">
          {children}
        </div>
      </div>
    </div>
  )
}
