"use client"

import { useState } from "react"
import { ArrowLeft, Crown, Zap, Flame } from "lucide-react"
import { Avatar } from "@/components/avatar"
import { WEEKLY_RANKING, MONTHLY_RANKING, type RankingEntry } from "@/lib/friends-data"
import { cn } from "@/lib/utils"

const PODIUM_STYLE = [
  { ring: "ring-brand-gold", badge: "bg-brand-gold", height: "h-28", size: "lg" as const },
  { ring: "ring-[oklch(0.78_0.02_255)]", badge: "bg-[oklch(0.7_0.02_255)]", height: "h-20", size: "md" as const },
  { ring: "ring-brand-orange", badge: "bg-brand-orange", height: "h-16", size: "md" as const },
]

function Podium({ entries }: { entries: RankingEntry[] }) {
  // top 3, ordered for podium display: 2nd, 1st, 3rd
  const top3 = entries.slice(0, 3)
  const order = [top3[1], top3[0], top3[2]].filter(Boolean)
  const placeOf = (e: RankingEntry) => top3.indexOf(e)

  return (
    <div className="flex items-end justify-center gap-3 px-2">
      {order.map((e) => {
        const place = placeOf(e)
        const s = PODIUM_STYLE[place]
        return (
          <div key={e.id} className="flex flex-1 flex-col items-center">
            <div className="relative">
              {place === 0 && (
                <Crown className="absolute -top-6 left-1/2 size-6 -translate-x-1/2 fill-brand-gold text-brand-gold" />
              )}
              <div className={cn("rounded-full ring-4", s.ring)}>
                <Avatar name={e.name} tone={e.tone} size={s.size} />
              </div>
              <span
                className={cn(
                  "absolute -bottom-1 left-1/2 flex size-6 -translate-x-1/2 items-center justify-center rounded-full font-heading text-xs font-bold text-white ring-2 ring-card",
                  s.badge,
                )}
              >
                {place + 1}
              </span>
            </div>
            <p className="mt-3 max-w-full truncate text-center font-heading text-xs font-bold text-foreground">
              {e.isMe ? "Você" : e.name.split(" ")[0]}
            </p>
            <p className="flex items-center gap-1 text-[11px] font-bold text-muted-foreground">
              <Zap className="size-3 fill-brand-gold text-brand-gold" />
              {e.periodXp.toLocaleString("pt-BR")}
            </p>
            <div className={cn("mt-2 w-full rounded-t-xl bg-brand-blue/15", s.height)} />
          </div>
        )
      })}
    </div>
  )
}

export function FriendsRankingScreen() {
  const [period, setPeriod] = useState<"weekly" | "monthly">("weekly")
  const entries = period === "weekly" ? WEEKLY_RANKING : MONTHLY_RANKING
  const rest = entries.slice(3)

  return (
    <div className="flex h-full w-full flex-col bg-background">
      {/* Header */}
      <header className="bg-gradient-to-b from-[oklch(0.58_0.2_262)] to-[oklch(0.45_0.21_263)] px-5 pb-6 pt-10 text-white">
        <div className="flex items-center gap-3">
          <button className="flex size-10 items-center justify-center rounded-2xl bg-white/15 transition active:scale-95" aria-label="Voltar">
            <ArrowLeft className="size-5" />
          </button>
          <h1 className="font-heading text-xl font-bold">Ranking de amigos</h1>
        </div>

        {/* Period tabs */}
        <div className="mt-4 flex gap-1.5 rounded-2xl bg-white/15 p-1.5">
          {(["weekly", "monthly"] as const).map((p) => (
            <button
              key={p}
              onClick={() => setPeriod(p)}
              className={cn(
                "flex-1 rounded-xl py-2 font-heading text-sm font-bold transition",
                period === p ? "bg-white text-brand-blue shadow-sm" : "text-white/80",
              )}
            >
              {p === "weekly" ? "Semanal" : "Mensal"}
            </button>
          ))}
        </div>
      </header>

      <div className="flex-1 overflow-y-auto px-5 pb-10">
        {/* Podium */}
        <div className="pt-10">
          <Podium entries={entries} />
        </div>

        {/* Remaining ranks */}
        <div className="mt-6 flex flex-col gap-2.5">
          {rest.map((e, i) => (
            <div
              key={e.id}
              className={cn(
                "flex items-center gap-3 rounded-2xl p-3 shadow-sm",
                e.isMe ? "bg-brand-blue/10 ring-2 ring-brand-blue/40" : "bg-card",
              )}
            >
              <span className="w-6 text-center font-heading text-sm font-bold text-muted-foreground">
                {i + 4}
              </span>
              <Avatar name={e.name} tone={e.tone} size="sm" online={e.online} />
              <div className="min-w-0 flex-1">
                <p className="truncate font-heading text-sm font-bold text-foreground">
                  {e.isMe ? "Você" : e.name}
                </p>
                <span className="flex items-center gap-1 text-[11px] font-bold text-brand-orange">
                  <Flame className="size-3 fill-brand-orange" />
                  {e.streak} dias
                </span>
              </div>
              <span className="flex items-center gap-1 font-heading text-sm font-bold text-foreground">
                <Zap className="size-3.5 fill-brand-gold text-brand-gold" />
                {e.periodXp.toLocaleString("pt-BR")}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
