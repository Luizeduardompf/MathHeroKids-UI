"use client"

import { useMemo, useState } from "react"
import { Search, ArrowLeft, UserPlus, Check, Clock, Flame } from "lucide-react"
import { Avatar } from "@/components/avatar"
import { SEARCH_POOL, TONE_SOFT, type SearchResult } from "@/lib/friends-data"

export function AddFriendScreen() {
  const [query, setQuery] = useState("")
  const [results, setResults] = useState<SearchResult[]>(SEARCH_POOL)

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase()
    if (!q) return results
    return results.filter(
      (r) => r.username.toLowerCase().includes(q) || r.name.toLowerCase().includes(q),
    )
  }, [query, results])

  const sendRequest = (id: string) =>
    setResults((rs) => rs.map((r) => (r.id === id ? { ...r, status: "pending" } : r)))

  return (
    <div className="flex h-full w-full flex-col bg-background">
      {/* Header */}
      <header className="bg-brand-blue px-5 pb-5 pt-10 text-white">
        <div className="flex items-center gap-3">
          <button className="flex size-10 items-center justify-center rounded-2xl bg-white/15 transition active:scale-95" aria-label="Voltar">
            <ArrowLeft className="size-5" />
          </button>
          <h1 className="font-heading text-xl font-bold">Adicionar amigo</h1>
        </div>
        {/* Search input */}
        <div className="mt-4 flex items-center gap-2 rounded-2xl bg-white px-4 py-3 shadow-sm">
          <Search className="size-5 text-muted-foreground" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Digite o nome de usuário"
            className="w-full bg-transparent font-sans text-sm text-foreground placeholder:text-muted-foreground focus:outline-none"
          />
        </div>
      </header>

      <div className="flex-1 overflow-y-auto px-5 pb-10 pt-5">
        <p className="mb-3 font-heading text-sm font-bold text-foreground">
          {query ? `Resultados para "${query}"` : "Sugestões para você"}
        </p>

        {filtered.length === 0 ? (
          <div className="mt-12 flex flex-col items-center text-center">
            <span className="flex size-16 items-center justify-center rounded-full bg-muted text-muted-foreground">
              <Search className="size-7" />
            </span>
            <p className="mt-4 font-heading text-base font-bold text-foreground">
              Nenhum herói encontrado
            </p>
            <p className="mt-1 max-w-[15rem] text-sm font-semibold text-muted-foreground">
              Verifique o nome de usuário e tente novamente.
            </p>
          </div>
        ) : (
          <div className="flex flex-col gap-3">
            {filtered.map((r) => (
              <div key={r.id} className="flex items-center gap-3 rounded-2xl bg-card p-3 shadow-sm">
                <Avatar name={r.name} tone={r.tone} size="md" />
                <div className="min-w-0 flex-1">
                  <p className="truncate font-heading text-sm font-bold text-foreground">{r.name}</p>
                  <div className="mt-0.5 flex items-center gap-2">
                    <span className="truncate text-xs font-semibold text-muted-foreground">@{r.username}</span>
                    <span className="flex items-center gap-1 text-[11px] font-bold text-brand-orange">
                      <Flame className="size-3 fill-brand-orange" />
                      {r.streak}
                    </span>
                  </div>
                </div>
                {r.status === "friend" ? (
                  <span className="flex items-center gap-1 rounded-xl bg-brand-green/15 px-3 py-2 text-xs font-bold text-brand-green-dark">
                    <Check className="size-4" />
                    Amigo
                  </span>
                ) : r.status === "pending" ? (
                  <span className="flex items-center gap-1 rounded-xl bg-muted px-3 py-2 text-xs font-bold text-muted-foreground">
                    <Clock className="size-4" />
                    Pendente
                  </span>
                ) : (
                  <button
                    onClick={() => sendRequest(r.id)}
                    className="flex items-center gap-1 rounded-xl bg-brand-blue px-3 py-2 text-xs font-bold text-white shadow-sm transition active:scale-95"
                  >
                    <UserPlus className="size-4" />
                    Adicionar
                  </button>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
