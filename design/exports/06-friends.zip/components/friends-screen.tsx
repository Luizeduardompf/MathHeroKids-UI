"use client"

import { useState } from "react"
import { Search, UserPlus, Trophy, Flame, Check, X, ChevronRight, Zap } from "lucide-react"
import { Avatar } from "@/components/avatar"
import { BottomNav } from "@/components/bottom-nav"
import { FRIENDS, REQUESTS, TONE_SOFT } from "@/lib/friends-data"

export function FriendsScreen() {
  const [requests, setRequests] = useState(REQUESTS)

  const resolve = (id: string) => setRequests((rs) => rs.filter((r) => r.id !== id))

  return (
    <div className="flex h-full w-full flex-col bg-background">
      {/* Header */}
      <header className="bg-brand-blue px-5 pb-6 pt-10 text-white">
        <div className="flex items-center justify-between">
          <div>
            <p className="font-heading text-sm font-semibold text-white/80">Math Hero Kids</p>
            <h1 className="font-heading text-2xl font-bold">Amigos</h1>
          </div>
          <button className="flex size-11 items-center justify-center rounded-2xl bg-white/15 transition active:scale-95">
            <UserPlus className="size-5" />
          </button>
        </div>
        {/* Search */}
        <div className="mt-4 flex items-center gap-2 rounded-2xl bg-white/15 px-4 py-3">
          <Search className="size-5 text-white/80" />
          <span className="font-sans text-sm text-white/80">Buscar por nome de usuário</span>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto px-5 pb-24 pt-5">
        {/* Pending requests */}
        {requests.length > 0 && (
          <section className="mb-6">
            <div className="mb-3 flex items-center justify-between">
              <h2 className="font-heading text-base font-bold text-foreground">Pedidos pendentes</h2>
              <span className="flex size-6 items-center justify-center rounded-full bg-brand-orange text-xs font-bold text-white">
                {requests.length}
              </span>
            </div>
            <div className="flex flex-col gap-3">
              {requests.map((r) => (
                <div key={r.id} className="flex items-center gap-3 rounded-2xl bg-card p-3 shadow-sm">
                  <Avatar name={r.name} tone={r.tone} size="md" />
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-heading text-sm font-bold text-foreground">{r.name}</p>
                    <p className="truncate text-xs font-semibold text-muted-foreground">
                      {r.mutual} amigos em comum
                    </p>
                  </div>
                  <button
                    onClick={() => resolve(r.id)}
                    className="flex size-9 items-center justify-center rounded-xl bg-brand-green text-white shadow-sm transition active:scale-90"
                    aria-label={`Aceitar ${r.name}`}
                  >
                    <Check className="size-5" />
                  </button>
                  <button
                    onClick={() => resolve(r.id)}
                    className="flex size-9 items-center justify-center rounded-xl bg-muted text-muted-foreground transition active:scale-90"
                    aria-label={`Recusar ${r.name}`}
                  >
                    <X className="size-5" />
                  </button>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Ranking shortcut */}
        <button className="mb-6 flex w-full items-center gap-3 rounded-2xl bg-brand-gold/20 p-4 text-left transition active:scale-[0.98]">
          <span className="flex size-11 items-center justify-center rounded-2xl bg-brand-gold text-white shadow-sm">
            <Trophy className="size-5 fill-white" />
          </span>
          <div className="flex-1">
            <p className="font-heading text-sm font-bold text-foreground">Ranking de amigos</p>
            <p className="text-xs font-semibold text-muted-foreground">Veja quem está na frente</p>
          </div>
          <ChevronRight className="size-5 text-muted-foreground" />
        </button>

        {/* Friends list */}
        <section>
          <div className="mb-3 flex items-center justify-between">
            <h2 className="font-heading text-base font-bold text-foreground">
              Meus amigos
            </h2>
            <span className="text-xs font-bold text-muted-foreground">{FRIENDS.length}</span>
          </div>
          <div className="flex flex-col gap-3">
            {FRIENDS.map((f) => (
              <button
                key={f.id}
                className="flex items-center gap-3 rounded-2xl bg-card p-3 text-left shadow-sm transition active:scale-[0.98]"
              >
                <Avatar name={f.name} tone={f.tone} size="md" online={f.online} />
                <div className="min-w-0 flex-1">
                  <p className="truncate font-heading text-sm font-bold text-foreground">{f.name}</p>
                  <div className="mt-0.5 flex items-center gap-3">
                    <span className={`flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-bold ${TONE_SOFT[f.tone]}`}>
                      Nível {f.level}
                    </span>
                    <span className="flex items-center gap-1 text-[11px] font-bold text-brand-orange">
                      <Flame className="size-3.5 fill-brand-orange" />
                      {f.streak}
                    </span>
                  </div>
                </div>
                <div className="flex flex-col items-end">
                  <span className="flex items-center gap-1 font-heading text-sm font-bold text-foreground">
                    <Zap className="size-3.5 fill-brand-gold text-brand-gold" />
                    {f.xp.toLocaleString("pt-BR")}
                  </span>
                  <span className="text-[11px] font-semibold text-muted-foreground">XP</span>
                </div>
              </button>
            ))}
          </div>
        </section>
      </div>

      <BottomNav active="friends" />
    </div>
  )
}
