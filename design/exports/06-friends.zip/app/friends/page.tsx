"use client"

import { useState } from "react"
import { PhoneFrame } from "@/components/phone-frame"
import { FriendsScreen } from "@/components/friends-screen"
import { AddFriendScreen } from "@/components/add-friend-screen"
import { FriendsRankingScreen } from "@/components/friends-ranking-screen"

const TABS = [
  { id: "friends", label: "Amigos" },
  { id: "add", label: "Adicionar amigo" },
  { id: "ranking", label: "Ranking" },
] as const

export default function FriendsDemoPage() {
  const [tab, setTab] = useState<(typeof TABS)[number]["id"]>("friends")

  return (
    <main className="flex min-h-screen flex-col items-center bg-background px-4 py-10">
      <header className="mb-2 text-center">
        <h1 className="font-heading text-3xl font-bold text-foreground">Math Hero Kids</h1>
        <p className="mt-1 text-base font-semibold text-muted-foreground">Telas de Amigos</p>
      </header>

      {/* Tabs */}
      <div className="mt-6 flex flex-wrap items-center justify-center gap-2 rounded-full bg-card p-1.5 shadow-sm">
        {TABS.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`rounded-full px-4 py-2 font-heading text-sm font-semibold transition ${
              tab === t.id ? "bg-brand-blue text-white shadow" : "text-muted-foreground hover:bg-accent"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Phone mockup */}
      <div className="mt-8 w-full max-w-[360px]">
        <PhoneFrame>
          {tab === "friends" && <FriendsScreen />}
          {tab === "add" && <AddFriendScreen />}
          {tab === "ranking" && <FriendsRankingScreen />}
        </PhoneFrame>
      </div>

      <p className="mt-6 max-w-md text-center text-sm leading-relaxed text-muted-foreground">
        Telas sociais do Math Hero Kids: lista de amigos com pedidos pendentes,
        busca para adicionar novos amigos e ranking semanal e mensal.
      </p>
    </main>
  )
}
