export type Friend = {
  id: string
  name: string
  username: string
  /** avatar background tone */
  tone: "blue" | "orange" | "green" | "gold" | "red"
  /** current level */
  level: number
  /** total XP */
  xp: number
  /** day streak */
  streak: number
  online?: boolean
}

export type FriendRequest = {
  id: string
  name: string
  username: string
  tone: Friend["tone"]
  /** mutual friends count */
  mutual: number
}

export type SearchResult = Friend & {
  status: "none" | "pending" | "friend"
}

export const TONE_BG: Record<Friend["tone"], string> = {
  blue: "bg-brand-blue",
  orange: "bg-brand-orange",
  green: "bg-brand-green",
  gold: "bg-brand-gold",
  red: "bg-brand-red",
}

export const TONE_SOFT: Record<Friend["tone"], string> = {
  blue: "bg-brand-blue/12 text-brand-blue",
  orange: "bg-brand-orange/15 text-brand-orange",
  green: "bg-brand-green/15 text-brand-green-dark",
  gold: "bg-brand-gold/20 text-[oklch(0.45_0.1_75)]",
  red: "bg-brand-red/12 text-brand-red",
}

export const FRIENDS: Friend[] = [
  { id: "f1", name: "Lucas Andrade", username: "lucas_mat", tone: "blue", level: 12, xp: 4820, streak: 9, online: true },
  { id: "f2", name: "Sofia Lima", username: "sofia.star", tone: "orange", level: 11, xp: 4310, streak: 14, online: true },
  { id: "f3", name: "Pedro Costa", username: "pedrinho7", tone: "green", level: 9, xp: 3650, streak: 4 },
  { id: "f4", name: "Maria Clara", username: "mclara", tone: "red", level: 8, xp: 3120, streak: 6, online: true },
  { id: "f5", name: "Theo Martins", username: "theo_hero", tone: "gold", level: 7, xp: 2740, streak: 2 },
  { id: "f6", name: "Alice Ramos", username: "alice.r", tone: "blue", level: 6, xp: 2180, streak: 1 },
]

export const REQUESTS: FriendRequest[] = [
  { id: "r1", name: "Beatriz Nunes", username: "bia_nunes", tone: "orange", mutual: 3 },
  { id: "r2", name: "Gabriel Souza", username: "gabe.souza", tone: "green", mutual: 1 },
]

export const SEARCH_POOL: SearchResult[] = [
  { id: "s1", name: "Enzo Ferreira", username: "enzo_f", tone: "blue", level: 10, xp: 3900, streak: 5, status: "none" },
  { id: "s2", name: "Valentina Rocha", username: "valrocha", tone: "red", level: 13, xp: 5200, streak: 21, status: "none" },
  { id: "s3", name: "Miguel Dias", username: "miguel.d", tone: "green", level: 5, xp: 1820, streak: 3, status: "pending" },
  { id: "s4", name: "Helena Pires", username: "lena_pires", tone: "gold", level: 9, xp: 3480, streak: 8, status: "none" },
  { id: "s5", name: "Davi Carvalho", username: "davi_c", tone: "orange", level: 7, xp: 2610, streak: 2, status: "friend" },
]

export type RankingEntry = Friend & {
  /** XP earned in the ranking period */
  periodXp: number
  /** true if this entry is the current user */
  isMe?: boolean
}

export const WEEKLY_RANKING: RankingEntry[] = [
  { id: "f2", name: "Sofia Lima", username: "sofia.star", tone: "orange", level: 11, xp: 4310, streak: 14, periodXp: 1240 },
  { id: "me", name: "Você", username: "voce", tone: "blue", level: 10, xp: 4050, streak: 9, periodXp: 1180, isMe: true },
  { id: "f1", name: "Lucas Andrade", username: "lucas_mat", tone: "blue", level: 12, xp: 4820, streak: 9, periodXp: 990 },
  { id: "f4", name: "Maria Clara", username: "mclara", tone: "red", level: 8, xp: 3120, streak: 6, periodXp: 870 },
  { id: "f3", name: "Pedro Costa", username: "pedrinho7", tone: "green", level: 9, xp: 3650, streak: 4, periodXp: 640 },
  { id: "f5", name: "Theo Martins", username: "theo_hero", tone: "gold", level: 7, xp: 2740, streak: 2, periodXp: 410 },
]

export const MONTHLY_RANKING: RankingEntry[] = [
  { id: "f1", name: "Lucas Andrade", username: "lucas_mat", tone: "blue", level: 12, xp: 4820, streak: 9, periodXp: 5120 },
  { id: "f2", name: "Sofia Lima", username: "sofia.star", tone: "orange", level: 11, xp: 4310, streak: 14, periodXp: 4980 },
  { id: "f4", name: "Maria Clara", username: "mclara", tone: "red", level: 8, xp: 3120, streak: 6, periodXp: 4210 },
  { id: "me", name: "Você", username: "voce", tone: "blue", level: 10, xp: 4050, streak: 9, periodXp: 3890, isMe: true },
  { id: "f3", name: "Pedro Costa", username: "pedrinho7", tone: "green", level: 9, xp: 3650, streak: 4, periodXp: 3120 },
  { id: "f6", name: "Alice Ramos", username: "alice.r", tone: "blue", level: 6, xp: 2180, streak: 1, periodXp: 2040 },
]

export function initials(name: string) {
  const parts = name.trim().split(/\s+/)
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase()
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase()
}
