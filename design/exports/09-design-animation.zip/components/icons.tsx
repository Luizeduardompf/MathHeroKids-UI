/**
 * Centralized icon set for MathHeroKids.
 *
 * All SVG icons used across the app are re-exported from this single module so
 * they are easy to find, swap, or replace (e.g. when porting to React Native).
 * Components must import icons from here, never directly from "lucide-react".
 */
export {
  // success screen
  Trophy,
  Zap,
  // calendar screen
  ChevronLeft,
  ChevronRight,
  Flame,
  Home,
  Calendar,
  Swords,
  Users,
  Settings,
  // day cell + celebration
  Star,
  Lock,
  Sparkles,
} from "lucide-react"

export type { LucideIcon } from "lucide-react"
