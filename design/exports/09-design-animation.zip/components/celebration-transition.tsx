"use client"

import { motion } from "motion/react"
import { Trophy, Sparkles, Star } from "@/components/icons"
import { useEffect } from "react"
import { Confetti } from "@/components/confetti"

export function CelebrationTransition({ onComplete }: { onComplete: () => void }) {
  useEffect(() => {
    const t = setTimeout(onComplete, 3000)
    return () => clearTimeout(t)
  }, [onComplete])

  return (
    <motion.div
      className="fixed inset-0 z-50 flex flex-col items-center justify-center overflow-hidden"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      {/* full-bleed flash background */}
      <motion.div
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(circle at 50% 45%, color-mix(in oklch, var(--sunshine) 80%, white) 0%, var(--gold) 40%, var(--primary) 100%)",
        }}
        initial={{ scale: 0, borderRadius: "100%" }}
        animate={{ scale: 4, borderRadius: "0%" }}
        transition={{ duration: 0.6, ease: "easeOut" }}
      />

      <Confetti count={120} />

      {/* spinning sun rays behind trophy */}
      <motion.div
        className="absolute size-[120vw]"
        style={{
          background:
            "repeating-conic-gradient(from 0deg, rgba(255,255,255,0.35) 0deg 8deg, transparent 8deg 16deg)",
        }}
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1, rotate: 360 }}
        transition={{ scale: { delay: 0.4, duration: 0.5 }, rotate: { delay: 0.4, duration: 8, ease: "linear" } }}
      />

      {/* burst ring */}
      <motion.div
        className="absolute rounded-full border-[6px] border-white"
        initial={{ width: 80, height: 80, opacity: 0.9 }}
        animate={{ width: 520, height: 520, opacity: 0 }}
        transition={{ delay: 0.5, duration: 1, ease: "easeOut" }}
      />

      {/* the trophy */}
      <motion.div
        className="relative z-10 flex size-44 items-center justify-center rounded-[2.5rem] bg-white shadow-2xl"
        initial={{ scale: 0, rotate: -180, y: 40 }}
        animate={{
          scale: [0, 1.3, 1],
          rotate: [-180, 0, 0],
          y: [40, 0, 0],
        }}
        transition={{ delay: 0.45, duration: 0.8, times: [0, 0.7, 1], ease: "easeOut" }}
      >
        <motion.div
          animate={{ rotate: [0, -8, 8, -5, 5, 0] }}
          transition={{ delay: 1.2, duration: 1, ease: "easeInOut" }}
        >
          <Trophy className="size-24 text-accent" strokeWidth={2.2} />
        </motion.div>

        {/* sparkles around trophy */}
        {[
          { Icon: Sparkles, top: "-12%", left: "-10%", d: 0.9 },
          { Icon: Star, top: "-8%", right: "-12%", d: 1.05 },
          { Icon: Star, bottom: "-10%", left: "-6%", d: 1.15 },
          { Icon: Sparkles, bottom: "-12%", right: "-8%", d: 1.25 },
        ].map(({ Icon, d, ...pos }, i) => (
          <motion.span
            key={i}
            className="absolute text-sunshine"
            style={pos as React.CSSProperties}
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: [0, 1.3, 1], opacity: 1, rotate: 360 }}
            transition={{ delay: d, duration: 0.6, repeat: Number.POSITIVE_INFINITY, repeatType: "reverse" }}
          >
            <Icon className="size-7 fill-current" />
          </motion.span>
        ))}
      </motion.div>

      <motion.h2
        className="relative z-10 mt-10 text-center font-heading text-5xl font-extrabold text-white drop-shadow-lg"
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 1, type: "spring", stiffness: 260, damping: 16 }}
      >
        Troféu Conquistado!
      </motion.h2>
      <motion.p
        className="relative z-10 mt-3 font-heading text-xl font-bold text-white/90"
        initial={{ y: 14, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 1.3 }}
      >
        O dia 8 agora é seu!
      </motion.p>
    </motion.div>
  )
}
