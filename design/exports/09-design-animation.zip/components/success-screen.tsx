"use client"

import { motion } from "motion/react"
import Image from "next/image"
import { Trophy, Zap } from "@/components/icons"
import { ASSETS } from "@/lib/assets"
import { Confetti } from "@/components/confetti"

export function SuccessScreen({ onContinue }: { onContinue: () => void }) {
  return (
    <div className="relative flex min-h-dvh flex-col overflow-hidden bg-gold px-6 pb-10 pt-6 text-gold-foreground">
      {/* soft radial glow */}
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "radial-gradient(120% 80% at 50% 20%, color-mix(in oklch, var(--sunshine) 70%, white) 0%, var(--gold) 55%, color-mix(in oklch, var(--gold) 80%, black) 100%)",
        }}
        aria-hidden="true"
      />
      <Confetti count={90} />

      {/* XP badge */}
      <motion.div
        initial={{ y: -30, opacity: 0, scale: 0.7 }}
        animate={{ y: 0, opacity: 1, scale: 1 }}
        transition={{ type: "spring", stiffness: 320, damping: 18, delay: 0.1 }}
        className="relative z-10 ml-auto flex items-center gap-1.5 rounded-full bg-black/15 px-4 py-2 font-heading text-lg font-extrabold text-white shadow-lg backdrop-blur-sm"
      >
        <Zap className="size-5 fill-current" />
        +300 XP
      </motion.div>

      <div className="relative z-10 flex flex-1 flex-col items-center justify-center text-center">
        {/* Milo */}
        <motion.div
          initial={{ scale: 0, rotate: -25 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{ type: "spring", stiffness: 200, damping: 12, delay: 0.2 }}
          className="relative"
        >
          <div className="animate-float-bob relative size-52 overflow-hidden rounded-full border-[6px] border-white bg-white shadow-2xl">
            <Image src={ASSETS.miloCelebrate || "/placeholder.svg"} alt="Milo comemorando" fill className="object-cover" priority />
          </div>
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", stiffness: 300, damping: 12, delay: 0.7 }}
            className="absolute bottom-2 right-0 flex size-16 items-center justify-center rounded-full border-4 border-white bg-accent shadow-xl"
          >
            <Trophy className="size-8 text-white" />
          </motion.div>
        </motion.div>

        <motion.h1
          initial={{ y: 24, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.45, type: "spring", stiffness: 260, damping: 18 }}
          className="mt-8 text-balance font-heading text-5xl font-extrabold leading-tight text-white drop-shadow-md"
        >
          Desafio concluído!
        </motion.h1>

        <motion.p
          initial={{ y: 16, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.6 }}
          className="mt-4 max-w-xs text-pretty text-lg font-semibold leading-relaxed text-white/90"
        >
          Incrível! Você terminou o desafio de hoje. Milo está orgulhoso!
        </motion.p>

        {/* progress */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.7 }}
          className="mt-10 w-full max-w-sm"
        >
          <div className="mb-2 flex items-center justify-between font-heading font-bold text-white">
            <span>20 / 20 questões</span>
            <span>100%</span>
          </div>
          <div className="h-4 w-full overflow-hidden rounded-full bg-black/15">
            <motion.div
              initial={{ width: "0%" }}
              animate={{ width: "100%" }}
              transition={{ delay: 0.8, duration: 1, ease: "easeOut" }}
              className="h-full rounded-full bg-white"
            />
          </div>
        </motion.div>
      </div>

      {/* Continue button */}
      <motion.button
        type="button"
        onClick={onContinue}
        initial={{ y: 40, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 1, type: "spring", stiffness: 260, damping: 20 }}
        whileTap={{ scale: 0.94 }}
        whileHover={{ scale: 1.03 }}
        className="relative z-10 mx-auto mt-4 w-full max-w-sm rounded-full bg-white py-4 font-heading text-xl font-extrabold text-gold-foreground shadow-xl"
      >
        Continuar
      </motion.button>
    </div>
  )
}
