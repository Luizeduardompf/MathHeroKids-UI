"use client"

import Image from "next/image"
import { ChevronLeft, ChevronRight, Flame, Trophy, Home, Calendar, Swords, Users, Settings } from "@/components/icons"
import { JUNE_2026, WEEKDAYS, CONQUERED_DAY } from "@/lib/calendar-data"
import { ASSETS } from "@/lib/assets"
import { DayCell } from "@/components/day-cell"

export function CalendarScreen({ celebrateDay }: { celebrateDay: number | null }) {
  return (
    <div className="relative flex min-h-dvh flex-col bg-background pb-24">
      <div className="mx-auto w-full max-w-md px-4 pt-6">
        {/* profile + XP */}
        <div className="mb-4 flex items-center gap-3 rounded-3xl bg-card p-3 shadow-sm">
          <div className="relative size-12 overflow-hidden rounded-2xl border-2 border-primary/30 bg-primary/10">
            <Image src={ASSETS.miloMascot || "/placeholder.svg"} alt="Avatar de Sofia" fill className="object-cover" />
          </div>
          <div className="flex-1">
            <div className="flex items-baseline justify-between">
              <p className="font-heading text-lg font-extrabold text-card-foreground">Sofia</p>
              <p className="font-heading text-sm font-bold text-primary">1.450 / 2.000 XP</p>
            </div>
            <p className="-mt-1 text-xs font-semibold text-muted-foreground">Nível 12</p>
            <div className="mt-1.5 h-2.5 w-full overflow-hidden rounded-full bg-secondary">
              <div className="h-full rounded-full bg-primary" style={{ width: "72%" }} />
            </div>
          </div>
        </div>

        {/* Milo says */}
        <div className="mb-4 flex items-center gap-3 rounded-3xl bg-primary p-3 shadow-md">
          <div className="relative size-14 shrink-0 overflow-hidden rounded-full border-2 border-white/40 bg-white">
            <Image src={ASSETS.miloMascot || "/placeholder.svg"} alt="Milo" fill className="object-cover" />
          </div>
          <div className="rounded-2xl bg-white px-4 py-2.5">
            <p className="text-[11px] font-extrabold uppercase tracking-wide text-primary">Milo diz</p>
            <p className="text-sm font-bold leading-snug text-foreground">Sua sequência está incrível! Não perca hoje.</p>
          </div>
        </div>

        {/* stats */}
        <div className="mb-4 grid grid-cols-2 gap-3">
          <div className="flex items-center gap-3 rounded-3xl bg-accent p-4 text-accent-foreground shadow-sm">
            <div className="flex size-12 items-center justify-center rounded-full bg-white/25">
              <Flame className="size-6" />
            </div>
            <div>
              <p className="font-heading text-2xl font-extrabold leading-none">8</p>
              <p className="text-sm font-bold">Sequência</p>
            </div>
          </div>
          <div className="flex items-center gap-3 rounded-3xl bg-card p-4 shadow-sm">
            <div className="flex size-12 items-center justify-center rounded-full bg-gold-soft">
              <Trophy className="size-6 text-gold" />
            </div>
            <div>
              <p className="font-heading text-2xl font-extrabold leading-none text-card-foreground">22</p>
              <p className="text-sm font-bold text-muted-foreground">Recorde</p>
            </div>
          </div>
        </div>

        {/* calendar card */}
        <div className="rounded-3xl bg-card p-4 shadow-sm">
          <div className="mb-3 flex items-center justify-between">
            <button className="flex size-9 items-center justify-center rounded-full bg-secondary text-secondary-foreground">
              <ChevronLeft className="size-5" />
            </button>
            <h2 className="font-heading text-xl font-extrabold text-card-foreground">Junho 2026</h2>
            <button className="flex size-9 items-center justify-center rounded-full bg-secondary text-secondary-foreground">
              <ChevronRight className="size-5" />
            </button>
          </div>

          <div className="mb-2 grid grid-cols-7 gap-1">
            {WEEKDAYS.map((w, i) => (
              <div key={i} className="text-center text-xs font-extrabold text-muted-foreground">
                {w}
              </div>
            ))}
          </div>

          <div className="grid grid-cols-7 gap-y-3">
            {JUNE_2026.map((d, i) =>
              d.day === null ? (
                <div key={i} />
              ) : (
                <DayCell
                  key={i}
                  day={d.day}
                  status={d.status}
                  index={i}
                  celebrate={celebrateDay === d.day && d.day === CONQUERED_DAY}
                />
              ),
            )}
          </div>
        </div>
      </div>

      {/* bottom nav */}
      <nav className="fixed inset-x-0 bottom-0 z-20 border-t border-border bg-card">
        <div className="mx-auto flex max-w-md items-center justify-around px-2 py-2">
          <NavItem icon={Home} label="Início" />
          <NavItem icon={Calendar} label="Calendário" active />
          <div className="flex flex-col items-center -translate-y-3">
            <div className="flex size-14 items-center justify-center rounded-full bg-accent text-accent-foreground shadow-lg ring-4 ring-card">
              <Swords className="size-6" />
            </div>
            <span className="mt-1 text-[11px] font-bold text-accent">Desafio</span>
          </div>
          <NavItem icon={Users} label="Amigos" />
          <NavItem icon={Settings} label="Ajustes" />
        </div>
      </nav>
    </div>
  )
}

function NavItem({
  icon: Icon,
  label,
  active = false,
}: {
  icon: React.ElementType
  label: string
  active?: boolean
}) {
  return (
    <button className="flex flex-col items-center gap-1">
      <Icon className={active ? "size-6 text-primary" : "size-6 text-muted-foreground"} />
      <span className={`text-[11px] font-bold ${active ? "text-primary" : "text-muted-foreground"}`}>{label}</span>
    </button>
  )
}
