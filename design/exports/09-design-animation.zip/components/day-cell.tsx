"use client"

import { motion, useAnimationControls } from "motion/react"
import { Trophy, Star, Lock, Sparkles } from "@/components/icons"
import { useEffect, useState } from "react"
import type { DayStatus } from "@/lib/calendar-data"
import { cn } from "@/lib/utils"

function StatusContent({ status, day }: { status: DayStatus; day: number }) {
  switch (status) {
    case "completed":
      return <Trophy className="size-6 text-success" strokeWidth={2.4} />
    case "special":
      return <Star className="size-6 fill-white text-white" strokeWidth={2.4} />
    case "missed":
      return <Trophy className="size-6 text-missed" strokeWidth={2.4} />
    case "earned":
      return <Trophy className="size-7 fill-white/20 text-white" strokeWidth={2.4} />
    case "today":
      return (
        <span className="flex flex-col items-center leading-none">
          <span className="font-heading text-lg font-extrabold text-white">{day}</span>
          <span className="text-[9px] font-bold text-white/90">HOJE</span>
        </span>
      )
    case "locked":
      return <Lock className="size-5 text-muted-foreground/60" />
    default:
      return null
  }
}

const STYLES: Record<string, string> = {
  completed: "bg-success-soft",
  special: "bg-gold",
  missed: "bg-missed-soft",
  today: "bg-primary",
  locked: "bg-muted",
  earned: "bg-gold shadow-[0_0_24px_4px_var(--gold)]",
}

export function DayCell({
  day,
  status,
  celebrate = false,
  index,
}: {
  day: number
  status: DayStatus
  celebrate?: boolean
  index: number
}) {
  const controls = useAnimationControls()
  const [display, setDisplay] = useState<DayStatus | "earned">(status)
  const [burst, setBurst] = useState(false)

  useEffect(() => {
    if (!celebrate) return
    let cancelled = false

    async function run() {
      // wait so the user sees the calendar + the still-"missed" red day first
      await new Promise((r) => setTimeout(r, 900))
      if (cancelled) return
      // shake it to draw attention
      await controls.start({
        rotate: [0, -12, 12, -10, 10, -6, 6, 0],
        transition: { duration: 0.7, ease: "easeInOut" },
      })
      if (cancelled) return
      // squash to nothing, swap content, then pop back as the gold trophy
      await controls.start({ scale: 0, transition: { duration: 0.18, ease: "easeIn" } })
      if (cancelled) return
      setDisplay("earned")
      setBurst(true)
      await controls.start({
        scale: [0, 1.6, 1],
        transition: { duration: 0.7, ease: "easeOut" },
      })
    }
    run()
    return () => {
      cancelled = true
    }
  }, [celebrate, controls])

  const showLabel = status !== "today"

  return (
    <div className="relative flex flex-col items-center gap-1">
      {/* expanding glow ring on transform */}
      {burst && (
        <motion.span
          className="absolute top-0 size-12 rounded-full border-4 border-gold"
          initial={{ scale: 0.6, opacity: 0.9 }}
          animate={{ scale: 2.6, opacity: 0 }}
          transition={{ duration: 0.9, ease: "easeOut" }}
        />
      )}
      {/* sparkle pops on transform */}
      {burst &&
        [
          { x: -22, y: -18 },
          { x: 22, y: -18 },
          { x: -22, y: 20 },
          { x: 22, y: 20 },
        ].map((p, i) => (
          <motion.span
            key={i}
            className="absolute top-3 text-sunshine"
            initial={{ x: 0, y: 0, scale: 0, opacity: 1 }}
            animate={{ x: p.x, y: p.y, scale: [0, 1.2, 0], opacity: [1, 1, 0] }}
            transition={{ duration: 0.9, delay: 0.1, ease: "easeOut" }}
          >
            <Sparkles className="size-4 fill-current" />
          </motion.span>
        ))}

      <motion.div
        animate={controls}
        className={cn(
          "flex size-11 items-center justify-center rounded-full transition-colors",
          STYLES[display],
        )}
      >
        <StatusContent status={display} day={day} />
      </motion.div>

      {showLabel && (
        <span
          className={cn(
            "font-heading text-xs font-bold",
            display === "earned" ? "text-gold-foreground" : "text-muted-foreground",
            status === "locked" && "text-muted-foreground/60",
          )}
        >
          {day}
        </span>
      )}
    </div>
  )
}
