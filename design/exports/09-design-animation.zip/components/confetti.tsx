"use client"

import { motion } from "motion/react"
import { useEffect, useMemo, useState } from "react"

const COLORS = [
  "var(--primary)",
  "var(--accent)",
  "var(--success)",
  "var(--gold)",
  "var(--missed)",
  "var(--sunshine)",
]

type Piece = {
  id: number
  x: number
  delay: number
  duration: number
  rotate: number
  color: string
  size: number
  round: boolean
  drift: number
}

export function Confetti({
  count = 70,
  className = "",
  spread = 100,
  origin = "top",
}: {
  count?: number
  className?: string
  spread?: number
  origin?: "top" | "center"
}) {
  const [mounted, setMounted] = useState(false)
  useEffect(() => setMounted(true), [])

  const pieces = useMemo<Piece[]>(() => {
    if (!mounted) return []
    return Array.from({ length: count }).map((_, i) => ({
      id: i,
      x: Math.random() * spread,
      delay: Math.random() * 0.6,
      duration: 1.6 + Math.random() * 1.8,
      rotate: Math.random() * 720 - 360,
      color: COLORS[i % COLORS.length],
      size: 8 + Math.random() * 8,
      round: Math.random() > 0.5,
      drift: Math.random() * 80 - 40,
    }))
  }, [count, spread, mounted])

  if (!mounted) return null

  return (
    <div className={`pointer-events-none absolute inset-0 overflow-hidden ${className}`} aria-hidden="true">
      {pieces.map((p) => (
        <motion.span
          key={p.id}
          className="absolute"
          style={{
            left: `${p.x}%`,
            top: origin === "center" ? "45%" : "-5%",
            width: p.size,
            height: p.round ? p.size : p.size * 0.5,
            backgroundColor: p.color,
            borderRadius: p.round ? "9999px" : "2px",
          }}
          initial={{ y: 0, x: 0, opacity: 0, rotate: 0 }}
          animate={{
            y: origin === "center" ? ["0%", "120vh"] : ["0vh", "115vh"],
            x: [0, p.drift, p.drift * 1.4],
            opacity: [0, 1, 1, 0],
            rotate: p.rotate,
          }}
          transition={{
            duration: p.duration,
            delay: p.delay,
            ease: "easeIn",
          }}
        />
      ))}
    </div>
  )
}
