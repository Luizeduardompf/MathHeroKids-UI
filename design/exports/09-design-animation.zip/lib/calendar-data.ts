export type DayStatus = "completed" | "special" | "missed" | "today" | "locked" | "earned"

export type CalendarDay = {
  day: number | null
  status: DayStatus
}

// June 2026 — week starts on Sunday (D S T Q Q S S = Dom, Seg, Ter, Qua, Qui, Sex, Sab)
// Day 8 starts as "missed" and is the day the child just conquered.
export const JUNE_2026: CalendarDay[] = [
  { day: null, status: "locked" },
  { day: null, status: "locked" },
  { day: null, status: "locked" },
  { day: 1, status: "completed" },
  { day: 2, status: "special" },
  { day: 3, status: "missed" },
  { day: 4, status: "completed" },

  { day: 5, status: "special" },
  { day: 6, status: "completed" },
  { day: 7, status: "completed" },
  { day: 8, status: "missed" }, // <- the conquered day
  { day: 9, status: "special" },
  { day: 10, status: "completed" },
  { day: 11, status: "completed" },

  { day: 12, status: "special" },
  { day: 13, status: "missed" },
  { day: 14, status: "completed" },
  { day: 15, status: "completed" },
  { day: 16, status: "special" },
  { day: 17, status: "completed" },
  { day: 18, status: "today" },

  { day: 19, status: "locked" },
  { day: 20, status: "locked" },
  { day: 21, status: "locked" },
  { day: 22, status: "locked" },
  { day: 23, status: "locked" },
  { day: 24, status: "locked" },
  { day: 25, status: "locked" },
]

export const WEEKDAYS = ["D", "S", "T", "Q", "Q", "S", "S"]

export const CONQUERED_DAY = 8
