/**
 * Centralized font configuration for MathHeroKids.
 *
 * Heading font: Baloo 2 (rounded, playful) -> exposed as --font-heading
 * Body font:    Nunito (friendly, legible) -> exposed as --font-sans
 *
 * Keeping these here isolates all typography choices in one place.
 * The CSS variables are consumed in app/globals.css via @theme inline.
 */
import { Baloo_2, Nunito } from "next/font/google"

export const headingFont = Baloo_2({
  variable: "--font-heading",
  subsets: ["latin"],
  weight: ["500", "600", "700", "800"],
})

export const bodyFont = Nunito({
  variable: "--font-sans",
  subsets: ["latin"],
  weight: ["400", "600", "700", "800"],
})

/** Combined font CSS variables to spread onto the <html> element. */
export const fontVariables = `${headingFont.variable} ${bodyFont.variable}`
