/**
 * Centralized asset manifest for MathHeroKids.
 *
 * All raster image assets live in /public and are referenced through this
 * manifest so paths are defined in exactly one place.
 */
export const ASSETS = {
  /** Milo mascot, neutral thumbs-up pose (avatar + "Milo diz" card). */
  miloMascot: "/milo-mascot.png",
  /** Milo celebrating with arms raised (success screen). */
  miloCelebrate: "/milo-celebrate.png",
} as const

export type AssetKey = keyof typeof ASSETS
