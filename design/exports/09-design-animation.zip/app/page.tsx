"use client"

import { AnimatePresence, motion } from "motion/react"
import { useState } from "react"
import { SuccessScreen } from "@/components/success-screen"
import { CelebrationTransition } from "@/components/celebration-transition"
import { CalendarScreen } from "@/components/calendar-screen"
import { CONQUERED_DAY } from "@/lib/calendar-data"
import { RotateCcw } from "lucide-react"

type Phase = "success" | "transition" | "calendar"

export default function Home() {
  const [phase, setPhase] = useState<Phase>("success")

  return (
    <main className="relative">
      <AnimatePresence mode="wait">
        {phase === "success" && (
          <motion.div key="success" exit={{ opacity: 0, scale: 0.96 }} transition={{ duration: 0.3 }}>
            <SuccessScreen onContinue={() => setPhase("transition")} />
          </motion.div>
        )}

        {phase === "transition" && (
          <CelebrationTransition key="transition" onComplete={() => setPhase("calendar")} />
        )}

        {phase === "calendar" && (
          <motion.div key="calendar" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}>
            <CalendarScreen celebrateDay={CONQUERED_DAY} />
          </motion.div>
        )}
      </AnimatePresence>

      {/* replay control to re-experience the flow */}
      {phase === "calendar" && (
        <button
          type="button"
          onClick={() => setPhase("success")}
          className="fixed right-4 top-4 z-30 flex items-center gap-2 rounded-full bg-primary px-4 py-2 font-heading text-sm font-bold text-primary-foreground shadow-lg"
        >
          <RotateCcw className="size-4" />
          Repetir
        </button>
      )}
    </main>
  )
}
