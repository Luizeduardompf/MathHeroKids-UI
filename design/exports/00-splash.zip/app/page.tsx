"use client"

import Image from "next/image"
import { useEffect, useState } from "react"
import {
  Plus,
  Minus,
  X,
  Divide,
  Equal,
  Star,
  Sparkles,
  Users,
  Music,
  MessageCircle,
  Pencil,
  Notebook,
  Backpack,
  Volleyball,
} from "lucide-react"

const TITLE = "Math Hero Kids"

// Floating icons that drift up: math symbols mixed with school & social life.
const FLOATERS = [
  { Icon: Plus, left: "6%", size: 26, delay: 0, duration: 7, drift: 18, tone: "text-brand-foreground/25" },
  { Icon: Backpack, left: "14%", size: 30, delay: 2.1, duration: 9, drift: -16, tone: "text-gold/40" },
  { Icon: Minus, left: "22%", size: 20, delay: 1.6, duration: 8, drift: -14, tone: "text-brand-foreground/25" },
  { Icon: MessageCircle, left: "30%", size: 26, delay: 3.4, duration: 8.4, drift: 20, tone: "text-sky-200/40" },
  { Icon: X, left: "38%", size: 24, delay: 0.8, duration: 6.5, drift: 22, tone: "text-brand-foreground/25" },
  { Icon: Pencil, left: "46%", size: 26, delay: 2.7, duration: 7.8, drift: -18, tone: "text-gold/45" },
  { Icon: Divide, left: "52%", size: 22, delay: 2.4, duration: 7.5, drift: -10, tone: "text-brand-foreground/25" },
  { Icon: Music, left: "60%", size: 26, delay: 1.1, duration: 9.2, drift: 16, tone: "text-pink-200/45" },
  { Icon: Equal, left: "66%", size: 24, delay: 0.4, duration: 8.5, drift: 16, tone: "text-brand-foreground/25" },
  { Icon: Users, left: "72%", size: 30, delay: 3, duration: 8.6, drift: -20, tone: "text-emerald-200/45" },
  { Icon: Plus, left: "78%", size: 20, delay: 4, duration: 7, drift: -12, tone: "text-brand-foreground/25" },
  { Icon: Notebook, left: "84%", size: 28, delay: 1.9, duration: 8.8, drift: 14, tone: "text-orange-200/45" },
  { Icon: Volleyball, left: "90%", size: 28, delay: 3.6, duration: 9.4, drift: -16, tone: "text-brand-foreground/35" },
  { Icon: X, left: "94%", size: 22, delay: 1.2, duration: 6.8, drift: 12, tone: "text-brand-foreground/25" },
]

// Numbers that also float up, mixed with the symbols.
const NUMBERS = [
  { value: "7", left: "14%", size: 30, delay: 1, duration: 8, drift: 14 },
  { value: "3", left: "40%", size: 26, delay: 2.2, duration: 7.2, drift: -16 },
  { value: "9", left: "68%", size: 34, delay: 0.6, duration: 8.8, drift: 20 },
  { value: "5", left: "82%", size: 24, delay: 2.8, duration: 6.6, drift: -12 },
]

// Stars orbiting around the mascot.
const ORBIT_STARS = [
  { angle: 0, radius: 110, size: 18, duration: 9 },
  { angle: 120, radius: 120, size: 14, duration: 11 },
  { angle: 240, radius: 100, size: 16, duration: 10 },
]

export default function SplashScreen() {
  const [progress, setProgress] = useState(0)
  // Bumps every few seconds to replay the one-shot entrance animations on loop.
  const [cycle, setCycle] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((prev) => (prev >= 100 ? 0 : Math.min(prev + 4, 100)))
    }, 90)

    const replay = setInterval(() => {
      setCycle((c) => c + 1)
    }, 6000)

    return () => {
      clearInterval(interval)
      clearInterval(replay)
    }
  }, [])

  return (
    <main className="relative flex min-h-[100dvh] flex-col items-center justify-between overflow-hidden bg-brand px-6 py-16 text-brand-foreground">
      {/* Soft drifting background glows */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -left-24 -top-24 size-80 rounded-full bg-brand-foreground/10 blur-3xl animate-[drift_12s_ease-in-out_infinite]"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -bottom-28 -right-20 size-96 rounded-full bg-gold/20 blur-3xl animate-[drift_14s_ease-in-out_infinite_reverse]"
      />

      {/* Floating math symbols */}
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 overflow-hidden">
        {FLOATERS.map(({ Icon, left, size, delay, duration, drift, tone }, i) => (
          <span
            key={`sym-${i}`}
            className={`absolute bottom-[-10%] animate-[rise_var(--dur)_linear_infinite] ${tone}`}
            style={
              {
                left,
                "--dur": `${duration}s`,
                "--drift": `${drift}px`,
                animationDelay: `${delay}s`,
              } as React.CSSProperties
            }
          >
            <Icon style={{ width: size, height: size }} strokeWidth={3} />
          </span>
        ))}
        {NUMBERS.map(({ value, left, size, delay, duration, drift }, i) => (
          <span
            key={`num-${i}`}
            className="absolute bottom-[-10%] font-heading font-extrabold text-gold/30 animate-[rise_var(--dur)_linear_infinite]"
            style={
              {
                left,
                fontSize: size,
                "--dur": `${duration}s`,
                "--drift": `${drift}px`,
                animationDelay: `${delay}s`,
              } as React.CSSProperties
            }
          >
            {value}
          </span>
        ))}
      </div>

      {/* spacer */}
      <div aria-hidden="true" />

      {/* Logo + name */}
      <div key={cycle} className="relative z-10 flex flex-col items-center text-center">
        <div className="relative mb-10 animate-[pop_0.9s_cubic-bezier(0.22,1.4,0.36,1)_both]">
          {/* pulsing halo */}
          <div className="absolute inset-0 -z-10 scale-[1.35] rounded-full bg-brand-foreground/15 blur-2xl animate-[halo_2.6s_ease-in-out_infinite]" />

          {/* orbiting stars */}
          {ORBIT_STARS.map(({ angle, radius, size, duration }, i) => (
            <span
              key={`orbit-${i}`}
              aria-hidden="true"
              className="absolute left-1/2 top-1/2 animate-[orbit_var(--dur)_linear_infinite]"
              style={
                {
                  "--angle": `${angle}deg`,
                  "--radius": `${radius}px`,
                  "--dur": `${duration}s`,
                } as React.CSSProperties
              }
            >
              <Star
                className="fill-gold text-gold drop-shadow"
                style={{ width: size, height: size }}
              />
            </span>
          ))}

          {/* mascot with gentle float */}
          <div className="animate-[float_3s_ease-in-out_infinite]">
            <div className="overflow-hidden rounded-[2.25rem] bg-card shadow-2xl ring-4 ring-brand-foreground/25">
              <Image
                src="/milo-mascot.png"
                alt="Milo, o mago da matemática, mascote do Math Hero Kids"
                width={220}
                height={220}
                priority
                className="size-44 object-cover sm:size-48"
              />
            </div>
            <Sparkles
              aria-hidden="true"
              className="absolute -right-3 -top-2 size-8 text-gold animate-[twinkle_1.8s_ease-in-out_infinite]"
            />
          </div>
        </div>

        {/* Title revealed letter by letter */}
        <h1 className="font-heading text-5xl font-extrabold tracking-tight text-balance sm:text-6xl">
          <span className="sr-only">{TITLE}</span>
          <span aria-hidden="true" className="inline-flex flex-wrap justify-center">
            {TITLE.split("").map((char, i) => (
              <span
                key={i}
                className="inline-block animate-[letter_0.6s_cubic-bezier(0.22,1.4,0.36,1)_both]"
                style={{ animationDelay: `${0.9 + i * 0.05}s` }}
              >
                {char === " " ? "\u00A0" : char}
              </span>
            ))}
          </span>
        </h1>
        <p className="mt-3 font-heading text-lg font-semibold text-brand-foreground/80 animate-[fadeUp_0.6s_ease-out_both]" style={{ animationDelay: "1.7s" }}>
          Aprender é uma aventura!
        </p>
      </div>

      {/* Loading indicator: bouncing dots */}
      <div className="relative z-10 flex flex-col items-center gap-4">
        <div
          className="flex items-end gap-2"
          role="progressbar"
          aria-valuenow={progress}
          aria-valuemin={0}
          aria-valuemax={100}
          aria-label="Carregando o aplicativo"
        >
          {[0, 1, 2].map((i) => (
            <span
              key={i}
              className="size-3.5 rounded-full bg-gold animate-[bounceDot_1.1s_ease-in-out_infinite]"
              style={{ animationDelay: `${i * 0.16}s` }}
            />
          ))}
        </div>
        <p className="font-heading text-sm font-semibold text-brand-foreground/70">Carregando...</p>
      </div>

      <style jsx global>{`
        @keyframes float {
          0%,
          100% {
            transform: translateY(0) rotate(-1.5deg);
          }
          50% {
            transform: translateY(-14px) rotate(1.5deg);
          }
        }
        @keyframes pop {
          0% {
            transform: scale(0) rotate(-25deg);
            opacity: 0;
          }
          60% {
            transform: scale(1.12) rotate(6deg);
            opacity: 1;
          }
          100% {
            transform: scale(1) rotate(0deg);
            opacity: 1;
          }
        }
        @keyframes halo {
          0%,
          100% {
            transform: scale(1.3);
            opacity: 0.5;
          }
          50% {
            transform: scale(1.55);
            opacity: 0.85;
          }
        }
        @keyframes orbit {
          from {
            transform: rotate(var(--angle)) translateX(var(--radius)) rotate(calc(-1 * var(--angle)));
          }
          to {
            transform: rotate(calc(var(--angle) + 360deg)) translateX(var(--radius))
              rotate(calc(-1 * (var(--angle) + 360deg)));
          }
        }
        @keyframes twinkle {
          0%,
          100% {
            transform: scale(0.8) rotate(0deg);
            opacity: 0.7;
          }
          50% {
            transform: scale(1.2) rotate(20deg);
            opacity: 1;
          }
        }
        @keyframes rise {
          0% {
            transform: translateY(0) translateX(0) rotate(0deg);
            opacity: 0;
          }
          12% {
            opacity: 1;
          }
          88% {
            opacity: 1;
          }
          100% {
            transform: translateY(-115vh) translateX(var(--drift)) rotate(180deg);
            opacity: 0;
          }
        }
        @keyframes letter {
          0% {
            transform: translateY(22px) scale(0.6);
            opacity: 0;
          }
          100% {
            transform: translateY(0) scale(1);
            opacity: 1;
          }
        }
        @keyframes fadeUp {
          0% {
            transform: translateY(12px);
            opacity: 0;
          }
          100% {
            transform: translateY(0);
            opacity: 1;
          }
        }
        @keyframes bounceDot {
          0%,
          100% {
            transform: translateY(0);
            opacity: 0.6;
          }
          50% {
            transform: translateY(-12px);
            opacity: 1;
          }
        }
        @keyframes drift {
          0%,
          100% {
            transform: translate(0, 0);
          }
          50% {
            transform: translate(30px, 20px);
          }
        }
        @media (prefers-reduced-motion: reduce) {
          .animate-\\[float_3s_ease-in-out_infinite\\],
          .animate-\\[pop_0\\.9s_cubic-bezier\\(0\\.22\\,1\\.4\\,0\\.36\\,1\\)_both\\] {
            animation: none !important;
          }
        }
      `}</style>
    </main>
  )
}
