"use client"

import { useState } from "react"
import { Volume2, VolumeX } from "lucide-react"
import { MiloCelebration } from "@/components/milo-celebration"
import { MILESTONES } from "@/lib/milestones"

export default function Page() {
  const [active, setActive] = useState(0)
  const [soundOn, setSoundOn] = useState(true)
  // Bump a key to force a fresh mount (replays animation + auto-continue)
  const [playKey, setPlayKey] = useState(0)

  const milestone = MILESTONES[active]

  const selectMilestone = (i: number) => {
    setActive(i)
    setPlayKey((k) => k + 1)
  }

  return (
    <main className="flex min-h-screen flex-col items-center bg-background px-4 py-10">
      <header className="mb-2 text-center">
        <h1 className="font-heading text-3xl font-bold text-foreground">Math Hero Kids</h1>
        <p className="mt-1 text-base font-semibold text-muted-foreground">
          Momentos Especiais do Milo
        </p>
      </header>

      {/* Tabs */}
      <div className="mt-6 flex flex-wrap items-center justify-center gap-2 rounded-full bg-card p-1.5 shadow-sm">
        {MILESTONES.map((m, i) => (
          <button
            key={m.id}
            onClick={() => selectMilestone(i)}
            className={`rounded-full px-4 py-2 font-heading text-sm font-semibold transition ${
              active === i
                ? "bg-brand-blue text-white shadow"
                : "text-muted-foreground hover:bg-accent"
            }`}
          >
            {m.isFinal ? "Concluído" : m.progressLabel.split(" ")[0] + " questões"}
          </button>
        ))}
      </div>

      {/* Controls */}
      <div className="mt-4 flex items-center gap-3">
        <button
          onClick={() => setSoundOn((s) => !s)}
          className="flex items-center gap-2 rounded-full bg-card px-4 py-2 text-sm font-semibold text-foreground shadow-sm transition active:scale-95"
          aria-pressed={soundOn}
        >
          {soundOn ? <Volume2 className="size-4 text-brand-blue" /> : <VolumeX className="size-4 text-muted-foreground" />}
          Som {soundOn ? "ligado" : "desligado"}
        </button>
        <button
          onClick={() => setPlayKey((k) => k + 1)}
          className="rounded-full bg-brand-orange px-4 py-2 text-sm font-bold text-white shadow-sm transition active:scale-95"
        >
          Reproduzir de novo
        </button>
      </div>

      {/* Phone mockup */}
      <div className="mt-8 w-full max-w-[360px]">
        <div className="relative aspect-[9/19] w-full overflow-hidden rounded-[2.5rem] border-8 border-foreground/90 bg-foreground shadow-2xl">
          <div className="absolute inset-0 overflow-hidden rounded-[2rem]">
            <MiloCelebration
              key={`${milestone.id}-${playKey}`}
              milestone={milestone}
              soundOn={soundOn}
              autoMs={2600}
              onContinue={() => {
                // Auto-advance to next milestone for a continuous demo
                setActive((i) => {
                  const next = (i + 1) % MILESTONES.length
                  return next
                })
                setPlayKey((k) => k + 1)
              }}
            />
          </div>
        </div>
      </div>

      <p className="mt-6 max-w-md text-center text-sm leading-relaxed text-muted-foreground">
        Estas telas aparecem ocasionalmente entre as questões para motivar a
        criança. Avançam sozinhas após cerca de 2-3 segundos.
      </p>
    </main>
  )
}
