export type MilestoneTone = "blue" | "orange" | "green" | "gold"

export type Milestone = {
  id: string
  /** Big celebration headline (Milo is the hero) */
  title: string
  /** Supporting line under the title */
  subtitle: string
  /** Short label badge, e.g. "5 / 10" */
  progressLabel: string
  /** 0-100 fill of the little progress bar */
  progressPercent: number
  /** XP reward shown in the floating pill */
  xp: number
  /** Visual accent that drives the gradient + glow */
  tone: MilestoneTone
  /** "star" for partial milestones, "trophy" for the final win */
  icon: "star" | "trophy"
  /** Whether this is the final challenge-complete screen */
  isFinal?: boolean
}

export const MILESTONES: Milestone[] = [
  {
    id: "q5",
    title: "Mandou bem!",
    subtitle: "Você já completou 5 questões. Continue assim!",
    progressLabel: "5 / 20 questões",
    progressPercent: 25,
    xp: 50,
    tone: "blue",
    icon: "star",
  },
  {
    id: "q10",
    title: "Você está na metade!",
    subtitle: "10 questões concluídas. Falta pouco para a estrela!",
    progressLabel: "10 / 20 questões",
    progressPercent: 50,
    xp: 100,
    tone: "orange",
    icon: "star",
  },
  {
    id: "q15",
    title: "Faltam só algumas!",
    subtitle: "15 questões! Você é um verdadeiro herói da matemática.",
    progressLabel: "15 / 20 questões",
    progressPercent: 75,
    xp: 150,
    tone: "green",
    icon: "star",
  },
  {
    id: "done",
    title: "Desafio concluído!",
    subtitle: "Incrível! Você terminou o desafio de hoje. Milo está orgulhoso!",
    progressLabel: "20 / 20 questões",
    progressPercent: 100,
    xp: 300,
    tone: "gold",
    icon: "trophy",
    isFinal: true,
  },
]
