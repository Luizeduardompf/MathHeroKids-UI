"use client"

import { useEffect, useState } from "react"
import Image from "next/image"
import { Sparkles, Star, Trophy, Zap } from "lucide-react"
import { Confetti } from "@/components/confetti"
import { useChime } from "@/hooks/use-chime"
import type { Milestone } from "@/lib/milestones"

const TONE = {
  blue: {
    gradFrom: "from-[oklch(0.58_0.2_262)]",
    gradTo: "to-[oklch(0.45_0.21_263)]",
    glow: "bg-[oklch(0.58_0.2_262)]",
    iconWrap: "bg-brand-blue",
    bar: "bg-brand-blue",
  },
  orange: {
    gradFrom: "from-[oklch(0.72_0.18_52)]",
    gradTo: "to-[oklch(0.62_0.2_38)]",
    glow: "bg-[oklch(0.72_0.18_52)]",
    iconWrap: "bg-brand-orange",
    bar: "bg-brand-orange",
  },
  green: {
    gradFrom: "from-[oklch(0.66_0.16_152)]",
    gradTo: "to-[oklch(0.52_0.15_153)]",
    glow: "bg-[oklch(0.66_0.16_152)]",
    iconWrap: "bg-brand-green",
    bar: "bg-brand-green",
  },
  gold: {
    gradFrom: "from-[oklch(0.84_0.15_85)]",
    gradTo: "to-[oklch(0.72_0.16_70)]",
    glow: "bg-[oklch(0.84_0.15_85)]",
    iconWrap: "bg-brand-gold",
    bar: "bg-brand-gold",
  },
} as const

export function MiloCelebration({
  milestone,
  autoMs = 2600,
  soundOn = true,
  onContinue,
}: {
  milestone: Milestone
  autoMs?: number
  soundOn?: boolean
  onContinue?: () => void
}) {
  const tone = TONE[milestone.tone]
  const chime = useChime()
  const [progress, setProgress] = useState(0)

  useEffect(() => {
    if (soundOn) chime(milestone.isFinal ? "win" : "milestone")
    // animate the auto-continue progress bar
    const start = performance.now()
    let frame = 0
    const tick = (now: number) => {
      const pct = Math.min(1, (now - start) / autoMs)
      setProgress(pct)
      if (pct < 1) {
        frame = requestAnimationFrame(tick)
      } else {
        onContinue?.()
      }
    }
    frame = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(frame)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [milestone.id])

  return (
    <div
      className={`relative flex h-full w-full flex-col items-center justify-center overflow-hidden bg-gradient-to-b ${tone.gradFrom} ${tone.gradTo} px-6`}
      role="alertdialog"
      aria-label={milestone.title}
    >
      <Confetti count={milestone.isFinal ? 90 : 60} seed={milestone.progressPercent} />

      {/* Soft background glow */}
      <div
        className={`pointer-events-none absolute left-1/2 top-1/3 size-72 -translate-x-1/2 -translate-y-1/2 rounded-full ${tone.glow} opacity-30 blur-3xl`}
        aria-hidden="true"
      />

      {/* XP pill */}
      <div className="animate-badge-pop absolute right-6 top-10 flex items-center gap-1.5 rounded-full bg-brand-gold px-4 py-2 text-[oklch(0.32_0.07_70)] shadow-lg">
        <Zap className="size-4 fill-current" />
        <span className="font-heading text-base font-bold">+{milestone.xp} XP</span>
      </div>

      {/* Twinkling stars around Milo */}
      <Star className="animate-star-twinkle absolute left-10 top-24 size-6 fill-white text-white opacity-90" style={{ animationDelay: "0.2s" }} />
      <Sparkles className="animate-star-twinkle absolute right-12 top-40 size-8 text-white opacity-90" style={{ animationDelay: "0.6s" }} />
      <Star className="animate-star-twinkle absolute bottom-40 left-14 size-5 fill-white text-white opacity-80" style={{ animationDelay: "0.9s" }} />

      {/* Milo hero */}
      <div className="relative flex flex-col items-center">
        <div className="relative">
          <div className="animate-ring-pulse absolute inset-0 rounded-full bg-white/40" aria-hidden="true" />
          <div className="animate-milo-pop relative flex size-44 items-center justify-center overflow-hidden rounded-full bg-white shadow-2xl ring-8 ring-white/30">
            <div className="animate-milo-float relative size-44">
              <Image
                src="/milo-celebrating.png"
                alt="Milo, o mago mascote, comemorando"
                fill
                className="object-contain drop-shadow-md"
                priority
              />
            </div>
          </div>
          {/* Icon badge on the corner */}
          <div className={`animate-badge-pop absolute -bottom-2 -right-2 flex size-16 items-center justify-center rounded-full ${tone.iconWrap} shadow-xl ring-4 ring-white`}>
            {milestone.icon === "trophy" ? (
              <Trophy className="size-8 fill-white text-white" />
            ) : (
              <Star className="size-8 fill-white text-white" />
            )}
          </div>
        </div>
      </div>

      {/* Text */}
      <h1 className="animate-text-rise mt-10 text-balance text-center font-heading text-4xl font-bold text-white" style={{ animationDelay: "0.15s" }}>
        {milestone.title}
      </h1>
      <p className="animate-text-rise mt-3 max-w-xs text-pretty text-center text-lg font-semibold leading-relaxed text-white/90" style={{ animationDelay: "0.3s" }}>
        {milestone.subtitle}
      </p>

      {/* Progress chip */}
      <div className="animate-text-rise mt-8 w-full max-w-xs" style={{ animationDelay: "0.45s" }}>
        <div className="mb-2 flex items-center justify-between text-sm font-bold text-white/90">
          <span>{milestone.progressLabel}</span>
          <span>{milestone.progressPercent}%</span>
        </div>
        <div className="h-3 w-full overflow-hidden rounded-full bg-white/30">
          <div
            className="animate-progress-grow h-full rounded-full bg-white"
            style={{ width: `${milestone.progressPercent}%` }}
          />
        </div>
      </div>

      {/* Auto-continue indicator */}
      <div className="absolute bottom-8 left-1/2 flex -translate-x-1/2 flex-col items-center gap-2">
        <button
          onClick={onContinue}
          className="flex items-center gap-2 rounded-full bg-white/95 px-6 py-2.5 font-heading text-sm font-bold text-foreground shadow-lg transition active:scale-95"
        >
          Continuar
        </button>
        <div className="h-1 w-24 overflow-hidden rounded-full bg-white/30">
          <div
            className="h-full rounded-full bg-white"
            style={{ width: `${progress * 100}%` }}
          />
        </div>
      </div>
    </div>
  )
}
