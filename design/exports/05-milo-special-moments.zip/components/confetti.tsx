"use client"

import { useMemo } from "react"

const CONFETTI_COLORS = [
  "var(--brand-blue)",
  "var(--brand-orange)",
  "var(--brand-green)",
  "var(--brand-gold)",
  "var(--brand-red)",
]

type Piece = {
  left: number
  delay: number
  duration: number
  color: string
  size: number
  rounded: boolean
}

export function Confetti({ count = 60, seed = 0 }: { count?: number; seed?: number }) {
  const pieces = useMemo<Piece[]>(() => {
    // Deterministic pseudo-random so re-renders stay stable per seed
    let s = seed * 9301 + 49297
    const rand = () => {
      s = (s * 9301 + 49297) % 233280
      return s / 233280
    }
    return Array.from({ length: count }).map(() => ({
      left: rand() * 100,
      delay: rand() * 0.8,
      duration: 1.8 + rand() * 1.6,
      color: CONFETTI_COLORS[Math.floor(rand() * CONFETTI_COLORS.length)],
      size: 7 + rand() * 8,
      rounded: rand() > 0.5,
    }))
  }, [count, seed])

  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden="true">
      {pieces.map((p, i) => (
        <span
          key={i}
          className="animate-confetti-fall absolute top-0 block"
          style={{
            left: `${p.left}%`,
            width: `${p.size}px`,
            height: `${p.size * 1.4}px`,
            backgroundColor: p.color,
            borderRadius: p.rounded ? "9999px" : "2px",
            animationDelay: `${p.delay}s`,
            animationDuration: `${p.duration}s`,
          }}
        />
      ))}
    </div>
  )
}
