"use client"

import { useCallback, useRef } from "react"

// Lightweight WebAudio chime so we don't need to ship audio assets.
export function useChime() {
  const ctxRef = useRef<AudioContext | null>(null)

  return useCallback((variant: "milestone" | "win" = "milestone") => {
    if (typeof window === "undefined") return
    try {
      if (!ctxRef.current) {
        const AudioCtx = window.AudioContext || (window as any).webkitAudioContext
        if (!AudioCtx) return
        ctxRef.current = new AudioCtx()
      }
      const ctx = ctxRef.current
      if (ctx.state === "suspended") void ctx.resume()

      // A short happy arpeggio. The "win" variant is longer/higher.
      const notes =
        variant === "win" ? [523.25, 659.25, 783.99, 1046.5] : [523.25, 659.25, 783.99]
      const now = ctx.currentTime
      notes.forEach((freq, i) => {
        const osc = ctx.createOscillator()
        const gain = ctx.createGain()
        osc.type = "triangle"
        osc.frequency.value = freq
        const start = now + i * 0.12
        gain.gain.setValueAtTime(0, start)
        gain.gain.linearRampToValueAtTime(0.18, start + 0.03)
        gain.gain.exponentialRampToValueAtTime(0.0001, start + 0.35)
        osc.connect(gain)
        gain.connect(ctx.destination)
        osc.start(start)
        osc.stop(start + 0.4)
      })
    } catch {
      // Audio is best-effort; ignore failures (autoplay policies, etc.)
    }
  }, [])
}
