export type Child = {
  id: string
  name: string
  level: number
  xp: number
  avatar: string
  color: string
  active?: boolean
  stats: {
    streak: number
    bestStreak: number
    challengesDone: number
    perfectDays: number
    accuracy: number
  }
  difficulty: "facil" | "medio" | "dificil"
}

export const children: Child[] = [
  {
    id: "sofia",
    name: "Sofia",
    level: 12,
    xp: 9310,
    avatar: "/avatar-sofia.png",
    color: "oklch(0.52 0.22 260)",
    active: true,
    stats: {
      streak: 8,
      bestStreak: 21,
      challengesDone: 142,
      perfectDays: 18,
      accuracy: 92,
    },
    difficulty: "medio",
  },
  {
    id: "lucas",
    name: "Lucas",
    level: 15,
    xp: 9820,
    avatar: "/avatar-lucas.png",
    color: "oklch(0.7 0.18 45)",
    stats: {
      streak: 12,
      bestStreak: 30,
      challengesDone: 210,
      perfectDays: 25,
      accuracy: 95,
    },
    difficulty: "dificil",
  },
  {
    id: "pedro",
    name: "Pedro",
    level: 8,
    xp: 7650,
    avatar: "/avatar-pedro.png",
    color: "oklch(0.6 0.16 150)",
    stats: {
      streak: 3,
      bestStreak: 9,
      challengesDone: 64,
      perfectDays: 7,
      accuracy: 84,
    },
    difficulty: "facil",
  },
]

export const avatarOptions = [
  { id: "sofia", src: "/avatar-sofia.png", color: "oklch(0.52 0.22 260)" },
  { id: "lucas", src: "/avatar-lucas.png", color: "oklch(0.7 0.18 45)" },
  { id: "pedro", src: "/avatar-pedro.png", color: "oklch(0.6 0.16 150)" },
  { id: "mia", src: "/avatar-mia.png", color: "oklch(0.8 0.15 85)" },
  { id: "theo", src: "/avatar-theo.png", color: "oklch(0.58 0.22 25)" },
  { id: "luna", src: "/avatar-luna.png", color: "oklch(0.55 0.2 300)" },
]

export const languages = [
  { code: "PT", label: "Português", flag: "🇧🇷" },
  { code: "EN", label: "English", flag: "🇺🇸" },
  { code: "ES", label: "Español", flag: "🇪🇸" },
  { code: "FR", label: "Français", flag: "🇫🇷" },
]
