"use client"

import { useState } from "react"
import Link from "next/link"
import { AuthHeader } from "@/components/auth-header"
import { MiloBubble } from "@/components/milo-bubble"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card } from "@/components/ui/card"
import { Mail, MailCheck } from "lucide-react"

export default function ForgotPasswordPage() {
  const [sent, setSent] = useState(false)
  const [email, setEmail] = useState("")

  return (
    <div className="flex min-h-dvh flex-col bg-background font-sans">
      <AuthHeader subtitle="Math Hero Kids" title="Recuperar senha" backHref="/login" />

      <main className="mx-auto w-full max-w-md flex-1 px-5 py-6">
        {sent ? (
          <Card className="flex flex-col items-center p-6 text-center">
            <span className="flex h-20 w-20 items-center justify-center rounded-full bg-success/15 text-success">
              <MailCheck className="h-9 w-9" />
            </span>
            <h2 className="mt-5 text-2xl font-extrabold text-foreground">E-mail enviado!</h2>
            <p className="mt-2 text-pretty text-muted-foreground">
              Enviamos as instruções para redefinir a senha para{" "}
              <span className="font-semibold text-foreground">{email || "seu e-mail"}</span>. Confira a
              caixa de entrada.
            </p>
            <Button render={<Link href="/login" />} size="lg" className="mt-6 h-14 w-full rounded-full text-lg font-bold">
              Voltar para o login
            </Button>
            <button
              type="button"
              onClick={() => setSent(false)}
              className="mt-3 text-sm font-semibold text-primary hover:underline"
            >
              Não recebeu? Enviar de novo
            </button>
          </Card>
        ) : (
          <>
            <MiloBubble message="Sem problemas! Vou te ajudar a voltar para os desafios." />

            <Card className="mt-5 space-y-5 p-5">
              <p className="text-muted-foreground">
                Digite o e-mail do responsável cadastrado. Enviaremos um link para criar uma nova senha.
              </p>
              <form className="space-y-5" onSubmit={(e) => { e.preventDefault(); setSent(true) }}>
                <div className="space-y-2">
                  <Label htmlFor="email" className="font-semibold">
                    E-mail do responsável
                  </Label>
                  <div className="relative">
                    <Mail className="pointer-events-none absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      id="email"
                      type="email"
                      autoComplete="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="responsavel@email.com"
                      className="h-12 rounded-xl pl-11 text-base"
                    />
                  </div>
                </div>
                <Button type="submit" size="lg" className="h-14 w-full rounded-full text-lg font-bold">
                  Enviar instruções
                </Button>
              </form>
            </Card>

            <p className="mt-6 text-center text-muted-foreground">
              Lembrou a senha?{" "}
              <Link href="/login" className="font-bold text-primary hover:underline">
                Entrar
              </Link>
            </p>
          </>
        )}
      </main>
    </div>
  )
}
