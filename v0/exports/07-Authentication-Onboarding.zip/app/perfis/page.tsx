"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { ScreenHeader } from "@/components/screen-header"
import { BottomNav } from "@/components/bottom-nav"
import { Card } from "@/components/ui/card"
import { children as allChildren } from "@/lib/mock-data"
import { cn } from "@/lib/utils"
import { Check, Plus, Star, Zap } from "lucide-react"

export default function ProfileSwitcherPage() {
  const [activeId, setActiveId] = useState(
    allChildren.find((c) => c.active)?.id ?? allChildren[0].id,
  )

  return (
    <div className="flex min-h-dvh flex-col bg-background font-sans">
      <ScreenHeader subtitle="Math Hero Kids" title="Quem está jogando?" />

      <main className="mx-auto w-full max-w-md flex-1 space-y-4 px-5 py-6">
        <p className="text-center text-muted-foreground">
          Toque em um perfil para trocar de jogador.
        </p>

        <ul className="space-y-3">
          {allChildren.map((child) => {
            const active = child.id === activeId
            const progress = Math.min(100, Math.round((child.xp % 1000) / 10))
            return (
              <li key={child.id}>
                <button
                  type="button"
                  onClick={() => setActiveId(child.id)}
                  className="block w-full text-left"
                  aria-pressed={active}
                >
                  <Card
                    className={cn(
                      "flex items-center gap-4 p-4 transition-colors",
                      active ? "border-2 border-primary bg-primary/5" : "border border-border",
                    )}
                  >
                    <div className="relative shrink-0">
                      <span
                        className="flex h-16 w-16 items-center justify-center rounded-full p-0.5"
                        style={{ backgroundColor: child.color }}
                      >
                        <Image
                          src={child.avatar || "/placeholder.svg"}
                          alt={child.name}
                          width={60}
                          height={60}
                          className="h-15 w-15 rounded-full border-2 border-card object-cover"
                        />
                      </span>
                      {active ? (
                        <span className="absolute -bottom-1 -right-1 flex h-6 w-6 items-center justify-center rounded-full bg-primary text-primary-foreground ring-2 ring-card">
                          <Check className="h-3.5 w-3.5" />
                        </span>
                      ) : null}
                    </div>

                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between gap-2">
                        <p className="truncate text-lg font-extrabold text-foreground">{child.name}</p>
                        <span className="flex items-center gap-1 rounded-full bg-warning/20 px-2 py-0.5 text-xs font-bold text-warning-foreground">
                          <Star className="h-3 w-3 fill-current" />
                          Nível {child.level}
                        </span>
                      </div>
                      <div className="mt-2 flex items-center gap-2">
                        <span className="flex items-center gap-1 text-sm font-semibold text-primary">
                          <Zap className="h-3.5 w-3.5 fill-current" />
                          {child.xp.toLocaleString("pt-BR")} XP
                        </span>
                      </div>
                      <div className="mt-2 h-2 overflow-hidden rounded-full bg-muted">
                        <div
                          className="h-full rounded-full bg-primary"
                          style={{ width: `${progress}%` }}
                        />
                      </div>
                    </div>
                  </Card>
                </button>
              </li>
            )
          })}
        </ul>

        {/* Add child */}
        <Link
          href="/criar-perfil"
          className="flex w-full items-center gap-4 rounded-2xl border-2 border-dashed border-primary/40 bg-card p-4 text-left transition-colors hover:bg-primary/5"
        >
          <span className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/10 text-primary">
            <Plus className="h-7 w-7" />
          </span>
          <span>
            <span className="block text-lg font-extrabold text-foreground">Adicionar criança</span>
            <span className="block text-sm text-muted-foreground">Crie um novo perfil neste dispositivo</span>
          </span>
        </Link>
      </main>

      <BottomNav />
    </div>
  )
}
