import Link from "next/link"
import { Settings, ShieldCheck, Users, ChevronRight, Sparkles, UserPlus, Baby, LogIn, KeyRound, IdCard } from "lucide-react"

const authScreens = [
  {
    href: "/bem-vindo",
    title: "Boas-vindas",
    description: "Tela inicial de apresentação do app",
    icon: Sparkles,
    color: "bg-primary/10 text-primary",
  },
  {
    href: "/cadastro-pais",
    title: "Cadastro do responsável",
    description: "E-mail e senha do responsável",
    icon: UserPlus,
    color: "bg-secondary/15 text-secondary",
  },
  {
    href: "/cadastro-crianca",
    title: "Cadastro da criança",
    description: "Avatar, usuário e data de nascimento",
    icon: Baby,
    color: "bg-success/15 text-success",
  },
  {
    href: "/login",
    title: "Login",
    description: "Entrar com usuário e senha",
    icon: LogIn,
    color: "bg-primary/10 text-primary",
  },
  {
    href: "/recuperar-senha",
    title: "Recuperar senha",
    description: "Enviar link por e-mail",
    icon: KeyRound,
    color: "bg-warning/20 text-warning-foreground",
  },
  {
    href: "/criar-perfil",
    title: "Criar perfil (in-app)",
    description: "Adicionar outra criança à conta",
    icon: IdCard,
    color: "bg-success/15 text-success",
  },
]

const screens = [
  {
    href: "/ajustes",
    title: "Ajustes",
    description: "Idioma, tempo, tabuada, som e notificações",
    icon: Settings,
    color: "bg-primary/10 text-primary",
  },
  {
    href: "/controle-pais",
    title: "Controle dos pais",
    description: "PIN, estatísticas, dificuldade e gerenciamento",
    icon: ShieldCheck,
    color: "bg-secondary/15 text-secondary",
  },
  {
    href: "/perfis",
    title: "Trocar de perfil",
    description: "Várias crianças no mesmo dispositivo",
    icon: Users,
    color: "bg-success/15 text-success",
  },
]

export default function Home() {
  return (
    <div className="flex min-h-dvh flex-col items-center justify-center bg-background px-5 py-12 font-sans">
      <main className="w-full max-w-md">
        <div className="mb-8 text-center">
          <p className="text-sm font-bold uppercase tracking-wide text-primary">Math Hero Kids</p>
          <h1 className="text-balance text-3xl font-extrabold tracking-tight text-foreground">
            Telas novas
          </h1>
          <p className="mt-1 text-muted-foreground">Selecione uma tela para visualizar</p>
        </div>

        <h2 className="mb-3 text-sm font-bold uppercase tracking-wide text-muted-foreground">
          Onboarding e acesso
        </h2>
        <ul className="space-y-3">
          {authScreens.map(({ href, title, description, icon: Icon, color }) => (
            <li key={href}>
              <Link
                href={href}
                className="flex items-center gap-4 rounded-2xl border border-border bg-card p-4 transition-colors hover:border-primary/40"
              >
                <span className={`flex h-12 w-12 items-center justify-center rounded-full ${color}`}>
                  <Icon className="h-6 w-6" />
                </span>
                <span className="flex-1">
                  <span className="block font-bold text-foreground">{title}</span>
                  <span className="block text-sm text-muted-foreground">{description}</span>
                </span>
                <ChevronRight className="h-5 w-5 text-muted-foreground" />
              </Link>
            </li>
          ))}
        </ul>

        <h2 className="mb-3 mt-8 text-sm font-bold uppercase tracking-wide text-muted-foreground">
          Telas do app
        </h2>
        <ul className="space-y-3">
          {screens.map(({ href, title, description, icon: Icon, color }) => (
            <li key={href}>
              <Link
                href={href}
                className="flex items-center gap-4 rounded-2xl border border-border bg-card p-4 transition-colors hover:border-primary/40"
              >
                <span className={`flex h-12 w-12 items-center justify-center rounded-full ${color}`}>
                  <Icon className="h-6 w-6" />
                </span>
                <span className="flex-1">
                  <span className="block font-bold text-foreground">{title}</span>
                  <span className="block text-sm text-muted-foreground">{description}</span>
                </span>
                <ChevronRight className="h-5 w-5 text-muted-foreground" />
              </Link>
            </li>
          ))}
        </ul>
      </main>
    </div>
  )
}
