"use client"

import { useState } from "react"
import Link from "next/link"
import { AuthHeader } from "@/components/auth-header"
import { MiloBubble } from "@/components/milo-bubble"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card } from "@/components/ui/card"
import { User, Mail, Lock, Eye, EyeOff, Check } from "lucide-react"

export default function ParentRegistrationPage() {
  const [showPassword, setShowPassword] = useState(false)
  const [accepted, setAccepted] = useState(false)

  return (
    <div className="flex min-h-dvh flex-col bg-background font-sans">
      <AuthHeader subtitle="Passo 1 de 2" title="Conta do responsável" backHref="/bem-vindo" />

      <main className="mx-auto w-full max-w-md flex-1 px-5 py-6">
        <MiloBubble message="Oi! Sou o Milo. Primeiro o responsável cria a conta, depois montamos o perfil da criança!" />

        <Card className="mt-5 space-y-5 p-5">
          <form className="space-y-5" onSubmit={(e) => e.preventDefault()}>
            <div className="space-y-2">
              <Label htmlFor="parent-name" className="font-semibold">
                Nome do responsável
              </Label>
              <div className="relative">
                <User className="pointer-events-none absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
                <Input
                  id="parent-name"
                  type="text"
                  autoComplete="name"
                  placeholder="Seu nome completo"
                  className="h-12 rounded-xl pl-11 text-base"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="parent-email" className="font-semibold">
                E-mail
              </Label>
              <div className="relative">
                <Mail className="pointer-events-none absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
                <Input
                  id="parent-email"
                  type="email"
                  autoComplete="email"
                  placeholder="responsavel@email.com"
                  className="h-12 rounded-xl pl-11 text-base"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="parent-password" className="font-semibold">
                Senha
              </Label>
              <div className="relative">
                <Lock className="pointer-events-none absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
                <Input
                  id="parent-password"
                  type={showPassword ? "text" : "password"}
                  autoComplete="new-password"
                  placeholder="Crie uma senha forte"
                  className="h-12 rounded-xl px-11 text-base"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((s) => !s)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground transition-colors hover:text-foreground"
                  aria-label={showPassword ? "Ocultar senha" : "Mostrar senha"}
                >
                  {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                </button>
              </div>
              <p className="text-xs text-muted-foreground">Use ao menos 8 caracteres.</p>
            </div>

            {/* Terms */}
            <button
              type="button"
              onClick={() => setAccepted((a) => !a)}
              className="flex w-full items-start gap-3 text-left"
              aria-pressed={accepted}
            >
              <span
                className={`mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-md border-2 transition-colors ${
                  accepted ? "border-primary bg-primary text-primary-foreground" : "border-border bg-card"
                }`}
              >
                {accepted ? <Check className="h-4 w-4" /> : null}
              </span>
              <span className="text-sm text-muted-foreground">
                Sou responsável legal pela criança e aceito os termos de uso e a política de privacidade.
              </span>
            </button>

            <Button
              render={<Link href="/cadastro-crianca" />}
              size="lg"
              className="h-14 w-full rounded-full text-lg font-bold"
            >
              Continuar
            </Button>
          </form>
        </Card>

        <p className="mt-6 text-center text-muted-foreground">
          Já tem conta?{" "}
          <Link href="/login" className="font-bold text-primary hover:underline">
            Entrar
          </Link>
        </p>
      </main>
    </div>
  )
}
