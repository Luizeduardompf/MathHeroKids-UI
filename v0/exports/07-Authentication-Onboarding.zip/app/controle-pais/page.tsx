"use client"

import { useState } from "react"
import Image from "next/image"
import { ScreenHeader } from "@/components/screen-header"
import { BottomNav } from "@/components/bottom-nav"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { children as allChildren, type Child } from "@/lib/mock-data"
import { cn } from "@/lib/utils"
import {
  Lock,
  Delete,
  ShieldCheck,
  Flame,
  Target,
  CalendarCheck,
  Trophy,
  RotateCcw,
  ChevronRight,
} from "lucide-react"

const PIN = "1234"

function PinGate({ onSuccess }: { onSuccess: () => void }) {
  const [entered, setEntered] = useState("")
  const [error, setError] = useState(false)

  function press(digit: string) {
    if (entered.length >= 4) return
    const next = entered + digit
    setEntered(next)
    setError(false)
    if (next.length === 4) {
      if (next === PIN) {
        setTimeout(onSuccess, 200)
      } else {
        setTimeout(() => {
          setError(true)
          setEntered("")
        }, 250)
      }
    }
  }

  function backspace() {
    setEntered((p) => p.slice(0, -1))
    setError(false)
  }

  return (
    <main className="mx-auto flex w-full max-w-md flex-1 flex-col items-center justify-center px-5 py-8">
      <div className="flex h-20 w-20 items-center justify-center rounded-full bg-primary/10 text-primary">
        <Lock className="h-9 w-9" />
      </div>
      <h2 className="mt-5 text-2xl font-extrabold text-foreground">Área dos pais</h2>
      <p className="mt-1 text-center text-muted-foreground">Digite o PIN para continuar</p>

      <div className="mt-6 flex gap-3" aria-label="Campos do PIN">
        {[0, 1, 2, 3].map((i) => (
          <span
            key={i}
            className={cn(
              "h-4 w-4 rounded-full border-2 transition-colors",
              error
                ? "border-destructive"
                : entered.length > i
                  ? "border-primary bg-primary"
                  : "border-border",
            )}
          />
        ))}
      </div>
      {error ? <p className="mt-3 text-sm font-medium text-destructive">PIN incorreto. Tente novamente.</p> : null}
      <p className="mt-2 text-xs text-muted-foreground">Dica do protótipo: 1234</p>

      <div className="mt-6 grid w-full max-w-xs grid-cols-3 gap-3">
        {["1", "2", "3", "4", "5", "6", "7", "8", "9"].map((d) => (
          <button
            key={d}
            type="button"
            onClick={() => press(d)}
            className="rounded-2xl bg-card py-4 text-2xl font-bold text-foreground shadow-sm transition-colors hover:bg-accent"
          >
            {d}
          </button>
        ))}
        <span />
        <button
          type="button"
          onClick={() => press("0")}
          className="rounded-2xl bg-card py-4 text-2xl font-bold text-foreground shadow-sm transition-colors hover:bg-accent"
        >
          0
        </button>
        <button
          type="button"
          onClick={backspace}
          className="flex items-center justify-center rounded-2xl bg-muted py-4 text-foreground transition-colors hover:bg-accent"
          aria-label="Apagar"
        >
          <Delete className="h-6 w-6" />
        </button>
      </div>
    </main>
  )
}

function StatTile({
  icon: Icon,
  value,
  label,
  color,
}: {
  icon: typeof Flame
  value: string | number
  label: string
  color: string
}) {
  return (
    <Card className="p-4">
      <span className={cn("flex h-10 w-10 items-center justify-center rounded-full", color)}>
        <Icon className="h-5 w-5" />
      </span>
      <p className="mt-2 text-3xl font-extrabold text-foreground">{value}</p>
      <p className="text-sm font-medium text-muted-foreground">{label}</p>
    </Card>
  )
}

const difficultyLabels: Record<Child["difficulty"], string> = {
  facil: "Fácil",
  medio: "Médio",
  dificil: "Difícil",
}

function Dashboard() {
  const [selectedId, setSelectedId] = useState(allChildren[0].id)
  const [difficulty, setDifficulty] = useState<Child["difficulty"]>(
    allChildren[0].difficulty,
  )
  const child = allChildren.find((c) => c.id === selectedId)!

  return (
    <main className="mx-auto w-full max-w-md flex-1 space-y-4 px-5 py-6">
      {/* Child selector */}
      <section>
        <h2 className="mb-2 text-sm font-bold uppercase tracking-wide text-muted-foreground">Criança</h2>
        <div className="flex gap-3 overflow-x-auto pb-1">
          {allChildren.map((c) => {
            const active = c.id === selectedId
            return (
              <button
                key={c.id}
                type="button"
                onClick={() => {
                  setSelectedId(c.id)
                  setDifficulty(c.difficulty)
                }}
                className={cn(
                  "flex shrink-0 items-center gap-2 rounded-full border-2 py-1.5 pl-1.5 pr-4 transition-colors",
                  active ? "border-primary bg-primary/5" : "border-border bg-card",
                )}
              >
                <Image
                  src={c.avatar || "/placeholder.svg"}
                  alt={c.name}
                  width={36}
                  height={36}
                  className="h-9 w-9 rounded-full object-cover"
                />
                <span className="text-sm font-semibold text-foreground">{c.name}</span>
              </button>
            )
          })}
        </div>
      </section>

      {/* Statistics */}
      <section>
        <h2 className="mb-2 text-lg font-bold text-foreground">Estatísticas de {child.name}</h2>
        <div className="grid grid-cols-2 gap-3">
          <StatTile icon={Flame} value={child.stats.streak} label="Sequência atual" color="bg-secondary/15 text-secondary" />
          <StatTile icon={Trophy} value={child.stats.bestStreak} label="Melhor sequência" color="bg-warning/20 text-warning-foreground" />
          <StatTile icon={Target} value={`${child.stats.accuracy}%`} label="Precisão" color="bg-success/15 text-success" />
          <StatTile icon={CalendarCheck} value={child.stats.challengesDone} label="Desafios feitos" color="bg-primary/10 text-primary" />
        </div>
      </section>

      {/* Difficulty config */}
      <Card className="p-5">
        <h2 className="mb-3 flex items-center gap-2 text-lg font-bold text-foreground">
          <span className="flex h-8 w-8 items-center justify-center rounded-full bg-success/15 text-success">
            <Target className="h-4 w-4" />
          </span>
          Dificuldade
        </h2>
        <div className="grid grid-cols-3 gap-2">
          {(Object.keys(difficultyLabels) as Child["difficulty"][]).map((level) => {
            const active = difficulty === level
            return (
              <button
                key={level}
                type="button"
                onClick={() => setDifficulty(level)}
                className={cn(
                  "rounded-2xl border-2 py-3 text-sm font-semibold transition-colors",
                  active
                    ? "border-success bg-success/10 text-success"
                    : "border-border bg-card text-muted-foreground",
                )}
              >
                {difficultyLabels[level]}
              </button>
            )
          })}
        </div>
      </Card>

      {/* Child management */}
      <Card className="divide-y divide-border p-2">
        <button
          type="button"
          className="flex w-full items-center justify-between gap-3 px-3 py-3 text-left"
        >
          <span className="flex items-center gap-3">
            <span className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 text-primary">
              <ShieldCheck className="h-5 w-5" />
            </span>
            <span>
              <span className="block font-semibold text-foreground">Gerenciar perfil</span>
              <span className="block text-sm text-muted-foreground">Editar nome, avatar e idade</span>
            </span>
          </span>
          <ChevronRight className="h-5 w-5 text-muted-foreground" />
        </button>
        <button
          type="button"
          className="flex w-full items-center justify-between gap-3 px-3 py-3 text-left"
        >
          <span className="flex items-center gap-3">
            <span className="flex h-10 w-10 items-center justify-center rounded-full bg-secondary/15 text-secondary">
              <Lock className="h-5 w-5" />
            </span>
            <span>
              <span className="block font-semibold text-foreground">Alterar PIN dos pais</span>
              <span className="block text-sm text-muted-foreground">Proteja a área dos pais</span>
            </span>
          </span>
          <ChevronRight className="h-5 w-5 text-muted-foreground" />
        </button>
      </Card>

      {/* Reset progress */}
      <Card className="border-destructive/30 p-5">
        <div className="flex items-start gap-3">
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-destructive/10 text-destructive">
            <RotateCcw className="h-5 w-5" />
          </span>
          <div>
            <p className="font-semibold text-foreground">Resetar progresso</p>
            <p className="text-sm text-muted-foreground">
              Apaga XP, sequências e troféus de {child.name}. Esta ação não pode ser desfeita.
            </p>
          </div>
        </div>
        <Button
          variant="outline"
          className="mt-4 w-full border-destructive text-destructive hover:bg-destructive/5 hover:text-destructive"
        >
          Resetar progresso de {child.name}
        </Button>
      </Card>
    </main>
  )
}

export default function ParentControlsPage() {
  const [unlocked, setUnlocked] = useState(false)

  return (
    <div className="flex min-h-dvh flex-col bg-background font-sans">
      <ScreenHeader subtitle="Math Hero Kids" title="Controle dos pais" />
      {unlocked ? <Dashboard /> : <PinGate onSuccess={() => setUnlocked(true)} />}
      <BottomNav />
    </div>
  )
}
