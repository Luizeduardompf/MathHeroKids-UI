"use client"

import { useState } from "react"
import { ScreenHeader } from "@/components/screen-header"
import { BottomNav } from "@/components/bottom-nav"
import { Card } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Slider } from "@/components/ui/slider"
import { languages } from "@/lib/mock-data"
import { cn } from "@/lib/utils"
import { Globe, Timer, X, Volume2, Music, Bell, Check } from "lucide-react"

function SectionTitle({ icon: Icon, title, color }: { icon: typeof Globe; title: string; color: string }) {
  return (
    <div className="mb-3 flex items-center gap-2">
      <span className={cn("flex h-8 w-8 items-center justify-center rounded-full", color)}>
        <Icon className="h-4 w-4" />
      </span>
      <h2 className="text-lg font-bold text-foreground">{title}</h2>
    </div>
  )
}

function ToggleRow({
  icon: Icon,
  label,
  description,
  checked,
  onChange,
  color,
}: {
  icon: typeof Volume2
  label: string
  description: string
  checked: boolean
  onChange: (v: boolean) => void
  color: string
}) {
  return (
    <div className="flex items-center justify-between gap-3 py-1">
      <div className="flex items-center gap-3">
        <span className={cn("flex h-10 w-10 items-center justify-center rounded-full", color)}>
          <Icon className="h-5 w-5" />
        </span>
        <div>
          <p className="font-semibold text-foreground">{label}</p>
          <p className="text-sm text-muted-foreground">{description}</p>
        </div>
      </div>
      <Switch checked={checked} onCheckedChange={onChange} />
    </div>
  )
}

export default function SettingsPage() {
  const [language, setLanguage] = useState("PT")
  const [timer, setTimer] = useState([30])
  const [range, setRange] = useState([10])
  const [sound, setSound] = useState(true)
  const [music, setMusic] = useState(false)
  const [notifications, setNotifications] = useState(true)

  return (
    <div className="flex min-h-dvh flex-col bg-background font-sans">
      <ScreenHeader subtitle="Math Hero Kids" title="Ajustes" />

      <main className="mx-auto w-full max-w-md flex-1 space-y-4 px-5 py-6">
        {/* Language */}
        <Card className="p-5">
          <SectionTitle icon={Globe} title="Idioma" color="bg-primary/10 text-primary" />
          <div className="grid grid-cols-2 gap-3">
            {languages.map((lang) => {
              const selected = language === lang.code
              return (
                <button
                  key={lang.code}
                  type="button"
                  onClick={() => setLanguage(lang.code)}
                  className={cn(
                    "flex items-center justify-between rounded-2xl border-2 px-4 py-3 text-left transition-colors",
                    selected
                      ? "border-primary bg-primary/5"
                      : "border-border bg-card hover:border-primary/40",
                  )}
                >
                  <span className="flex items-center gap-2">
                    <span className="text-xl" aria-hidden>
                      {lang.flag}
                    </span>
                    <span className="text-sm font-semibold text-foreground">{lang.code}</span>
                  </span>
                  {selected ? (
                    <span className="flex h-5 w-5 items-center justify-center rounded-full bg-primary text-primary-foreground">
                      <Check className="h-3 w-3" />
                    </span>
                  ) : null}
                </button>
              )
            })}
          </div>
        </Card>

        {/* Question timer */}
        <Card className="p-5">
          <SectionTitle icon={Timer} title="Tempo por questão" color="bg-secondary/15 text-secondary" />
          <div className="flex items-baseline justify-between">
            <p className="text-sm text-muted-foreground">Tempo limite para cada pergunta</p>
            <p className="text-2xl font-extrabold text-secondary">{timer[0]}s</p>
          </div>
          <Slider
            value={timer}
            onValueChange={setTimer}
            min={10}
            max={60}
            step={5}
            className="mt-4"
            aria-label="Tempo por questão"
          />
          <div className="mt-1 flex justify-between text-xs text-muted-foreground">
            <span>10s</span>
            <span>60s</span>
          </div>
        </Card>

        {/* Multiplication range */}
        <Card className="p-5">
          <SectionTitle icon={X} title="Tabuada" color="bg-success/15 text-success" />
          <div className="flex items-baseline justify-between">
            <p className="text-sm text-muted-foreground">Multiplicar até</p>
            <p className="text-2xl font-extrabold text-success">{range[0]}</p>
          </div>
          <Slider
            value={range}
            onValueChange={setRange}
            min={2}
            max={12}
            step={1}
            className="mt-4"
            aria-label="Faixa de multiplicação"
          />
          <div className="mt-1 flex justify-between text-xs text-muted-foreground">
            <span>2</span>
            <span>12</span>
          </div>
        </Card>

        {/* Audio & notifications */}
        <Card className="space-y-2 p-5">
          <SectionTitle icon={Volume2} title="Som e notificações" color="bg-warning/20 text-warning-foreground" />
          <ToggleRow
            icon={Volume2}
            label="Efeitos sonoros"
            description="Sons de acertos e recompensas"
            checked={sound}
            onChange={setSound}
            color="bg-primary/10 text-primary"
          />
          <ToggleRow
            icon={Music}
            label="Música"
            description="Música de fundo durante os desafios"
            checked={music}
            onChange={setMusic}
            color="bg-secondary/15 text-secondary"
          />
          <ToggleRow
            icon={Bell}
            label="Notificações"
            description="Lembretes diários para praticar"
            checked={notifications}
            onChange={setNotifications}
            color="bg-success/15 text-success"
          />
        </Card>
      </main>

      <BottomNav />
    </div>
  )
}
