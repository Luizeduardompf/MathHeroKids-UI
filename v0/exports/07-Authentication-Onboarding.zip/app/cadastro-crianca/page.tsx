"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { AuthHeader } from "@/components/auth-header"
import { MiloBubble } from "@/components/milo-bubble"
import { ChildProfileForm } from "@/components/child-profile-form"
import { Button } from "@/components/ui/button"
import { PartyPopper, Plus } from "lucide-react"

export default function ChildRegistrationPage() {
  const [done, setDone] = useState(false)

  return (
    <div className="flex min-h-dvh flex-col bg-background font-sans">
      <AuthHeader subtitle="Passo 2 de 2" title="Perfil da criança" backHref="/cadastro-pais" />

      <main className="mx-auto w-full max-w-md flex-1 px-5 py-6">
        {done ? (
          <div className="flex flex-col items-center text-center">
            <div className="relative flex h-40 w-40 items-center justify-center rounded-full bg-primary/10">
              <Image
                src="/milo-mascot.png"
                alt="Milo comemorando"
                width={130}
                height={130}
                className="h-32 w-32 object-contain"
              />
              <span className="absolute -right-1 top-2 flex h-12 w-12 items-center justify-center rounded-full bg-warning text-warning-foreground">
                <PartyPopper className="h-6 w-6" />
              </span>
            </div>
            <h2 className="mt-6 text-3xl font-extrabold text-foreground">Tudo pronto!</h2>
            <p className="mt-2 text-pretty text-muted-foreground">
              O perfil foi criado com sucesso. Você pode adicionar mais crianças ou começar a jogar agora.
            </p>

            <div className="mt-8 w-full space-y-3">
              <Button render={<Link href="/perfis" />} size="lg" className="h-14 w-full rounded-full text-lg font-bold">
                Começar a jogar
              </Button>
              <Button
                onClick={() => setDone(false)}
                size="lg"
                variant="outline"
                className="h-14 w-full rounded-full border-2 text-lg font-bold"
              >
                <Plus className="h-5 w-5" />
                Adicionar outra criança
              </Button>
            </div>
          </div>
        ) : (
          <>
            <MiloBubble
              variant="secondary"
              message="Agora vamos criar o herói da matemática! Escolha um avatar e preencha os dados."
            />
            <div className="mt-5">
              <ChildProfileForm submitLabel="Criar perfil" onSubmit={() => setDone(true)} />
            </div>
            <p className="mt-4 text-center text-xs text-muted-foreground">
              Você poderá adicionar mais crianças depois, na área dos pais.
            </p>
          </>
        )}
      </main>
    </div>
  )
}
