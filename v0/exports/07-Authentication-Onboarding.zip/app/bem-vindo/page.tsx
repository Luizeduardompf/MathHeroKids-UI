import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Sparkles, Star, Trophy } from "lucide-react"

export default function WelcomePage() {
  return (
    <div className="flex min-h-dvh flex-col bg-primary font-sans text-primary-foreground">
      <main className="mx-auto flex w-full max-w-md flex-1 flex-col items-center px-6 pb-8 pt-14 text-center">
        {/* Mascot */}
        <div className="relative">
          <span className="absolute -left-4 top-2 text-warning">
            <Star className="h-6 w-6 fill-current" />
          </span>
          <span className="absolute -right-3 top-8 text-primary-foreground/70">
            <Sparkles className="h-7 w-7" />
          </span>
          <div className="flex h-44 w-44 items-center justify-center rounded-full bg-primary-foreground/10 ring-8 ring-primary-foreground/5">
            <Image
              src="/milo-mascot.png"
              alt="Milo, o mago da matemática"
              width={160}
              height={160}
              className="h-40 w-40 object-contain drop-shadow-lg"
              priority
            />
          </div>
        </div>

        <h1 className="mt-8 text-balance text-4xl font-extrabold tracking-tight">Math Hero Kids</h1>
        <p className="mt-3 text-pretty text-lg font-medium text-primary-foreground/80">
          Aprenda matemática brincando com o Milo! Desafios divertidos, troféus e muita diversão.
        </p>

        {/* Feature pills */}
        <ul className="mt-8 flex w-full flex-col gap-3 text-left">
          <li className="flex items-center gap-3 rounded-2xl bg-primary-foreground/10 px-4 py-3">
            <span className="flex h-10 w-10 items-center justify-center rounded-full bg-warning text-warning-foreground">
              <Trophy className="h-5 w-5" />
            </span>
            <span className="font-semibold">Ganhe troféus e suba de nível</span>
          </li>
          <li className="flex items-center gap-3 rounded-2xl bg-primary-foreground/10 px-4 py-3">
            <span className="flex h-10 w-10 items-center justify-center rounded-full bg-secondary text-secondary-foreground">
              <Sparkles className="h-5 w-5" />
            </span>
            <span className="font-semibold">Desafios diários com o Milo</span>
          </li>
          <li className="flex items-center gap-3 rounded-2xl bg-primary-foreground/10 px-4 py-3">
            <span className="flex h-10 w-10 items-center justify-center rounded-full bg-success text-success-foreground">
              <Star className="h-5 w-5 fill-current" />
            </span>
            <span className="font-semibold">Vários perfis para a família toda</span>
          </li>
        </ul>

        {/* Actions */}
        <div className="mt-auto w-full space-y-3 pt-10">
          <Button
            render={<Link href="/cadastro-pais" />}
            size="lg"
            className="h-14 w-full rounded-full bg-card text-lg font-bold text-primary hover:bg-card/90"
          >
            Começar agora
          </Button>
          <Button
            render={<Link href="/login" />}
            size="lg"
            variant="ghost"
            className="h-14 w-full rounded-full text-lg font-bold text-primary-foreground hover:bg-primary-foreground/10 hover:text-primary-foreground"
          >
            Já tenho uma conta
          </Button>
        </div>
      </main>
    </div>
  )
}
