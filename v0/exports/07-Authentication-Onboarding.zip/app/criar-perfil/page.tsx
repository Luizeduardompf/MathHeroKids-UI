"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { AuthHeader } from "@/components/auth-header"
import { MiloBubble } from "@/components/milo-bubble"
import { ChildProfileForm } from "@/components/child-profile-form"

export default function CreateChildProfilePage() {
  const router = useRouter()
  const [saving, setSaving] = useState(false)

  return (
    <div className="flex min-h-dvh flex-col bg-background font-sans">
      <AuthHeader subtitle="Área dos pais" title="Nova criança" backHref="/perfis" />

      <main className="mx-auto w-full max-w-md flex-1 px-5 py-6">
        <MiloBubble
          variant="success"
          message="Mais um herói chegando! Preencha os dados para criar o novo perfil."
        />
        <div className="mt-5">
          <ChildProfileForm
            submitLabel={saving ? "Salvando..." : "Salvar perfil"}
            onSubmit={() => {
              setSaving(true)
              setTimeout(() => router.push("/perfis"), 600)
            }}
          />
        </div>
      </main>
    </div>
  )
}
