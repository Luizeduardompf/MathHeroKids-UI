"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Home, Calendar, Swords, Users, Settings } from "lucide-react"
import { cn } from "@/lib/utils"

const items = [
  { href: "/", label: "Início", icon: Home },
  { href: "/calendario", label: "Calendário", icon: Calendar },
  { href: "/desafio", label: "Desafio", icon: Swords, center: true },
  { href: "/amigos", label: "Amigos", icon: Users },
  { href: "/ajustes", label: "Ajustes", icon: Settings },
]

export function BottomNav() {
  const pathname = usePathname()

  return (
    <nav className="sticky bottom-0 z-20 mt-auto border-t border-border bg-card">
      <ul className="mx-auto flex max-w-md items-end justify-between px-4 py-2">
        {items.map(({ href, label, icon: Icon, center }) => {
          const active = pathname === href
          if (center) {
            return (
              <li key={href} className="flex flex-col items-center">
                <Link
                  href={href}
                  className="flex h-14 w-14 -translate-y-3 items-center justify-center rounded-full bg-secondary text-secondary-foreground shadow-lg ring-4 ring-card"
                  aria-label={label}
                >
                  <Icon className="h-6 w-6" />
                </Link>
                <span className="-mt-1 text-xs font-semibold text-secondary">{label}</span>
              </li>
            )
          }
          return (
            <li key={href}>
              <Link
                href={href}
                className={cn(
                  "flex flex-col items-center gap-1 px-2 py-1 text-xs font-medium",
                  active ? "text-primary" : "text-muted-foreground",
                )}
              >
                <Icon className="h-6 w-6" />
                <span className={cn(active && "font-bold")}>{label}</span>
              </Link>
            </li>
          )
        })}
      </ul>
    </nav>
  )
}
