import type { ReactNode } from "react"

export function ScreenHeader({
  title,
  subtitle,
  action,
}: {
  title: string
  subtitle?: string
  action?: ReactNode
}) {
  return (
    <header className="bg-primary px-5 pb-6 pt-8 text-primary-foreground">
      <div className="mx-auto flex max-w-md items-start justify-between gap-3">
        <div className="min-w-0">
          {subtitle ? (
            <p className="text-sm font-semibold text-primary-foreground/70">{subtitle}</p>
          ) : null}
          <h1 className="text-balance text-3xl font-extrabold tracking-tight">{title}</h1>
        </div>
        {action ? <div className="shrink-0">{action}</div> : null}
      </div>
    </header>
  )
}
