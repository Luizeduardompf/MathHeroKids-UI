import Link from "next/link"
import { ChevronLeft } from "lucide-react"

export function AuthHeader({
  title,
  subtitle,
  backHref,
}: {
  title: string
  subtitle?: string
  backHref: string
}) {
  return (
    <header className="bg-primary px-5 pb-8 pt-8 text-primary-foreground">
      <div className="mx-auto flex max-w-md items-center gap-3">
        <Link
          href={backHref}
          className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary-foreground/15 transition-colors hover:bg-primary-foreground/25"
          aria-label="Voltar"
        >
          <ChevronLeft className="h-6 w-6" />
        </Link>
        <div className="min-w-0">
          {subtitle ? (
            <p className="text-sm font-semibold text-primary-foreground/70">{subtitle}</p>
          ) : null}
          <h1 className="text-balance text-2xl font-extrabold tracking-tight">{title}</h1>
        </div>
      </div>
    </header>
  )
}
