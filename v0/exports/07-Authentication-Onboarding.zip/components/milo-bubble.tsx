import Image from "next/image"

export function MiloBubble({
  message,
  variant = "primary",
}: {
  message: string
  variant?: "primary" | "secondary" | "success" | "destructive"
}) {
  const bg =
    variant === "secondary"
      ? "bg-secondary"
      : variant === "success"
        ? "bg-success"
        : variant === "destructive"
          ? "bg-destructive"
          : "bg-primary"

  return (
    <div className={`flex items-center gap-3 rounded-3xl ${bg} p-3 pr-4`}>
      <span className="flex h-14 w-14 shrink-0 items-center justify-center overflow-hidden rounded-full bg-card">
        <Image
          src="/milo-mascot.png"
          alt="Milo, o mago"
          width={56}
          height={56}
          className="h-14 w-14 object-cover"
        />
      </span>
      <div className="rounded-2xl bg-card px-4 py-2.5">
        <p className="text-xs font-bold uppercase tracking-wide text-muted-foreground">Milo diz</p>
        <p className="text-pretty font-bold leading-snug text-foreground">{message}</p>
      </div>
    </div>
  )
}
