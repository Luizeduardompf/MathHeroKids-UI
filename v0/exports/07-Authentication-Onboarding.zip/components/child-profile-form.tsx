"use client"

import { useState } from "react"
import Image from "next/image"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { avatarOptions } from "@/lib/mock-data"
import { cn } from "@/lib/utils"
import { User, Lock, Cake, Check } from "lucide-react"

export function ChildProfileForm({
  submitLabel,
  onSubmit,
}: {
  submitLabel: string
  onSubmit?: () => void
}) {
  const [selectedAvatar, setSelectedAvatar] = useState(avatarOptions[0].id)

  return (
    <form
      className="space-y-5"
      onSubmit={(e) => {
        e.preventDefault()
        onSubmit?.()
      }}
    >
      {/* Avatar selection */}
      <Card className="p-5">
        <Label className="font-semibold">Escolha o avatar</Label>
        <div className="mt-3 grid grid-cols-3 gap-3">
          {avatarOptions.map((avatar) => {
            const active = avatar.id === selectedAvatar
            return (
              <button
                key={avatar.id}
                type="button"
                onClick={() => setSelectedAvatar(avatar.id)}
                className="relative flex items-center justify-center"
                aria-label={`Avatar ${avatar.id}`}
                aria-pressed={active}
              >
                <span
                  className={cn(
                    "flex h-20 w-20 items-center justify-center rounded-full p-1 transition-all",
                    active ? "ring-4" : "ring-2 ring-border",
                  )}
                  style={active ? { backgroundColor: avatar.color, boxShadow: `0 0 0 4px ${avatar.color}33` } : undefined}
                >
                  <Image
                    src={avatar.src || "/placeholder.svg"}
                    alt={`Avatar ${avatar.id}`}
                    width={72}
                    height={72}
                    className="h-[72px] w-[72px] rounded-full border-2 border-card object-cover"
                  />
                </span>
                {active ? (
                  <span className="absolute -bottom-1 -right-0 flex h-7 w-7 items-center justify-center rounded-full bg-primary text-primary-foreground ring-2 ring-card">
                    <Check className="h-4 w-4" />
                  </span>
                ) : null}
              </button>
            )
          })}
        </div>
      </Card>

      <Card className="space-y-5 p-5">
        {/* Child name */}
        <div className="space-y-2">
          <Label htmlFor="child-name" className="font-semibold">
            Nome da criança
          </Label>
          <div className="relative">
            <User className="pointer-events-none absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
            <Input
              id="child-name"
              type="text"
              placeholder="ex: Sofia"
              className="h-12 rounded-xl pl-11 text-base"
            />
          </div>
        </div>

        {/* Username */}
        <div className="space-y-2">
          <Label htmlFor="child-username" className="font-semibold">
            Nome de usuário
          </Label>
          <div className="relative">
            <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-base font-bold text-muted-foreground">
              @
            </span>
            <Input
              id="child-username"
              type="text"
              autoComplete="username"
              placeholder="sofia_hero"
              className="h-12 rounded-xl pl-9 text-base"
            />
          </div>
          <p className="text-xs text-muted-foreground">A criança usa este nome para entrar no app.</p>
        </div>

        {/* Birth date */}
        <div className="space-y-2">
          <Label htmlFor="child-birth" className="font-semibold">
            Data de nascimento
          </Label>
          <div className="relative">
            <Cake className="pointer-events-none absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
            <Input
              id="child-birth"
              type="date"
              className="h-12 rounded-xl pl-11 text-base"
            />
          </div>
          <p className="text-xs text-muted-foreground">Usamos para ajustar a dificuldade dos desafios.</p>
        </div>

        {/* Child password */}
        <div className="space-y-2">
          <Label htmlFor="child-password" className="font-semibold">
            Senha da criança
          </Label>
          <div className="relative">
            <Lock className="pointer-events-none absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
            <Input
              id="child-password"
              type="password"
              autoComplete="new-password"
              placeholder="Senha simples e fácil de lembrar"
              className="h-12 rounded-xl pl-11 text-base"
            />
          </div>
        </div>
      </Card>

      <Button type="submit" size="lg" className="h-14 w-full rounded-full text-lg font-bold">
        {submitLabel}
      </Button>
    </form>
  )
}
