import { Trophy as TrophyIcon, Lock } from "lucide-react"
import { cn } from "@/lib/utils"
import type { Rarity } from "@/lib/gamification-data"

export const rarityStyles: Record<
  Rarity,
  { label: string; ring: string; bg: string; icon: string; chip: string }
> = {
  bronze: {
    label: "Bronze",
    ring: "ring-orange/40",
    bg: "bg-orange-soft",
    icon: "text-orange",
    chip: "bg-orange-soft text-orange",
  },
  prata: {
    label: "Prata",
    ring: "ring-muted-foreground/30",
    bg: "bg-muted",
    icon: "text-muted-foreground",
    chip: "bg-muted text-muted-foreground",
  },
  ouro: {
    label: "Ouro",
    ring: "ring-gold/50",
    bg: "bg-gold-soft",
    icon: "text-gold",
    chip: "bg-gold-soft text-gold-foreground",
  },
  diamante: {
    label: "Diamante",
    ring: "ring-brand/40",
    bg: "bg-brand-soft",
    icon: "text-brand",
    chip: "bg-brand-soft text-brand",
  },
}

type TrophyMedalProps = {
  rarity: Rarity
  earned: boolean
  size?: "sm" | "md" | "lg"
  className?: string
}

const sizes = {
  sm: { box: "size-14", icon: "size-7" },
  md: { box: "size-20", icon: "size-10" },
  lg: { box: "size-36", icon: "size-20" },
}

export function TrophyMedal({ rarity, earned, size = "md", className }: TrophyMedalProps) {
  const style = rarityStyles[rarity]
  const s = sizes[size]
  return (
    <div
      className={cn(
        "flex shrink-0 items-center justify-center rounded-full ring-4",
        earned ? style.bg : "bg-muted",
        earned ? style.ring : "ring-border",
        s.box,
        className,
      )}
    >
      {earned ? (
        <TrophyIcon className={cn(s.icon, style.icon)} />
      ) : (
        <Lock className={cn(s.icon, "text-muted-foreground/60")} />
      )}
    </div>
  )
}
