"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Home, Calendar, Swords, Users, Settings } from "lucide-react"
import { cn } from "@/lib/utils"

const items = [
  { href: "/home", label: "Início", icon: Home },
  { href: "/calendario", label: "Calendário", icon: Calendar },
  { href: "/desafio", label: "Desafio", icon: Swords, highlight: true },
  { href: "/amigos", label: "Amigos", icon: Users },
  { href: "/ajustes", label: "Ajustes", icon: Settings },
]

export function BottomNav() {
  const pathname = usePathname()

  return (
    <nav className="sticky bottom-0 z-20 border-t border-border bg-card px-2 pb-2 pt-2">
      <ul className="flex items-end justify-between">
        {items.map((item) => {
          const Icon = item.icon
          const active = pathname === item.href
          if (item.highlight) {
            return (
              <li key={item.href} className="flex-1">
                <Link href={item.href} className="flex flex-col items-center gap-1">
                  <span className="flex size-14 -translate-y-3 items-center justify-center rounded-full bg-orange text-orange-foreground shadow-lg shadow-orange/40">
                    <Icon className="size-6" />
                  </span>
                  <span className="-mt-2 text-xs font-bold text-orange">{item.label}</span>
                </Link>
              </li>
            )
          }
          return (
            <li key={item.href} className="flex-1">
              <Link
                href={item.href}
                className={cn(
                  "flex flex-col items-center gap-1 py-1 text-xs font-bold",
                  active ? "text-brand" : "text-muted-foreground",
                )}
              >
                <Icon className="size-6" />
                {item.label}
              </Link>
            </li>
          )
        })}
      </ul>
    </nav>
  )
}
