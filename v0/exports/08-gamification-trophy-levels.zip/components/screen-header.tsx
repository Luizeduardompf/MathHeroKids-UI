import Link from "next/link"
import { ChevronLeft } from "lucide-react"
import { cn } from "@/lib/utils"

type ScreenHeaderProps = {
  eyebrow?: string
  title: string
  backHref?: string
  className?: string
}

export function ScreenHeader({ eyebrow, title, backHref, className }: ScreenHeaderProps) {
  return (
    <header
      className={cn(
        "bg-brand text-brand-foreground rounded-b-[2rem] px-5 pb-7 pt-6 shadow-lg shadow-brand/20",
        className,
      )}
    >
      <div className="flex items-center gap-3">
        {backHref && (
          <Link
            href={backHref}
            aria-label="Voltar"
            className="flex size-11 shrink-0 items-center justify-center rounded-full bg-white/20 transition-colors hover:bg-white/30"
          >
            <ChevronLeft className="size-6" />
          </Link>
        )}
        <div className="min-w-0">
          {eyebrow && (
            <p className="text-sm font-bold tracking-wide text-white/75">{eyebrow}</p>
          )}
          <h1 className="text-pretty text-3xl font-extrabold leading-tight">{title}</h1>
        </div>
      </div>
    </header>
  )
}
