import Image from "next/image"
import { cn } from "@/lib/utils"

type MiloBubbleProps = {
  message: string
  tone?: "brand" | "orange"
  className?: string
}

export function MiloBubble({ message, tone = "brand", className }: MiloBubbleProps) {
  return (
    <div
      className={cn(
        "flex items-center gap-3 rounded-3xl p-3 shadow-md",
        tone === "brand" ? "bg-brand text-brand-foreground" : "bg-orange text-orange-foreground",
        className,
      )}
    >
      <div className="flex size-16 shrink-0 items-center justify-center overflow-hidden rounded-full bg-white">
        <Image src="/milo.png" alt="Milo, o mago da matemática" width={64} height={64} className="size-full object-cover" />
      </div>
      <div className="min-w-0 flex-1 rounded-2xl bg-white px-4 py-3 text-foreground">
        <p className="text-xs font-extrabold uppercase tracking-wide text-muted-foreground">Milo diz</p>
        <p className="text-pretty text-base font-bold leading-snug">{message}</p>
      </div>
    </div>
  )
}
