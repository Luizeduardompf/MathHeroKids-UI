export type Rarity = "bronze" | "prata" | "ouro" | "diamante"

export type TrophyCategory = "diario" | "semanal" | "mensal" | "sequencia" | "especial"

export type Trophy = {
  id: string
  name: string
  category: TrophyCategory
  rarity: Rarity
  description: string
  howToEarn: string
  earned: boolean
  dateEarned?: string
  progress?: { current: number; total: number }
}

export const trophies: Trophy[] = [
  {
    id: "diario-1",
    name: "Troféu Diário",
    category: "diario",
    rarity: "bronze",
    description: "Complete o desafio do dia para ganhar este troféu.",
    howToEarn: "Termine 1 desafio diário com o Milo.",
    earned: true,
    dateEarned: "17 de junho de 2026",
  },
  {
    id: "semanal-1",
    name: "Troféu Semanal",
    category: "semanal",
    rarity: "prata",
    description: "Jogue todos os dias por 7 dias seguidos.",
    howToEarn: "Mantenha sua sequência por uma semana inteira.",
    earned: true,
    dateEarned: "15 de junho de 2026",
  },
  {
    id: "mensal-1",
    name: "Troféu Mensal",
    category: "mensal",
    rarity: "ouro",
    description: "Um mês inteiro de matemática sem falhar!",
    howToEarn: "Complete os desafios todos os dias do mês.",
    earned: false,
    progress: { current: 18, total: 30 },
  },
  {
    id: "sequencia-1",
    name: "Sequência de Fogo",
    category: "sequencia",
    rarity: "ouro",
    description: "Sua sequência está pegando fogo!",
    howToEarn: "Alcance uma sequência de 10 dias.",
    earned: false,
    progress: { current: 8, total: 10 },
  },
  {
    id: "semana-perfeita",
    name: "Semana Perfeita",
    category: "especial",
    rarity: "diamante",
    description: "7 dias seguidos sem errar nenhuma resposta.",
    howToEarn: "Acerte 100% dos desafios por 7 dias.",
    earned: true,
    dateEarned: "10 de junho de 2026",
  },
  {
    id: "mes-perfeito",
    name: "Mês Perfeito",
    category: "especial",
    rarity: "diamante",
    description: "O troféu mais raro de todos: um mês impecável.",
    howToEarn: "Acerte 100% dos desafios o mês inteiro.",
    earned: false,
    progress: { current: 12, total: 30 },
  },
  {
    id: "campeao",
    name: "Campeão",
    category: "especial",
    rarity: "ouro",
    description: "Termine no topo do ranking da semana.",
    howToEarn: "Seja o número 1 entre seus amigos.",
    earned: false,
    progress: { current: 2, total: 1 },
  },
  {
    id: "diario-bronze-2",
    name: "Madrugador",
    category: "diario",
    rarity: "bronze",
    description: "Comece o desafio bem cedinho.",
    howToEarn: "Complete um desafio antes das 9h.",
    earned: false,
    progress: { current: 0, total: 1 },
  },
]

export type Achievement = {
  id: string
  name: string
  description: string
  category: string
  earned: boolean
  icon: "star" | "flame" | "zap" | "crown" | "target" | "calendar" | "medal" | "sparkle"
}

export const achievements: Achievement[] = [
  {
    id: "first-perfect-day",
    name: "Primeiro Dia Perfeito",
    description: "Acertou todas as respostas em um dia.",
    category: "Primeiros passos",
    earned: true,
    icon: "star",
  },
  {
    id: "7-day-streak",
    name: "Sequência de 7 Dias",
    description: "Jogou 7 dias seguidos sem parar.",
    category: "Sequências",
    earned: true,
    icon: "flame",
  },
  {
    id: "30-day-streak",
    name: "Sequência de 30 Dias",
    description: "Um mês inteiro de dedicação!",
    category: "Sequências",
    earned: false,
    icon: "calendar",
  },
  {
    id: "mult-master",
    name: "Mestre da Multiplicação",
    description: "Dominou a tabuada toda.",
    category: "Habilidades",
    earned: true,
    icon: "crown",
  },
  {
    id: "speed-champion",
    name: "Campeão da Velocidade",
    description: "Respondeu super rápido sem errar.",
    category: "Habilidades",
    earned: false,
    icon: "zap",
  },
  {
    id: "perfect-week",
    name: "Semana Perfeita",
    description: "7 dias sem errar nenhuma resposta.",
    category: "Especiais",
    earned: true,
    icon: "medal",
  },
  {
    id: "perfect-month",
    name: "Mês Perfeito",
    description: "Um mês inteiro impecável.",
    category: "Especiais",
    earned: false,
    icon: "sparkle",
  },
  {
    id: "first-access",
    name: "Primeiro Acesso",
    description: "Bem-vindo ao app!",
    category: "Primeiros passos",
    earned: true,
    icon: "target",
  },
]

export type LevelReward = {
  type: "Roupa do Milo" | "Moldura" | "Medalha" | "Variante de Troféu" | "Comemoração"
  name: string
}

export type LevelMilestone = {
  level: number
  title: string
  xpRequired: number
  reward: LevelReward
  status: "unlocked" | "current" | "locked"
}

export const currentLevel = 12
export const currentXp = 1450
export const nextLevelXp = 2000

export const levelMilestones: LevelMilestone[] = [
  { level: 10, title: "Explorador", xpRequired: 1200, reward: { type: "Moldura", name: "Moldura Estrelas" }, status: "unlocked" },
  { level: 11, title: "Aventureiro", xpRequired: 1600, reward: { type: "Roupa do Milo", name: "Capa Mágica" }, status: "unlocked" },
  { level: 12, title: "Herói da Matemática", xpRequired: 2000, reward: { type: "Medalha", name: "Medalha de Prata" }, status: "current" },
  { level: 13, title: "Mago Aprendiz", xpRequired: 2500, reward: { type: "Variante de Troféu", name: "Troféu Brilhante" }, status: "locked" },
  { level: 15, title: "Mestre dos Números", xpRequired: 3500, reward: { type: "Roupa do Milo", name: "Chapéu Galáctico" }, status: "locked" },
  { level: 20, title: "Lenda Matemática", xpRequired: 6000, reward: { type: "Comemoração", name: "Fogos Dourados" }, status: "locked" },
]

export const levelRewards: { level: number; reward: LevelReward; status: "unlocked" | "locked" }[] = [
  { level: 10, reward: { type: "Moldura", name: "Moldura Estrelas" }, status: "unlocked" },
  { level: 11, reward: { type: "Roupa do Milo", name: "Capa Mágica" }, status: "unlocked" },
  { level: 12, reward: { type: "Medalha", name: "Medalha de Prata" }, status: "unlocked" },
  { level: 13, reward: { type: "Variante de Troféu", name: "Troféu Brilhante" }, status: "locked" },
  { level: 14, reward: { type: "Moldura", name: "Moldura Arco-íris" }, status: "locked" },
  { level: 15, reward: { type: "Roupa do Milo", name: "Chapéu Galáctico" }, status: "locked" },
  { level: 18, reward: { type: "Medalha", name: "Medalha de Ouro" }, status: "locked" },
  { level: 20, reward: { type: "Comemoração", name: "Fogos Dourados" }, status: "locked" },
]
