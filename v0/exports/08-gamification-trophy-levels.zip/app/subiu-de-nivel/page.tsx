import Image from "next/image"
import Link from "next/link"
import { Star, Frame } from "lucide-react"
import { Confetti } from "@/components/confetti"

const newLevel = 13

export default function LevelUpPage() {
  return (
    <div className="relative mx-auto flex min-h-screen w-full max-w-md flex-col items-center justify-between overflow-hidden bg-brand px-6 py-10 text-center text-brand-foreground">
      <Confetti count={70} />

      <div className="relative z-10 flex flex-1 flex-col items-center justify-center gap-6">
        <p className="animate-pop-in text-2xl font-extrabold uppercase tracking-widest text-warning">
          Você subiu de nível!
        </p>

        {/* Badge do novo nível */}
        <div className="relative flex items-center justify-center">
          <span className="absolute inline-flex size-44 rounded-full bg-white/20 animate-pulse-ring" />
          <div className="animate-pop-in relative flex size-36 items-center justify-center rounded-full bg-warning text-warning-foreground ring-8 ring-white/30">
            <span className="text-6xl font-extrabold">{newLevel}</span>
            <Star className="absolute -right-2 -top-2 size-10 fill-white text-white" />
          </div>
        </div>

        <div>
          <h1 className="text-pretty text-4xl font-extrabold leading-tight">Mago Aprendiz</h1>
          <p className="mt-1 text-lg font-bold text-white/85">Nível {newLevel} alcançado</p>
        </div>

        {/* Milo comemorando */}
        <div className="animate-float-soft flex size-36 items-center justify-center overflow-hidden rounded-full bg-white/15">
          <Image
            src="/milo-celebrate.png"
            alt="Milo comemorando"
            width={144}
            height={144}
            className="size-full object-cover"
          />
        </div>

        <div className="w-full rounded-3xl bg-white px-5 py-4 text-foreground shadow-lg">
          <p className="text-xs font-extrabold uppercase tracking-wide text-muted-foreground">Milo diz</p>
          <p className="text-pretty text-lg font-extrabold leading-snug">
            Incrível! Você é demais na matemática! Continue assim, herói!
          </p>
        </div>

        {/* Recompensa desbloqueada */}
        <div className="flex w-full items-center gap-3 rounded-3xl bg-white/15 p-4 text-left ring-1 ring-white/25">
          <span className="flex size-14 shrink-0 items-center justify-center rounded-2xl bg-warning text-warning-foreground">
            <Frame className="size-7" />
          </span>
          <div>
            <p className="text-sm font-bold uppercase tracking-wide text-white/80">Recompensa desbloqueada</p>
            <p className="text-lg font-extrabold">Troféu Brilhante</p>
          </div>
        </div>
      </div>

      <div className="relative z-10 w-full">
        <Link
          href="/niveis"
          className="block rounded-full bg-white py-4 text-center text-lg font-extrabold text-brand shadow-lg transition-transform active:scale-[0.98]"
        >
          Continuar
        </Link>
      </div>
    </div>
  )
}
