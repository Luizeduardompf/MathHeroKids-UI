import { Shirt, Frame, Medal, Trophy, PartyPopper, Lock, Check } from "lucide-react"
import { ScreenHeader } from "@/components/screen-header"
import { MiloBubble } from "@/components/milo-bubble"
import { BottomNav } from "@/components/bottom-nav"
import { currentLevel, levelRewards, type LevelReward } from "@/lib/gamification-data"
import { cn } from "@/lib/utils"

const rewardIcon = {
  "Roupa do Milo": Shirt,
  Moldura: Frame,
  Medalha: Medal,
  "Variante de Troféu": Trophy,
  Comemoração: PartyPopper,
} as const

function RewardIcon({ reward, className }: { reward: LevelReward; className?: string }) {
  const Icon = rewardIcon[reward.type]
  return <Icon className={className} />
}

export default function LevelRewardsPage() {
  const unlocked = levelRewards.filter((r) => r.status === "unlocked")
  const locked = levelRewards.filter((r) => r.status === "locked")

  return (
    <div className="mx-auto flex min-h-screen w-full max-w-md flex-col bg-background">
      <ScreenHeader eyebrow="Math Hero Kids" title="Recompensas" backHref="/" />

      <main className="flex flex-1 flex-col gap-5 px-4 py-5">
        <MiloBubble message="Suba de nível para liberar roupas, molduras e muito mais!" />

        {/* Desbloqueadas */}
        <section>
          <h2 className="mb-3 text-xl font-extrabold text-foreground">Desbloqueadas</h2>
          <div className="grid grid-cols-2 gap-3">
            {unlocked.map((r) => (
              <div
                key={`${r.level}-${r.reward.name}`}
                className="flex flex-col items-center gap-2 rounded-3xl bg-card p-4 text-center shadow-sm ring-1 ring-border"
              >
                <span className="relative flex size-16 items-center justify-center rounded-2xl bg-success-soft text-success">
                  <RewardIcon reward={r.reward} className="size-8" />
                  <span className="absolute -bottom-1 -right-1 flex size-6 items-center justify-center rounded-full bg-success text-success-foreground ring-2 ring-card">
                    <Check className="size-4" />
                  </span>
                </span>
                <span className="text-sm font-extrabold leading-tight text-foreground">{r.reward.name}</span>
                <span className="rounded-full bg-success-soft px-2 py-0.5 text-[10px] font-extrabold text-success">
                  Nível {r.level}
                </span>
              </div>
            ))}
          </div>
        </section>

        {/* Futuras / bloqueadas */}
        <section>
          <h2 className="mb-3 text-xl font-extrabold text-foreground">Próximas recompensas</h2>
          <div className="flex flex-col gap-3">
            {locked.map((r) => {
              const levelsAway = r.level - currentLevel
              return (
                <div
                  key={`${r.level}-${r.reward.name}`}
                  className={cn(
                    "flex items-center gap-4 rounded-3xl p-4 shadow-sm ring-1 ring-border",
                    "bg-muted/40",
                  )}
                >
                  <span className="flex size-14 shrink-0 items-center justify-center rounded-2xl bg-muted text-muted-foreground/60">
                    <Lock className="size-6" />
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="font-extrabold text-foreground">{r.reward.name}</p>
                    <p className="text-sm font-bold text-muted-foreground">{r.reward.type}</p>
                  </div>
                  <div className="shrink-0 text-right">
                    <p className="text-lg font-extrabold text-brand">Nível {r.level}</p>
                    <p className="text-xs font-bold text-muted-foreground">
                      {levelsAway > 0 ? `faltam ${levelsAway}` : "disponível"}
                    </p>
                  </div>
                </div>
              )
            })}
          </div>
        </section>

        <div className="flex items-center gap-3 rounded-3xl bg-warning-soft p-4">
          <PartyPopper className="size-7 shrink-0 text-warning-foreground" />
          <p className="text-pretty font-bold text-warning-foreground">
            Continue jogando todos os dias para liberar as recompensas mais raras!
          </p>
        </div>
      </main>

      <BottomNav />
    </div>
  )
}
