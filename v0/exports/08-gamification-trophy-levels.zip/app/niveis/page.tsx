import { Shirt, Frame, Medal, Trophy, PartyPopper, Lock, Check, Star } from "lucide-react"
import { ScreenHeader } from "@/components/screen-header"
import { MiloBubble } from "@/components/milo-bubble"
import { BottomNav } from "@/components/bottom-nav"
import {
  currentLevel,
  currentXp,
  nextLevelXp,
  levelMilestones,
  type LevelReward,
} from "@/lib/gamification-data"
import { cn } from "@/lib/utils"

const rewardIcon = {
  "Roupa do Milo": Shirt,
  Moldura: Frame,
  Medalha: Medal,
  "Variante de Troféu": Trophy,
  Comemoração: PartyPopper,
} as const

function RewardIcon({ reward, className }: { reward: LevelReward; className?: string }) {
  const Icon = rewardIcon[reward.type]
  return <Icon className={className} />
}

export default function LevelProgressionPage() {
  const pct = Math.round((currentXp / nextLevelXp) * 100)

  return (
    <div className="mx-auto flex min-h-screen w-full max-w-md flex-col bg-background">
      <ScreenHeader eyebrow="Math Hero Kids" title="Progressão" backHref="/" />

      <main className="flex flex-1 flex-col gap-5 px-4 py-5">
        {/* Nível atual */}
        <section className="flex flex-col items-center gap-3 rounded-3xl bg-brand p-6 text-center text-brand-foreground shadow-lg shadow-brand/20">
          <div className="relative flex size-24 items-center justify-center rounded-full bg-warning text-warning-foreground ring-4 ring-white/40">
            <span className="text-4xl font-extrabold">{currentLevel}</span>
            <Star className="absolute -right-1 -top-1 size-7 fill-white text-white" />
          </div>
          <div>
            <p className="text-sm font-bold uppercase tracking-wide text-white/80">Nível atual</p>
            <p className="text-2xl font-extrabold">Herói da Matemática</p>
          </div>
          <div className="w-full">
            <div className="flex items-center justify-between text-sm font-bold">
              <span>{currentXp} XP</span>
              <span className="text-white/80">{nextLevelXp}</span>
            </div>
            <div className="mt-1 h-4 overflow-hidden rounded-full bg-white/25">
              <div className="h-full rounded-full bg-white" style={{ width: `${pct}%` }} />
            </div>
            <p className="mt-2 text-sm font-bold text-white/90">
              Faltam {nextLevelXp - currentXp} XP para o nível {currentLevel + 1}
            </p>
          </div>
        </section>

        <MiloBubble tone="orange" message="Você está super perto do próximo nível! Bora lá?" />

        {/* Linha do tempo de marcos */}
        <section>
          <h2 className="mb-3 text-xl font-extrabold text-foreground">Marcos e recompensas</h2>
          <ol className="relative flex flex-col gap-3 pl-4">
            <span className="absolute bottom-3 left-[1.35rem] top-3 w-1 rounded-full bg-border" />
            {levelMilestones.map((m) => {
              const isCurrent = m.status === "current"
              const isUnlocked = m.status === "unlocked"
              return (
                <li key={m.level} className="relative flex items-center gap-4">
                  <span
                    className={cn(
                      "z-10 flex size-12 shrink-0 items-center justify-center rounded-full font-extrabold ring-4 ring-background",
                      isUnlocked && "bg-success text-success-foreground",
                      isCurrent && "bg-brand text-brand-foreground",
                      m.status === "locked" && "bg-muted text-muted-foreground",
                    )}
                  >
                    {isUnlocked ? <Check className="size-6" /> : m.status === "locked" ? <Lock className="size-5" /> : m.level}
                  </span>
                  <div
                    className={cn(
                      "flex flex-1 items-center gap-3 rounded-3xl p-4 shadow-sm ring-1",
                      isCurrent ? "bg-brand-soft ring-brand/30" : "bg-card ring-border",
                    )}
                  >
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-bold text-muted-foreground">Nível {m.level} · {m.title}</p>
                      <p className="truncate font-extrabold text-foreground">{m.reward.name}</p>
                    </div>
                    <span
                      className={cn(
                        "flex size-11 shrink-0 items-center justify-center rounded-2xl",
                        m.status === "locked" ? "bg-muted text-muted-foreground/60" : "bg-orange-soft text-orange",
                      )}
                    >
                      <RewardIcon reward={m.reward} className="size-6" />
                    </span>
                  </div>
                </li>
              )
            })}
          </ol>
        </section>
      </main>

      <BottomNav />
    </div>
  )
}
