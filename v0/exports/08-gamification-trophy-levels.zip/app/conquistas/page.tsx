import { Star, Flame, Zap, Crown, Target, Calendar, Medal, Sparkles, Lock } from "lucide-react"
import { ScreenHeader } from "@/components/screen-header"
import { MiloBubble } from "@/components/milo-bubble"
import { BottomNav } from "@/components/bottom-nav"
import { achievements, type Achievement } from "@/lib/gamification-data"
import { cn } from "@/lib/utils"

const icons = {
  star: Star,
  flame: Flame,
  zap: Zap,
  crown: Crown,
  target: Target,
  calendar: Calendar,
  medal: Medal,
  sparkle: Sparkles,
}

function AchievementCard({ a }: { a: Achievement }) {
  const Icon = icons[a.icon]
  return (
    <div
      className={cn(
        "flex flex-col items-center gap-2 rounded-3xl p-4 text-center shadow-sm ring-1",
        a.earned ? "bg-card ring-border" : "bg-muted/50 ring-border",
      )}
    >
      <span
        className={cn(
          "flex size-16 items-center justify-center rounded-full",
          a.earned ? "bg-brand-soft text-brand" : "bg-muted text-muted-foreground/60",
        )}
      >
        {a.earned ? <Icon className="size-8" /> : <Lock className="size-7" />}
      </span>
      <span className={cn("text-sm font-extrabold leading-tight", a.earned ? "text-foreground" : "text-muted-foreground")}>
        {a.name}
      </span>
      <span className="text-xs font-semibold leading-tight text-muted-foreground">{a.description}</span>
    </div>
  )
}

export default function AchievementsPage() {
  const earned = achievements.filter((a) => a.earned).length
  const total = achievements.length
  const pct = Math.round((earned / total) * 100)
  const categories = Array.from(new Set(achievements.map((a) => a.category)))

  return (
    <div className="mx-auto flex min-h-screen w-full max-w-md flex-col bg-background">
      <ScreenHeader eyebrow="Math Hero Kids" title="Conquistas" backHref="/" />

      <main className="flex flex-1 flex-col gap-5 px-4 py-5">
        <MiloBubble message="Cada conquista é uma vitória sua! Continue colecionando." />

        {/* Percentual de conclusão */}
        <section className="rounded-3xl bg-card p-5 shadow-sm ring-1 ring-border">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-extrabold text-foreground">Coleção completa</h2>
            <span className="text-2xl font-extrabold text-brand">{pct}%</span>
          </div>
          <div className="mt-3 h-4 overflow-hidden rounded-full bg-muted">
            <div className="h-full rounded-full bg-brand" style={{ width: `${pct}%` }} />
          </div>
          <p className="mt-2 font-bold text-muted-foreground">
            {earned} de {total} conquistas desbloqueadas
          </p>
        </section>

        {categories.map((cat) => (
          <section key={cat}>
            <h2 className="mb-3 text-xl font-extrabold text-foreground">{cat}</h2>
            <div className="grid grid-cols-2 gap-3">
              {achievements
                .filter((a) => a.category === cat)
                .map((a) => (
                  <AchievementCard key={a.id} a={a} />
                ))}
            </div>
          </section>
        ))}
      </main>

      <BottomNav />
    </div>
  )
}
