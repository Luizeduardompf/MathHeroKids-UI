import Link from "next/link"
import Image from "next/image"
import { Trophy, Medal, TrendingUp, Gift, PartyPopper, ChevronRight } from "lucide-react"

const screens = [
  { href: "/trofeus", title: "Sala de Troféus", desc: "Veja todos os troféus conquistados", icon: Trophy, color: "bg-gold-soft text-gold-foreground" },
  { href: "/conquistas", title: "Coleção de Conquistas", desc: "Suas medalhas e distintivos", icon: Medal, color: "bg-brand-soft text-brand" },
  { href: "/niveis", title: "Progressão de Nível", desc: "XP, níveis e marcos", icon: TrendingUp, color: "bg-success-soft text-success" },
  { href: "/recompensas", title: "Recompensas de Nível", desc: "Itens desbloqueados por nível", icon: Gift, color: "bg-orange-soft text-orange" },
  { href: "/subiu-de-nivel", title: "Subiu de Nível!", desc: "Comemoração de novo nível", icon: PartyPopper, color: "bg-warning-soft text-warning-foreground" },
]

export default function Home() {
  return (
    <div className="mx-auto flex min-h-screen w-full max-w-md flex-col bg-background">
      <header className="bg-brand px-5 pb-8 pt-8 text-center text-brand-foreground rounded-b-[2rem] shadow-lg shadow-brand/20">
        <div className="mx-auto mb-3 flex size-24 items-center justify-center overflow-hidden rounded-3xl bg-white/15 animate-float-soft">
          <Image src="/milo.png" alt="Milo" width={96} height={96} className="size-full object-cover" />
        </div>
        <h1 className="text-3xl font-extrabold">Math Hero Kids</h1>
        <p className="mt-1 font-bold text-white/80">Telas de gamificação</p>
      </header>

      <main className="flex flex-1 flex-col gap-3 px-4 py-6">
        {screens.map((s) => {
          const Icon = s.icon
          return (
            <Link
              key={s.href}
              href={s.href}
              className="flex items-center gap-4 rounded-3xl bg-card p-4 shadow-sm ring-1 ring-border transition-transform active:scale-[0.98]"
            >
              <span className={`flex size-14 shrink-0 items-center justify-center rounded-2xl ${s.color}`}>
                <Icon className="size-7" />
              </span>
              <span className="min-w-0 flex-1">
                <span className="block text-lg font-extrabold text-foreground">{s.title}</span>
                <span className="block text-sm font-semibold text-muted-foreground">{s.desc}</span>
              </span>
              <ChevronRight className="size-5 shrink-0 text-muted-foreground" />
            </Link>
          )
        })}
      </main>
    </div>
  )
}
