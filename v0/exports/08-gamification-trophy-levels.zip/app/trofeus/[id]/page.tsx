import Link from "next/link"
import { notFound } from "next/navigation"
import { Calendar, Sparkles } from "lucide-react"
import { ScreenHeader } from "@/components/screen-header"
import { MiloBubble } from "@/components/milo-bubble"
import { TrophyMedal, rarityStyles } from "@/components/trophy-medal"
import { trophies } from "@/lib/gamification-data"

export function generateStaticParams() {
  return trophies.map((t) => ({ id: t.id }))
}

export default async function TrophyDetailPage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = await params
  const trophy = trophies.find((t) => t.id === id)
  if (!trophy) notFound()

  const style = rarityStyles[trophy.rarity]
  const pct = trophy.progress
    ? Math.min(100, Math.round((trophy.progress.current / trophy.progress.total) * 100))
    : 0

  return (
    <div className="mx-auto flex min-h-screen w-full max-w-md flex-col bg-background">
      <ScreenHeader eyebrow="Troféu" title={trophy.name} backHref="/trofeus" />

      <main className="flex flex-1 flex-col gap-5 px-4 py-6">
        {/* Ilustração grande */}
        <div className="flex flex-col items-center gap-4 rounded-3xl bg-card p-8 text-center shadow-sm ring-1 ring-border">
          <div className="relative flex items-center justify-center">
            {trophy.earned && (
              <span className={`absolute inline-flex size-36 rounded-full ${style.bg} animate-pulse-ring`} />
            )}
            <TrophyMedal rarity={trophy.rarity} earned={trophy.earned} size="lg" className="relative" />
          </div>
          <span className={`rounded-full px-3 py-1 text-sm font-extrabold ${style.chip}`}>
            {style.label}
          </span>
          <p className="text-pretty text-lg font-bold text-muted-foreground">{trophy.description}</p>
        </div>

        {/* Como ganhar */}
        <section className="rounded-3xl bg-card p-5 shadow-sm ring-1 ring-border">
          <div className="flex items-center gap-2">
            <Sparkles className="size-5 text-orange" />
            <h2 className="text-lg font-extrabold text-foreground">Como conquistar</h2>
          </div>
          <p className="mt-2 font-semibold text-muted-foreground">{trophy.howToEarn}</p>
        </section>

        {/* Estado: conquistado ou progresso */}
        {trophy.earned ? (
          <section className="flex items-center gap-3 rounded-3xl bg-success-soft p-5">
            <span className="flex size-12 shrink-0 items-center justify-center rounded-full bg-success text-success-foreground">
              <Calendar className="size-6" />
            </span>
            <div>
              <p className="text-sm font-extrabold uppercase tracking-wide text-success">Conquistado</p>
              <p className="font-bold text-foreground">{trophy.dateEarned}</p>
            </div>
          </section>
        ) : trophy.progress ? (
          <section className="rounded-3xl bg-card p-5 shadow-sm ring-1 ring-border">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-extrabold text-foreground">Seu progresso</h2>
              <span className="text-lg font-extrabold text-brand">{pct}%</span>
            </div>
            <div className="mt-3 h-4 overflow-hidden rounded-full bg-muted">
              <div className="h-full rounded-full bg-brand" style={{ width: `${pct}%` }} />
            </div>
            <p className="mt-2 font-bold text-muted-foreground">
              Faltam {Math.max(0, trophy.progress.total - trophy.progress.current)} para desbloquear!
            </p>
          </section>
        ) : null}

        <MiloBubble
          tone="orange"
          message={
            trophy.earned
              ? "Você arrasou! Que tal mostrar para os seus amigos?"
              : "Você está quase lá! Continue praticando que eu acredito em você!"
          }
        />

        <Link
          href="/trofeus"
          className="rounded-full bg-brand py-4 text-center text-lg font-extrabold text-brand-foreground shadow-lg shadow-brand/30 transition-transform active:scale-[0.98]"
        >
          Voltar aos troféus
        </Link>
      </main>
    </div>
  )
}
