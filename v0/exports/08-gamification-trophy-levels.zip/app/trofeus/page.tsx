import Link from "next/link"
import { Flame, Trophy } from "lucide-react"
import { ScreenHeader } from "@/components/screen-header"
import { MiloBubble } from "@/components/milo-bubble"
import { TrophyMedal, rarityStyles } from "@/components/trophy-medal"
import { BottomNav } from "@/components/bottom-nav"
import { trophies, type TrophyCategory } from "@/lib/gamification-data"

const categoryLabels: Record<TrophyCategory, string> = {
  diario: "Diários",
  semanal: "Semanais",
  mensal: "Mensais",
  sequencia: "Sequência",
  especial: "Especiais",
}

const order: TrophyCategory[] = ["diario", "semanal", "mensal", "sequencia", "especial"]

export default function TrophyRoomPage() {
  const earnedCount = trophies.filter((t) => t.earned).length
  const nextTrophy = trophies.find((t) => !t.earned && t.progress)

  return (
    <div className="mx-auto flex min-h-screen w-full max-w-md flex-col bg-background">
      <ScreenHeader eyebrow="Math Hero Kids" title="Sala de Troféus" backHref="/" />

      <main className="flex flex-1 flex-col gap-5 px-4 py-5">
        <MiloBubble message="Olha quantos troféus você já tem! Vamos conquistar mais?" />

        <div className="grid grid-cols-2 gap-3">
          <div className="flex items-center gap-3 rounded-3xl bg-gold-soft p-4">
            <span className="flex size-12 items-center justify-center rounded-full bg-gold text-gold-foreground">
              <Trophy className="size-6" />
            </span>
            <div>
              <p className="text-2xl font-extrabold leading-none text-foreground">{earnedCount}</p>
              <p className="text-sm font-bold text-muted-foreground">Conquistados</p>
            </div>
          </div>
          <div className="flex items-center gap-3 rounded-3xl bg-orange-soft p-4">
            <span className="flex size-12 items-center justify-center rounded-full bg-orange text-orange-foreground">
              <Flame className="size-6" />
            </span>
            <div>
              <p className="text-2xl font-extrabold leading-none text-foreground">8</p>
              <p className="text-sm font-bold text-muted-foreground">Sequência</p>
            </div>
          </div>
        </div>

        {/* Progresso para o próximo troféu */}
        {nextTrophy?.progress && (
          <section className="rounded-3xl bg-card p-4 shadow-sm ring-1 ring-border">
            <p className="mb-3 text-sm font-extrabold uppercase tracking-wide text-muted-foreground">
              Próximo troféu
            </p>
            <div className="flex items-center gap-3">
              <TrophyMedal rarity={nextTrophy.rarity} earned={false} size="sm" />
              <div className="min-w-0 flex-1">
                <p className="font-extrabold text-foreground">{nextTrophy.name}</p>
                <div className="mt-2 h-3 overflow-hidden rounded-full bg-muted">
                  <div
                    className="h-full rounded-full bg-gold"
                    style={{
                      width: `${Math.min(100, (nextTrophy.progress.current / nextTrophy.progress.total) * 100)}%`,
                    }}
                  />
                </div>
                <p className="mt-1 text-sm font-bold text-muted-foreground">
                  {nextTrophy.progress.current} / {nextTrophy.progress.total}
                </p>
              </div>
            </div>
          </section>
        )}

        {order.map((cat) => {
          const list = trophies.filter((t) => t.category === cat)
          if (list.length === 0) return null
          return (
            <section key={cat}>
              <h2 className="mb-3 text-xl font-extrabold text-foreground">{categoryLabels[cat]}</h2>
              <div className="grid grid-cols-3 gap-3">
                {list.map((t) => (
                  <Link
                    key={t.id}
                    href={`/trofeus/${t.id}`}
                    className="flex flex-col items-center gap-2 rounded-3xl bg-card p-3 text-center shadow-sm ring-1 ring-border transition-transform active:scale-95"
                  >
                    <TrophyMedal rarity={t.rarity} earned={t.earned} size="sm" />
                    <span className="text-xs font-bold leading-tight text-foreground">{t.name}</span>
                    <span
                      className={`rounded-full px-2 py-0.5 text-[10px] font-extrabold ${rarityStyles[t.rarity].chip}`}
                    >
                      {rarityStyles[t.rarity].label}
                    </span>
                  </Link>
                ))}
              </div>
            </section>
          )
        })}
      </main>

      <BottomNav />
    </div>
  )
}
