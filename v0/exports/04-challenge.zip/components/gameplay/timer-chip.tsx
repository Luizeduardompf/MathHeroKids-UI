import { Clock } from "lucide-react"

interface TimerChipProps {
  /** seconds remaining */
  remaining: number
}

export function TimerChip({ remaining }: TimerChipProps) {
  // Subtle, supportive color states — never competes with the question
  const critical = remaining <= 2
  const almost = remaining <= 5

  let bg = "bg-muted"
  let fg = "text-ink-muted"

  if (critical) {
    bg = "bg-brand-red-soft"
    fg = "text-brand-red"
  } else if (almost) {
    bg = "bg-brand-orange-soft"
    fg = "text-brand-orange"
  }

  return (
    <div
      className={`flex items-center gap-1 rounded-full px-2.5 py-1 ${bg} ${fg} transition-colors`}
      role="timer"
      aria-label={`${remaining} segundos restantes`}
    >
      <Clock className="h-4 w-4" strokeWidth={2.5} />
      <span className="text-sm font-extrabold tabular-nums">{remaining}s</span>
    </div>
  )
}
