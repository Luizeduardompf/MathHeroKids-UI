"use client"

interface ExitModalProps {
  onContinue: () => void
  onLeave: () => void
}

export function ExitModal({ onContinue, onLeave }: ExitModalProps) {
  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center bg-ink/40 px-6 backdrop-blur-sm">
      <div className="w-full max-w-sm rounded-[2rem] bg-card p-6 text-center shadow-xl animate-pop">
        <h2 className="text-2xl font-black text-ink text-balance">
          Sair do desafio?
        </h2>
        <p className="mt-2 text-base font-semibold text-ink-muted text-pretty">
          Seu progresso desta questão não será salvo.
        </p>
        <div className="mt-6 flex flex-col gap-3">
          <button
            type="button"
            onClick={onContinue}
            className="flex h-14 items-center justify-center rounded-2xl bg-brand-green text-lg font-black text-white shadow-sm transition-transform active:scale-95"
          >
            Continuar
          </button>
          <button
            type="button"
            onClick={onLeave}
            className="flex h-14 items-center justify-center rounded-2xl bg-muted text-lg font-black text-ink-muted transition-transform active:scale-95"
          >
            Sair
          </button>
        </div>
      </div>
    </div>
  )
}
