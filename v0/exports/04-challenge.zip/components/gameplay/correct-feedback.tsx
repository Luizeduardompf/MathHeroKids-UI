"use client"

import { useEffect } from "react"
import confetti from "canvas-confetti"
import { Check } from "lucide-react"

interface CorrectFeedbackProps {
  xpGain?: number
}

/**
 * Quick (1–2s) success celebration: confetti burst, animated green check, floating +XP.
 * Shown as a full-screen overlay between answering correctly and the next question.
 */
export function CorrectFeedback({ xpGain = 10 }: CorrectFeedbackProps) {
  useEffect(() => {
    const fire = (ratio: number, opts: confetti.Options) => {
      confetti({
        particleCount: Math.floor(120 * ratio),
        spread: 70,
        origin: { y: 0.6 },
        colors: ["#2f6bff", "#f4761e", "#3aa564", "#e0a52b"],
        ...opts,
      })
    }
    fire(0.25, { spread: 26, startVelocity: 55 })
    fire(0.35, { spread: 100, decay: 0.91, scalar: 0.9 })
    fire(0.2, { spread: 120, startVelocity: 45 })

    // play a short success sound (best-effort, ignored if blocked)
    try {
      const ctx = new (window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext })
          .webkitAudioContext)()
      const notes = [523.25, 659.25, 783.99]
      notes.forEach((freq, i) => {
        const osc = ctx.createOscillator()
        const gain = ctx.createGain()
        osc.type = "triangle"
        osc.frequency.value = freq
        osc.connect(gain)
        gain.connect(ctx.destination)
        const t = ctx.currentTime + i * 0.12
        gain.gain.setValueAtTime(0.0001, t)
        gain.gain.exponentialRampToValueAtTime(0.25, t + 0.02)
        gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.18)
        osc.start(t)
        osc.stop(t + 0.2)
      })
    } catch {
      // audio not available — silently ignore
    }
  }, [])

  return (
    <div className="absolute inset-0 z-30 flex flex-col items-center justify-center gap-6 bg-brand-green-soft/85 backdrop-blur-sm">
      <div className="relative flex h-32 w-32 items-center justify-center rounded-full bg-brand-green shadow-lg animate-pop">
        <Check className="h-20 w-20 text-white" strokeWidth={4} />
        <span className="absolute -right-2 -top-8 rounded-full bg-brand-gold px-3 py-1 text-lg font-black text-white shadow-md animate-float-up">
          +{xpGain} XP
        </span>
      </div>
      <p className="text-3xl font-black text-brand-green-dark animate-pop">
        Acertou!
      </p>
    </div>
  )
}
