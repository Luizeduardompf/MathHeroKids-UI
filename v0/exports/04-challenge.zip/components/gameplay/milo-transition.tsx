import Image from "next/image"

interface MiloTransitionProps {
  message: string
}

/**
 * Encouraging interstitial between questions. Milo appears full-screen
 * for 2–3s, then gameplay auto-continues. Not shown during questions.
 */
export function MiloTransition({ message }: MiloTransitionProps) {
  return (
    <div className="absolute inset-0 z-30 flex flex-col items-center justify-center gap-6 bg-brand-blue px-8 text-center">
      <div className="relative h-40 w-40 overflow-hidden rounded-full bg-white shadow-xl ring-4 ring-white/40 animate-pop">
        <Image
          src="/milo-mascot.png"
          alt="Milo, o mago da matemática"
          fill
          className="object-cover"
          sizes="160px"
          priority
        />
      </div>
      <p className="text-4xl font-black leading-tight text-white text-balance animate-float-up">
        {message}
      </p>
    </div>
  )
}
