"use client"

import { Delete, Check } from "lucide-react"

interface NumericKeypadProps {
  onDigit: (digit: string) => void
  onDelete: () => void
  onSubmit: () => void
  canSubmit: boolean
}

export function NumericKeypad({
  onDigit,
  onDelete,
  onSubmit,
  canSubmit,
}: NumericKeypadProps) {
  const digits = ["1", "2", "3", "4", "5", "6", "7", "8", "9"]

  return (
    <div className="grid grid-cols-3 gap-2.5">
      {digits.map((d) => (
        <KeyButton key={d} onClick={() => onDigit(d)}>
          {d}
        </KeyButton>
      ))}

      <KeyButton variant="muted" onClick={onDelete} aria-label="Apagar">
        <Delete className="h-7 w-7" strokeWidth={2.5} />
      </KeyButton>

      <KeyButton onClick={() => onDigit("0")}>0</KeyButton>

      <KeyButton
        variant="success"
        onClick={onSubmit}
        disabled={!canSubmit}
        aria-label="Confirmar resposta"
      >
        <Check className="h-8 w-8" strokeWidth={3} />
      </KeyButton>
    </div>
  )
}

function KeyButton({
  children,
  onClick,
  variant = "default",
  disabled,
  ...props
}: {
  children: React.ReactNode
  onClick: () => void
  variant?: "default" | "muted" | "success"
  disabled?: boolean
} & React.ButtonHTMLAttributes<HTMLButtonElement>) {
  const base =
    "flex h-[clamp(3.25rem,9vh,4.5rem)] items-center justify-center rounded-2xl text-3xl font-black shadow-sm transition-transform active:translate-y-0.5 active:scale-95 disabled:opacity-40 disabled:active:translate-y-0 disabled:active:scale-100"

  const variants = {
    default: "bg-card text-ink hover:bg-brand-blue-soft",
    muted: "bg-muted text-ink-muted hover:bg-border",
    success: "bg-brand-green text-white hover:bg-brand-green-dark",
  }

  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      className={`${base} ${variants[variant]}`}
      {...props}
    >
      {children}
    </button>
  )
}
