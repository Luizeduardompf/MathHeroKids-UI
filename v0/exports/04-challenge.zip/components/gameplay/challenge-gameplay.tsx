"use client"

import { useState, useEffect, useCallback, useRef } from "react"
import { X } from "lucide-react"
import { TimerChip } from "@/components/gameplay/timer-chip"
import { NumericKeypad } from "@/components/gameplay/numeric-keypad"
import { CorrectFeedback } from "@/components/gameplay/correct-feedback"
import { MiloTransition } from "@/components/gameplay/milo-transition"
import { ExitModal } from "@/components/gameplay/exit-modal"

const TOTAL_QUESTIONS = 20
const TIME_PER_QUESTION = 15

const MILO_MESSAGES = [
  "Incrível!",
  "Muito bem!",
  "Continue assim!",
  "Faltam poucas questões!",
]

// Simple multiplication generator (visual demo — no real backend)
function makeQuestion() {
  const a = Math.floor(Math.random() * 9) + 2
  const b = Math.floor(Math.random() * 9) + 2
  return { a, b, answer: a * b }
}

type Phase = "playing" | "correct" | "milo"

export function ChallengeGameplay() {
  const [questionIndex, setQuestionIndex] = useState(1)
  const [question, setQuestion] = useState(() => ({ a: 7, b: 8, answer: 56 }))
  const [answer, setAnswer] = useState("")
  const [remaining, setRemaining] = useState(TIME_PER_QUESTION)
  const [phase, setPhase] = useState<Phase>("playing")
  const [showExit, setShowExit] = useState(false)
  const [miloMessage, setMiloMessage] = useState(MILO_MESSAGES[0])
  const [wrong, setWrong] = useState(false)
  const advancing = useRef(false)

  // Countdown — only while actively playing
  useEffect(() => {
    if (phase !== "playing" || showExit) return
    const id = setInterval(() => {
      setRemaining((r) => (r <= 1 ? TIME_PER_QUESTION : r - 1))
    }, 1000)
    return () => clearInterval(id)
  }, [phase, showExit])

  const goToNextQuestion = useCallback(() => {
    advancing.current = false
    setQuestionIndex((i) => (i >= TOTAL_QUESTIONS ? 1 : i + 1))
    setQuestion(makeQuestion())
    setAnswer("")
    setRemaining(TIME_PER_QUESTION)
    setPhase("playing")
  }, [])

  const handleSubmit = useCallback(() => {
    if (advancing.current || phase !== "playing") return
    const isCorrect = Number(answer) === question.answer

    if (!isCorrect) {
      // gentle nudge, stay on the question
      setWrong(true)
      setTimeout(() => setWrong(false), 500)
      setAnswer("")
      return
    }

    advancing.current = true
    setPhase("correct")

    // Occasionally show a Milo encouragement between questions
    const showMilo = questionIndex % 3 === 0
    setTimeout(() => {
      if (showMilo) {
        setMiloMessage(
          MILO_MESSAGES[Math.floor(Math.random() * MILO_MESSAGES.length)],
        )
        setPhase("milo")
        setTimeout(goToNextQuestion, 2400)
      } else {
        goToNextQuestion()
      }
    }, 1400)
  }, [answer, question.answer, questionIndex, phase, goToNextQuestion])

  const handleDigit = (d: string) =>
    setAnswer((prev) => (prev.length >= 3 ? prev : prev + d))
  const handleDelete = () => setAnswer((prev) => prev.slice(0, -1))

  const progressPct = Math.round((questionIndex / TOTAL_QUESTIONS) * 100)

  return (
    <div className="relative mx-auto flex h-[100dvh] w-full max-w-[480px] flex-col overflow-hidden bg-background">
      {/* Minimal header: close, progress, subtle timer */}
      <header className="flex items-center gap-3 px-4 pt-[max(0.75rem,env(safe-area-inset-top))]">
        <button
          type="button"
          onClick={() => setShowExit(true)}
          aria-label="Sair do desafio"
          className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-muted text-ink-muted transition-transform active:scale-90"
        >
          <X className="h-6 w-6" strokeWidth={2.5} />
        </button>

        <div className="flex-1">
          <div className="mb-1 flex items-baseline justify-between">
            <span className="text-xs font-extrabold text-ink">
              Questão {questionIndex} de {TOTAL_QUESTIONS}
            </span>
          </div>
          <div className="h-2.5 w-full overflow-hidden rounded-full bg-brand-green-soft">
            <div
              className="h-full rounded-full bg-brand-green transition-all duration-300"
              style={{ width: `${progressPct}%` }}
            />
          </div>
        </div>

        <TimerChip remaining={remaining} />
      </header>

      {/* Hero question — fills the available space, always visible */}
      <main className="flex flex-1 flex-col items-center justify-center px-5">
        <span className="mb-6 rounded-full bg-brand-green-soft px-4 py-1.5 text-sm font-extrabold text-brand-green-dark">
          Tabuada da Multiplicação
        </span>
        <div
          className={`flex flex-wrap items-center justify-center gap-x-3 gap-y-2 ${
            wrong ? "animate-shake" : ""
          }`}
        >
          <span className="text-7xl font-black text-ink sm:text-8xl">
            {question.a}
          </span>
          <span className="text-6xl font-black text-brand-blue sm:text-7xl">
            ×
          </span>
          <span className="text-7xl font-black text-ink sm:text-8xl">
            {question.b}
          </span>
          <span className="text-6xl font-black text-brand-blue sm:text-7xl">
            =
          </span>
          <div
            className={`flex h-24 min-w-24 items-center justify-center rounded-3xl border-4 border-dashed px-3 transition-colors ${
              wrong
                ? "border-brand-red bg-brand-red-soft"
                : answer
                  ? "border-brand-blue bg-brand-blue-soft"
                  : "border-brand-blue-soft"
            }`}
          >
            <span className="text-7xl font-black text-brand-blue sm:text-8xl">
              {answer || "?"}
            </span>
          </div>
        </div>
      </main>

      {/* Fixed keypad — no scrolling required on any device */}
      <div className="px-4 pb-[max(1rem,env(safe-area-inset-bottom))]">
        <NumericKeypad
          onDigit={handleDigit}
          onDelete={handleDelete}
          onSubmit={handleSubmit}
          canSubmit={answer.length > 0}
        />
      </div>

      {phase === "correct" && <CorrectFeedback xpGain={10} />}
      {phase === "milo" && <MiloTransition message={miloMessage} />}
      {showExit && (
        <ExitModal
          onContinue={() => setShowExit(false)}
          onLeave={() => setShowExit(false)}
        />
      )}
    </div>
  )
}
