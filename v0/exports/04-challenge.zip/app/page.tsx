import { ChallengeGameplay } from "@/components/gameplay/challenge-gameplay"

export default function Home() {
  return (
    <main className="min-h-screen bg-background">
      <ChallengeGameplay />
    </main>
  )
}
