import Image from "next/image"

export function MiloMessage({
  message,
}: {
  message: string
}) {
  return (
    <div className="relative overflow-hidden rounded-3xl bg-brand-blue p-4 shadow-md shadow-brand-blue/30">
      <div className="absolute -right-6 -top-8 h-28 w-28 rounded-full bg-white/10" />
      <div className="absolute -bottom-10 right-10 h-24 w-24 rounded-full bg-white/10" />
      <div className="relative flex items-center gap-3">
        <span className="flex h-16 w-16 shrink-0 items-center justify-center overflow-hidden rounded-full bg-white">
          <Image
            src="/milo-calendar.png"
            alt="Milo, o mago da matemática"
            width={60}
            height={60}
            className="object-contain"
          />
        </span>
        <div className="min-w-0 flex-1">
          <p className="mb-1 text-xs font-bold uppercase tracking-wide text-brand-blue-light">
            Milo diz
          </p>
          <div className="rounded-2xl bg-white px-4 py-2.5">
            <p className="text-pretty text-sm font-bold leading-snug text-foreground">
              {message}
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
