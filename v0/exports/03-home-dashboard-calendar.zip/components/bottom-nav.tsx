import { Home, Calendar, Swords, Users, Settings } from "lucide-react"

const items = [
  { label: "Início", icon: Home, active: false },
  { label: "Calendário", icon: Calendar, active: true },
  { label: "Desafio", icon: Swords, active: false, primary: true },
  { label: "Amigos", icon: Users, active: false },
  { label: "Ajustes", icon: Settings, active: false },
]

export function BottomNav() {
  return (
    <nav className="sticky bottom-0 z-20 border-t border-border bg-card px-2 pb-6 pt-2">
      <ul className="flex items-end justify-between">
        {items.map((item) => {
          const Icon = item.icon

          if (item.primary) {
            return (
              <li key={item.label} className="flex-1">
                <button
                  type="button"
                  className="mx-auto flex flex-col items-center gap-1"
                  aria-label={item.label}
                >
                  <span className="flex h-14 w-14 -translate-y-3 items-center justify-center rounded-full bg-brand-orange text-white shadow-lg shadow-brand-orange/40 ring-4 ring-card">
                    <Icon className="h-6 w-6" />
                  </span>
                  <span className="-mt-2 text-xs font-bold text-brand-orange">
                    {item.label}
                  </span>
                </button>
              </li>
            )
          }

          return (
            <li key={item.label} className="flex-1">
              <button
                type="button"
                className="mx-auto flex flex-col items-center gap-1 py-1"
                aria-label={item.label}
                aria-current={item.active ? "page" : undefined}
              >
                <Icon
                  className={
                    item.active
                      ? "h-6 w-6 text-brand-blue"
                      : "h-6 w-6 text-muted-foreground"
                  }
                />
                <span
                  className={
                    item.active
                      ? "text-xs font-bold text-brand-blue"
                      : "text-xs font-medium text-muted-foreground"
                  }
                >
                  {item.label}
                </span>
              </button>
            </li>
          )
        })}
      </ul>
    </nav>
  )
}
