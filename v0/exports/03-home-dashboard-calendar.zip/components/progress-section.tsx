import { Trophy, Zap, CalendarDays, CalendarCheck } from "lucide-react"
import type { CalendarStats } from "@/lib/calendar-data"

function Ring({ percent, color }: { percent: number; color: string }) {
  const r = 26
  const c = 2 * Math.PI * r
  const offset = c - (percent / 100) * c
  return (
    <svg viewBox="0 0 64 64" className="h-16 w-16 -rotate-90">
      <circle
        cx="32"
        cy="32"
        r={r}
        fill="none"
        strokeWidth="7"
        className="stroke-muted"
      />
      <circle
        cx="32"
        cy="32"
        r={r}
        fill="none"
        strokeWidth="7"
        strokeLinecap="round"
        stroke={color}
        strokeDasharray={c}
        strokeDashoffset={offset}
      />
    </svg>
  )
}

export function ProgressSection({ stats }: { stats: CalendarStats }) {
  return (
    <section className="flex flex-col gap-3">
      <h2 className="px-1 text-lg font-extrabold text-foreground">
        Seu progresso
      </h2>

      {/* Monthly progress with ring */}
      <div className="flex items-center gap-4 rounded-3xl bg-card p-4 shadow-sm ring-1 ring-border">
        <div className="relative flex items-center justify-center">
          <Ring percent={stats.monthlyPercent} color="var(--brand-green)" />
          <span className="absolute text-sm font-extrabold text-foreground">
            {stats.monthlyPercent}%
          </span>
        </div>
        <div className="flex-1">
          <div className="mb-1 flex items-center gap-1.5">
            <CalendarDays className="h-4 w-4 text-brand-green" />
            <p className="text-sm font-bold text-foreground">Progresso do mês</p>
          </div>
          <p className="text-xs font-medium text-muted-foreground">
            Você completou seus desafios em quase todos os dias. Continue assim!
          </p>
        </div>
      </div>

      {/* Weekly progress bar */}
      <div className="rounded-3xl bg-card p-4 shadow-sm ring-1 ring-border">
        <div className="mb-2 flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <CalendarCheck className="h-4 w-4 text-brand-orange" />
            <p className="text-sm font-bold text-foreground">Esta semana</p>
          </div>
          <span className="text-sm font-extrabold text-brand-orange">
            {stats.weeklyDays}/7 dias
          </span>
        </div>
        <div className="h-3 w-full overflow-hidden rounded-full bg-brand-orange-light">
          <div
            className="h-full rounded-full bg-brand-orange"
            style={{ width: `${stats.weeklyPercent}%` }}
          />
        </div>
      </div>

      {/* Trophy progress + XP */}
      <div className="grid grid-cols-2 gap-3">
        <div className="rounded-3xl bg-card p-4 shadow-sm ring-1 ring-border">
          <span className="flex h-10 w-10 items-center justify-center rounded-full bg-brand-gold-light">
            <Trophy className="h-5 w-5 text-brand-gold" />
          </span>
          <p className="mt-2 text-sm font-bold text-foreground">
            Troféu mensal
          </p>
          <p className="mb-2 text-xs font-medium text-muted-foreground">
            {stats.trophyProgress} de {stats.trophyTarget} dias
          </p>
          <div className="h-2 w-full overflow-hidden rounded-full bg-muted">
            <div
              className="h-full rounded-full bg-brand-gold"
              style={{
                width: `${(stats.trophyProgress / stats.trophyTarget) * 100}%`,
              }}
            />
          </div>
        </div>

        <div className="flex flex-col justify-center rounded-3xl bg-brand-blue p-4 text-white shadow-md shadow-brand-blue/30">
          <span className="flex h-10 w-10 items-center justify-center rounded-full bg-white/20">
            <Zap className="h-5 w-5" />
          </span>
          <p className="mt-2 text-2xl font-extrabold leading-none">
            +{stats.xpThisMonth.toLocaleString("pt-BR")}
          </p>
          <p className="text-sm font-bold text-brand-blue-light">XP no mês</p>
        </div>
      </div>
    </section>
  )
}
