import { Trophy, Star, Lock } from "lucide-react"
import { cn } from "@/lib/utils"
import {
  type CalendarDay,
  MONTH_LABEL,
  WEEKDAYS,
} from "@/lib/calendar-data"
import { ChevronLeft, ChevronRight } from "lucide-react"

function BrokenTrophy({ className }: { className?: string }) {
  // Trophy with a "crack" line to convey a missed day
  return (
    <span className={cn("relative inline-flex", className)}>
      <Trophy className="h-full w-full" />
      <span className="absolute left-1/2 top-0 h-full w-[1.5px] -translate-x-1/2 rotate-12 bg-current opacity-60" />
    </span>
  )
}

function DayCell({ day }: { day: CalendarDay }) {
  if (day.status === "empty") {
    return <div aria-hidden="true" />
  }

  const base =
    "relative flex aspect-square w-full flex-col items-center justify-center rounded-2xl text-sm font-bold transition-transform"

  switch (day.status) {
    case "perfect":
      return (
        <div
          className={cn(
            base,
            "bg-brand-gold text-white shadow-md shadow-brand-gold/40 ring-2 ring-brand-yellow",
          )}
        >
          <Star className="animate-star-shimmer h-5 w-5 fill-white" />
          <span className="mt-0.5 text-[11px]">{day.day}</span>
        </div>
      )
    case "completed":
      return (
        <div
          className={cn(
            base,
            "bg-brand-green-light text-brand-green-dark ring-1 ring-brand-green/30",
          )}
        >
          <Trophy className="h-5 w-5 text-brand-green" />
          <span className="mt-0.5 text-[11px]">{day.day}</span>
        </div>
      )
    case "missed":
      return (
        <div
          className={cn(
            base,
            "bg-brand-red-light text-brand-red ring-1 ring-brand-red/25",
          )}
        >
          <BrokenTrophy className="h-5 w-5" />
          <span className="mt-0.5 text-[11px]">{day.day}</span>
        </div>
      )
    case "today":
      return (
        <div
          className={cn(
            base,
            "animate-today-pulse bg-brand-blue text-white ring-2 ring-white",
          )}
        >
          <span className="text-base font-extrabold">{day.day}</span>
          <span className="text-[9px] font-bold uppercase tracking-wide text-brand-blue-light">
            hoje
          </span>
        </div>
      )
    case "future":
      return (
        <div
          className={cn(
            base,
            "bg-muted text-muted-foreground/60 ring-1 ring-border",
          )}
        >
          <Lock className="h-4 w-4" />
          <span className="mt-0.5 text-[11px]">{day.day}</span>
        </div>
      )
    default:
      return null
  }
}

export function CalendarGrid({ days }: { days: CalendarDay[] }) {
  return (
    <section className="rounded-3xl bg-card p-4 shadow-sm ring-1 ring-border">
      <div className="mb-4 flex items-center justify-between">
        <button
          type="button"
          aria-label="Mês anterior"
          className="flex h-9 w-9 items-center justify-center rounded-full bg-muted text-muted-foreground"
        >
          <ChevronLeft className="h-5 w-5" />
        </button>
        <h2 className="text-lg font-extrabold text-foreground">{MONTH_LABEL}</h2>
        <button
          type="button"
          aria-label="Próximo mês"
          className="flex h-9 w-9 items-center justify-center rounded-full bg-muted text-muted-foreground"
        >
          <ChevronRight className="h-5 w-5" />
        </button>
      </div>

      <div className="mb-2 grid grid-cols-7 gap-1.5">
        {WEEKDAYS.map((d, i) => (
          <div
            key={i}
            className="text-center text-xs font-bold text-muted-foreground"
          >
            {d}
          </div>
        ))}
      </div>

      <div className="grid grid-cols-7 gap-1.5">
        {days.map((day, i) => (
          <DayCell key={i} day={day} />
        ))}
      </div>

      <CalendarLegend />
    </section>
  )
}

function CalendarLegend() {
  const items = [
    {
      label: "Perfeito",
      icon: <Star className="h-3.5 w-3.5 fill-white text-white" />,
      box: "bg-brand-gold",
    },
    {
      label: "Concluído",
      icon: <Trophy className="h-3.5 w-3.5 text-brand-green" />,
      box: "bg-brand-green-light ring-1 ring-brand-green/30",
    },
    {
      label: "Perdido",
      icon: <BrokenTrophy className="h-3.5 w-3.5 text-brand-red" />,
      box: "bg-brand-red-light ring-1 ring-brand-red/25",
    },
    {
      label: "Bloqueado",
      icon: <Lock className="h-3.5 w-3.5 text-muted-foreground/60" />,
      box: "bg-muted ring-1 ring-border",
    },
  ]

  return (
    <div className="mt-4 flex flex-wrap items-center justify-between gap-2 border-t border-border pt-3">
      {items.map((item) => (
        <div key={item.label} className="flex items-center gap-1.5">
          <span
            className={cn(
              "flex h-6 w-6 items-center justify-center rounded-lg",
              item.box,
            )}
          >
            {item.icon}
          </span>
          <span className="text-xs font-semibold text-muted-foreground">
            {item.label}
          </span>
        </div>
      ))}
    </div>
  )
}
