import Image from "next/image"
import { ChevronDown } from "lucide-react"

export function ProfileHeader() {
  return (
    <header className="sticky top-0 z-20 bg-background/85 px-4 pb-3 pt-4 backdrop-blur-md">
      <div className="flex items-center gap-3">
        <button
          type="button"
          className="flex items-center gap-2.5 rounded-full bg-card py-1.5 pl-1.5 pr-3 shadow-sm ring-1 ring-border"
        >
          <span className="relative h-11 w-11 overflow-hidden rounded-full ring-2 ring-brand-blue-light">
            <Image
              src="/sofia-avatar.png"
              alt="Avatar de Sofia"
              fill
              className="object-cover"
              sizes="44px"
            />
          </span>
          <span className="text-left leading-tight">
            <span className="flex items-center gap-1 text-base font-bold text-foreground">
              Sofia
              <ChevronDown className="h-4 w-4 text-muted-foreground" />
            </span>
            <span className="text-xs font-medium text-muted-foreground">
              Nível 12
            </span>
          </span>
        </button>

        <div className="flex flex-1 flex-col gap-1.5">
          <div className="flex items-center justify-between text-sm font-bold">
            <span className="text-brand-blue">1.450 XP</span>
            <span className="text-muted-foreground">2.000</span>
          </div>
          <div className="h-2.5 w-full overflow-hidden rounded-full bg-brand-blue-light">
            <div
              className="h-full rounded-full bg-brand-blue"
              style={{ width: "72.5%" }}
            />
          </div>
        </div>
      </div>
    </header>
  )
}
