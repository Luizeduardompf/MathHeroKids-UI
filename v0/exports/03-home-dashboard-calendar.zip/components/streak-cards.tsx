import { Flame, Trophy } from "lucide-react"
import type { CalendarStats } from "@/lib/calendar-data"

export function StreakCards({ stats }: { stats: CalendarStats }) {
  return (
    <div className="grid grid-cols-2 gap-3">
      <div className="flex items-center gap-3 rounded-3xl bg-brand-orange p-4 text-white shadow-md shadow-brand-orange/30">
        <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-white/20">
          <Flame className="h-6 w-6" />
        </span>
        <div className="leading-tight">
          <p className="text-2xl font-extrabold">{stats.currentStreak}</p>
          <p className="text-sm font-bold text-white/90">Sequência</p>
        </div>
      </div>

      <div className="flex items-center gap-3 rounded-3xl bg-card p-4 shadow-sm ring-1 ring-border">
        <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-brand-gold-light">
          <Trophy className="h-6 w-6 text-brand-gold" />
        </span>
        <div className="leading-tight">
          <p className="text-2xl font-extrabold text-foreground">
            {stats.bestStreak}
          </p>
          <p className="text-sm font-bold text-muted-foreground">Recorde</p>
        </div>
      </div>
    </div>
  )
}
