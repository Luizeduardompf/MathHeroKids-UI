export type DayStatus =
  | "perfect"
  | "completed"
  | "missed"
  | "today"
  | "future"
  | "empty"

export type CalendarDay = {
  day: number
  status: DayStatus
  xp?: number
}

// Demo month: a hypothetical "current month" with a mix of states.
// Today is set to the 18th so we can show completed, perfect, missed,
// today and future days all at once.
const TODAY = 18
const DAYS_IN_MONTH = 30
// First day of month falls on a Wednesday (0 = Sunday ... 6 = Saturday)
const FIRST_WEEKDAY = 3

// Days that were perfect (10/10 questions correct)
const PERFECT_DAYS = new Set([2, 5, 9, 12, 16])
// Days that were missed (no challenge completed)
const MISSED_DAYS = new Set([3, 8, 13])

export function getMonthDays(): CalendarDay[] {
  const cells: CalendarDay[] = []

  // Leading empty cells before the 1st
  for (let i = 0; i < FIRST_WEEKDAY; i++) {
    cells.push({ day: 0, status: "empty" })
  }

  for (let day = 1; day <= DAYS_IN_MONTH; day++) {
    let status: DayStatus
    let xp: number | undefined

    if (day === TODAY) {
      status = "today"
    } else if (day > TODAY) {
      status = "future"
    } else if (MISSED_DAYS.has(day)) {
      status = "missed"
    } else if (PERFECT_DAYS.has(day)) {
      status = "perfect"
      xp = 150
    } else {
      status = "completed"
      xp = 100
    }

    cells.push({ day, status, xp })
  }

  return cells
}

export const MONTH_LABEL = "Junho 2026"

export const WEEKDAYS = ["D", "S", "T", "Q", "Q", "S", "S"] as const
export const WEEKDAYS_FULL = [
  "Domingo",
  "Segunda",
  "Terça",
  "Quarta",
  "Quinta",
  "Sexta",
  "Sábado",
] as const

export type CalendarStats = {
  monthlyPercent: number
  weeklyPercent: number
  weeklyDays: number
  currentStreak: number
  bestStreak: number
  trophyProgress: number
  trophyTarget: number
  xpThisMonth: number
}

export function getStats(days: CalendarDay[]): CalendarStats {
  const past = days.filter(
    (d) => d.status === "completed" || d.status === "perfect" || d.status === "missed",
  )
  const done = past.filter((d) => d.status === "completed" || d.status === "perfect")
  const monthlyPercent = Math.round((done.length / past.length) * 100)
  const xpThisMonth = done.reduce((sum, d) => sum + (d.xp ?? 0), 0)

  return {
    monthlyPercent,
    weeklyPercent: 71,
    weeklyDays: 5,
    currentStreak: 8,
    bestStreak: 21,
    trophyProgress: done.length,
    trophyTarget: 30,
    xpThisMonth,
  }
}
