import { ProfileHeader } from "@/components/profile-header"
import { BottomNav } from "@/components/bottom-nav"
import { MiloMessage } from "@/components/milo-message"
import { StreakCards } from "@/components/streak-cards"
import { CalendarGrid } from "@/components/calendar-grid"
import { ProgressSection } from "@/components/progress-section"
import { getMonthDays, getStats } from "@/lib/calendar-data"

export default function CalendarPage() {
  const days = getMonthDays()
  const stats = getStats(days)

  return (
    <div className="flex min-h-screen w-full justify-center bg-brand-blue-light/40">
      <div className="relative flex min-h-screen w-full max-w-[440px] flex-col bg-background shadow-xl">
        <ProfileHeader />

        <main className="flex flex-1 flex-col gap-4 px-4 pb-6 pt-2">
          <MiloMessage message="Sua sequência está incrível! Não perca hoje." />

          <StreakCards stats={stats} />

          <CalendarGrid days={days} />

          <ProgressSection stats={stats} />
        </main>

        <BottomNav />
      </div>
    </div>
  )
}
