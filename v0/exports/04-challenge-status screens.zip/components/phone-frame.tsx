export function PhoneFrame({ children }: { children: React.ReactNode }) {
  return (
    <div className="relative flex w-full max-w-[420px] flex-col overflow-hidden rounded-[2.5rem] border-8 border-card bg-background font-sans shadow-2xl">
      {children}
    </div>
  )
}
