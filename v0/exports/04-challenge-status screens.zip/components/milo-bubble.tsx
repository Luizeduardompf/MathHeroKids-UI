import Image from "next/image"

type MiloBubbleVariant = "encouraging" | "gentle" | "cheer"

const miloSrc: Record<MiloBubbleVariant, string> = {
  encouraging: "/milo-encouraging.png",
  gentle: "/milo-gentle.png",
  cheer: "/milo-cheer.png",
}

export function MiloBubble({
  message,
  variant = "encouraging",
  tone = "primary",
}: {
  message: string
  variant?: MiloBubbleVariant
  tone?: "primary" | "warning" | "destructive"
}) {
  const toneClasses: Record<string, string> = {
    primary: "bg-primary",
    warning: "bg-warning",
    destructive: "bg-destructive",
  }

  const labelToneClasses: Record<string, string> = {
    primary: "text-primary-foreground/80",
    warning: "text-warning-foreground/70",
    destructive: "text-destructive-foreground/80",
  }

  return (
    <div
      className={`flex items-center gap-3 rounded-3xl ${toneClasses[tone]} p-3 pr-4 shadow-sm`}
    >
      <div className="flex size-16 shrink-0 items-center justify-center rounded-full bg-card shadow-inner">
        <Image
          src={miloSrc[variant] || "/placeholder.svg"}
          alt="Milo, o mago mascote"
          width={56}
          height={56}
          className="size-14 object-contain"
        />
      </div>
      <div className="flex flex-1 flex-col gap-1">
        <span
          className={`font-heading text-xs font-bold uppercase tracking-wide ${labelToneClasses[tone]}`}
        >
          Milo diz
        </span>
        <div className="rounded-2xl bg-card px-4 py-2.5">
          <p className="font-heading text-base font-bold leading-snug text-card-foreground text-pretty">
            {message}
          </p>
        </div>
      </div>
    </div>
  )
}
