import { X, Check, ArrowRight, RotateCcw, Lightbulb } from "lucide-react"
import { MiloBubble } from "@/components/milo-bubble"
import { ActionButton } from "@/components/action-button"

export function WrongAnswerScreen() {
  return (
    <div className="flex flex-1 flex-col bg-gradient-to-b from-warning/15 to-background px-6 pb-8 pt-12">
      <div className="flex flex-1 flex-col items-center justify-center gap-6 text-center">
        {/* Soft mark, no punishment */}
        <div className="relative animate-pop-in">
          <div className="flex size-24 items-center justify-center rounded-full bg-warning/25">
            <div className="flex size-20 items-center justify-center rounded-full bg-warning text-warning-foreground">
              <X className="size-10" strokeWidth={3} />
            </div>
          </div>
        </div>

        <div className="flex flex-col gap-1">
          <h1 className="font-heading text-2xl font-extrabold text-foreground text-balance">
            Quase lá!
          </h1>
          <p className="text-base font-semibold text-muted-foreground">
            Veja a resposta certa abaixo.
          </p>
        </div>

        {/* Correct answer card */}
        <div className="w-full rounded-3xl border-2 border-success/30 bg-card p-5 shadow-sm">
          <div className="flex items-center justify-center gap-3 font-heading text-4xl font-extrabold text-foreground">
            <span>7</span>
            <span className="text-primary">×</span>
            <span>8</span>
            <span className="text-muted-foreground">=</span>
            <span className="flex items-center gap-2 text-success">
              56
              <span className="flex size-7 items-center justify-center rounded-full bg-success text-success-foreground">
                <Check className="size-4" strokeWidth={3.5} />
              </span>
            </span>
          </div>

          <div className="mt-4 flex items-center justify-center gap-2 rounded-2xl bg-muted px-4 py-2.5">
            <span className="text-sm font-bold text-muted-foreground">
              Sua resposta:
            </span>
            <span className="font-heading text-lg font-extrabold text-destructive line-through">
              54
            </span>
          </div>

          <div className="mt-3 flex items-start gap-2 rounded-2xl bg-warning/15 px-4 py-3 text-left">
            <Lightbulb className="mt-0.5 size-5 shrink-0 text-warning" strokeWidth={2.5} />
            <p className="text-sm font-semibold leading-relaxed text-foreground text-pretty">
              {"7 grupos de 8 dão 56. Pense em 7 × 8 como 7 × 4 (28) somado duas vezes!"}
            </p>
          </div>
        </div>
      </div>

      <div className="mb-6 mt-6">
        <MiloBubble
          variant="gentle"
          tone="primary"
          message="Errar faz parte de aprender! Agora você já sabe esta. Bora continuar!"
        />
      </div>

      <div className="flex flex-col gap-3">
        <ActionButton tone="success">
          Continuar
          <ArrowRight className="size-5" strokeWidth={2.5} />
        </ActionButton>
        <ActionButton tone="neutral">
          <RotateCcw className="size-5" strokeWidth={2.5} />
          Tentar o bloco de novo
        </ActionButton>
      </div>
    </div>
  )
}
