import { Clock, RotateCcw, Home } from "lucide-react"
import { MiloBubble } from "@/components/milo-bubble"
import { ActionButton } from "@/components/action-button"

export function TimeExpiredScreen() {
  return (
    <div className="flex flex-1 flex-col bg-gradient-to-b from-destructive/10 to-background px-6 pb-8 pt-12">
      {/* Illustration */}
      <div className="flex flex-1 flex-col items-center justify-center gap-6 text-center">
        <div className="relative animate-pop-in">
          <div className="absolute inset-0 -z-10 scale-125 rounded-full bg-destructive/15 blur-xl" />
          <div className="flex size-32 items-center justify-center rounded-full bg-destructive/15">
            <div className="flex size-24 items-center justify-center rounded-full bg-destructive text-destructive-foreground animate-wiggle-soft">
              <Clock className="size-12" strokeWidth={2.5} />
            </div>
          </div>
        </div>

        <div className="flex flex-col gap-2">
          <h1 className="font-heading text-3xl font-extrabold text-foreground text-balance">
            Acabou o tempo!
          </h1>
          <p className="max-w-xs text-base font-semibold leading-relaxed text-muted-foreground text-pretty">
            Não tem problema. Você consegue! Vamos tentar de novo com calma.
          </p>
        </div>
      </div>

      {/* Milo */}
      <div className="mb-6">
        <MiloBubble
          variant="encouraging"
          tone="destructive"
          message="Sem pressa! Respire fundo e tente outra vez. Eu acredito em você!"
        />
      </div>

      {/* Actions */}
      <div className="flex flex-col gap-3">
        <ActionButton tone="primary">
          <RotateCcw className="size-5" strokeWidth={2.5} />
          Tentar o bloco de novo
        </ActionButton>
        <ActionButton tone="neutral">
          <Home className="size-5" strokeWidth={2.5} />
          Voltar ao início
        </ActionButton>
      </div>
    </div>
  )
}
