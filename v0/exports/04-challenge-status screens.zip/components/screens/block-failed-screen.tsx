import { RotateCcw, Home, Target, Star } from "lucide-react"
import { MiloBubble } from "@/components/milo-bubble"
import { ActionButton } from "@/components/action-button"

const TOTAL = 20
const CORRECT = 18

export function BlockFailedScreen() {
  const percent = Math.round((CORRECT / TOTAL) * 100)

  return (
    <div className="flex flex-1 flex-col bg-gradient-to-b from-warning/15 to-background px-6 pb-8 pt-12">
      <div className="flex flex-1 flex-col items-center justify-center gap-6 text-center">
        <div className="relative animate-pop-in">
          <div className="flex size-28 items-center justify-center rounded-full bg-warning/25 animate-float-soft">
            <div className="flex size-22 items-center justify-center rounded-full bg-warning p-5 text-warning-foreground">
              <Target className="size-12" strokeWidth={2.5} />
            </div>
          </div>
        </div>

        <div className="flex flex-col gap-1">
          <h1 className="font-heading text-2xl font-extrabold text-foreground text-balance">
            Você chegou bem perto!
          </h1>
          <p className="max-w-xs text-base font-semibold leading-relaxed text-muted-foreground text-pretty">
            Para concluir o bloco, você precisa de uma pontuação perfeita.
          </p>
        </div>

        {/* Score card */}
        <div className="w-full rounded-3xl border-2 border-warning/30 bg-card p-5 shadow-sm">
          <div className="flex items-end justify-center gap-1.5">
            <span className="font-heading text-5xl font-extrabold text-foreground">
              {CORRECT}
            </span>
            <span className="mb-1.5 font-heading text-2xl font-bold text-muted-foreground">
              /{TOTAL}
            </span>
          </div>
          <p className="mt-1 text-sm font-bold text-muted-foreground">
            respostas corretas
          </p>

          {/* Progress bar */}
          <div className="mt-4 h-3.5 w-full overflow-hidden rounded-full bg-muted">
            <div
              className="h-full rounded-full bg-warning transition-all"
              style={{ width: `${percent}%` }}
            />
          </div>
          <div className="mt-2 flex items-center justify-between text-xs font-bold">
            <span className="text-muted-foreground">{percent}% acertos</span>
            <span className="flex items-center gap-1 text-warning">
              <Star className="size-3.5 fill-warning" strokeWidth={0} />
              Meta: 100%
            </span>
          </div>
        </div>
      </div>

      <div className="mb-6 mt-6">
        <MiloBubble
          variant="cheer"
          tone="warning"
          message="Faltou pouquinho! Mais uma tentativa e essa estrela perfeita é sua!"
        />
      </div>

      <div className="flex flex-col gap-3">
        <ActionButton tone="primary">
          <RotateCcw className="size-5" strokeWidth={2.5} />
          Tentar o bloco de novo
        </ActionButton>
        <ActionButton tone="neutral">
          <Home className="size-5" strokeWidth={2.5} />
          Voltar ao início
        </ActionButton>
      </div>
    </div>
  )
}
