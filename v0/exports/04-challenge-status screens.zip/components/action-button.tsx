import { cn } from "@/lib/utils"

type ActionTone = "success" | "primary" | "warning" | "neutral"

const toneClasses: Record<ActionTone, string> = {
  success: "bg-success text-success-foreground hover:brightness-105",
  primary: "bg-primary text-primary-foreground hover:brightness-105",
  warning: "bg-warning text-warning-foreground hover:brightness-105",
  neutral: "bg-muted text-muted-foreground hover:bg-accent",
}

export function ActionButton({
  children,
  tone = "primary",
  className,
  ...props
}: React.ComponentProps<"button"> & { tone?: ActionTone }) {
  return (
    <button
      className={cn(
        "flex h-14 w-full items-center justify-center gap-2 rounded-full px-6 font-heading text-lg font-bold shadow-sm transition-all outline-none active:translate-y-px focus-visible:ring-4 focus-visible:ring-ring/40",
        toneClasses[tone],
        className,
      )}
      {...props}
    >
      {children}
    </button>
  )
}
