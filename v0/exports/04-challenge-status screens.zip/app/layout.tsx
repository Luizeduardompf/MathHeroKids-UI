import { Analytics } from '@vercel/analytics/next'
import type { Metadata } from 'next'
import { Baloo_2, Nunito } from 'next/font/google'
import './globals.css'

const nunito = Nunito({
  variable: '--font-nunito',
  subsets: ['latin'],
})
const baloo = Baloo_2({
  variable: '--font-baloo',
  subsets: ['latin'],
})

export const metadata: Metadata = {
  title: 'Math Hero Kids',
  description:
    'Matemática gamificada, divertida e segura para crianças de 6 a 12 anos.',
  generator: 'v0.app',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html
      lang="pt-BR"
      className={`${nunito.variable} ${baloo.variable} bg-background`}
    >
      <body className="font-sans antialiased">
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
