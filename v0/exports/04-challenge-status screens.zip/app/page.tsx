"use client"

import { useState } from "react"
import { PhoneFrame } from "@/components/phone-frame"
import { TimeExpiredScreen } from "@/components/screens/time-expired-screen"
import { WrongAnswerScreen } from "@/components/screens/wrong-answer-screen"
import { BlockFailedScreen } from "@/components/screens/block-failed-screen"

type Screen = "time" | "wrong" | "block"

const tabs: { id: Screen; label: string }[] = [
  { id: "time", label: "Tempo esgotado" },
  { id: "wrong", label: "Resposta errada" },
  { id: "block", label: "Bloco não concluído" },
]

export default function Page() {
  const [screen, setScreen] = useState<Screen>("time")

  return (
    <main className="flex min-h-screen flex-col items-center gap-6 bg-muted px-4 py-8">
      <header className="flex flex-col items-center gap-1 text-center">
        <h1 className="font-heading text-2xl font-extrabold text-foreground">
          Math Hero Kids
        </h1>
        <p className="text-sm font-semibold text-muted-foreground">
          Estados de falha do Desafio
        </p>
      </header>

      <div className="sticky top-4 z-10 flex flex-wrap items-center justify-center gap-2 rounded-full bg-card p-1.5 shadow-md">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setScreen(tab.id)}
            className={`rounded-full px-4 py-2 font-heading text-sm font-bold transition-all outline-none focus-visible:ring-4 focus-visible:ring-ring/40 ${
              screen === tab.id
                ? "bg-primary text-primary-foreground"
                : "text-muted-foreground hover:bg-muted"
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      <PhoneFrame>
        {screen === "time" && <TimeExpiredScreen />}
        {screen === "wrong" && <WrongAnswerScreen />}
        {screen === "block" && <BlockFailedScreen />}
      </PhoneFrame>
    </main>
  )
}
