export type Profile = {
  id: string
  name: string
  avatar: string
  level: number
  xp: number
  xpForNext: number
}

export const profiles: Profile[] = [
  { id: "sofia", name: "Sofia", avatar: "/avatars/sofia.png", level: 12, xp: 1450, xpForNext: 2000 },
  { id: "lucas", name: "Lucas", avatar: "/avatars/lucas.png", level: 15, xp: 820, xpForNext: 2400 },
  { id: "pedro", name: "Pedro", avatar: "/avatars/pedro.png", level: 9, xp: 540, xpForNext: 1600 },
]

export type ChallengeStatus = "not-started" | "in-progress" | "completed"

export const todaysChallenge = {
  title: "Today's Challenge",
  subtitle: "Multiplication Mountain",
  status: "in-progress" as ChallengeStatus,
  questionsDone: 4,
  questionsTotal: 10,
  rewardXp: 150,
}

export const streak = {
  current: 8,
  best: 21,
}

export type TrophyTier = "daily" | "weekly" | "monthly"

export const trophies: {
  tier: TrophyTier
  label: string
  earned: boolean
  accent: string
}[] = [
  { tier: "daily", label: "Daily Trophy", earned: true, accent: "gold" },
  { tier: "weekly", label: "Weekly Trophy", earned: false, accent: "silver" },
  { tier: "monthly", label: "Monthly Trophy", earned: false, accent: "diamond" },
]

export const friends = {
  total: 12,
  requests: 3,
  top: [
    { name: "Lucas", avatar: "/avatars/lucas.png", level: 15, xp: 9820 },
    { name: "Mia", avatar: "/avatars/mia.png", level: 13, xp: 8740 },
    { name: "Noah", avatar: "/avatars/noah.png", level: 11, xp: 6210 },
  ],
}

export const leaderboard = [
  { rank: 1, name: "Lucas", avatar: "/avatars/lucas.png", xp: 9820 },
  { rank: 2, name: "Sofia", avatar: "/avatars/sofia.png", xp: 9310 },
  { rank: 3, name: "Pedro", avatar: "/avatars/pedro.png", xp: 7650 },
]

export const stats = [
  { label: "Perfect Days", value: 18, accent: "primary" },
  { label: "Perfect Weeks", value: 3, accent: "secondary" },
  { label: "Perfect Months", value: 1, accent: "success" },
  { label: "Challenges Done", value: 142, accent: "warning" },
]

export const miloMessages = [
  "Great job today!",
  "Ready for today's challenge?",
  "Only one more day for a weekly trophy!",
  "Your friend Lucas is ahead of you!",
]
