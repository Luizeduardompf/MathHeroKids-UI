import { Flame, Trophy } from "lucide-react"

export function StreakRow({ current, best }: { current: number; best: number }) {
  return (
    <div className="grid grid-cols-2 gap-3">
      <div className="flex items-center gap-3 rounded-3xl bg-gradient-to-br from-secondary-400 to-secondary-600 p-3 shadow-md">
        <span className="grid h-11 w-11 place-items-center rounded-2xl bg-white/25">
          <Flame className="h-6 w-6 text-white" fill="currentColor" />
        </span>
        <span className="text-secondary-foreground">
          <span className="block text-2xl font-black leading-none">{current}</span>
          <span className="text-xs font-bold opacity-90">Day Streak</span>
        </span>
      </div>
      <div className="flex items-center gap-3 rounded-3xl bg-card p-3 shadow-sm ring-1 ring-border">
        <span className="grid h-11 w-11 place-items-center rounded-2xl bg-gold-100">
          <Trophy className="h-6 w-6 text-gold-600" fill="currentColor" />
        </span>
        <span className="text-foreground">
          <span className="block text-2xl font-black leading-none">{best}</span>
          <span className="text-xs font-bold text-muted-foreground">Best Streak</span>
        </span>
      </div>
    </div>
  )
}
