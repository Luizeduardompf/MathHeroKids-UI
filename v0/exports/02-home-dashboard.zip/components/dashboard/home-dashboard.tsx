"use client"

import { useState } from "react"
import {
  profiles,
  todaysChallenge,
  streak,
  trophies,
  miloMessages,
  type Profile,
} from "@/lib/dashboard-data"
import { ProfileHeader } from "@/components/dashboard/profile-header"
import { MiloBanner } from "@/components/dashboard/milo-banner"
import { StreakRow } from "@/components/dashboard/streak-row"
import { ChallengeCard } from "@/components/dashboard/challenge-card"
import { TrophyShelf } from "@/components/dashboard/trophy-shelf"
import { FriendsCard } from "@/components/dashboard/friends-card"
import { RankingCard } from "@/components/dashboard/ranking-card"
import { StatsGrid } from "@/components/dashboard/stats-grid"
import { BottomNav } from "@/components/dashboard/bottom-nav"

function SectionTitle({ title, action }: { title: string; action?: string }) {
  return (
    <div className="mb-2 flex items-center justify-between px-1">
      <h3 className="text-lg font-black text-foreground">{title}</h3>
      {action && <button className="text-xs font-extrabold text-primary-600">{action}</button>}
    </div>
  )
}

export function HomeDashboard() {
  const [active, setActive] = useState<Profile>(profiles[0])

  return (
    <div className="mx-auto flex min-h-dvh w-full max-w-md flex-col bg-background">
      <header className="sticky top-0 z-20 bg-background/90 px-4 pb-3 pt-5 backdrop-blur">
        <ProfileHeader profiles={profiles} active={active} onSelect={setActive} />
      </header>

      <main className="flex flex-1 flex-col gap-5 px-4 pb-6">
        <MiloBanner messages={miloMessages} />

        <StreakRow current={streak.current} best={streak.best} />

        <section>
          <ChallengeCard {...todaysChallenge} />
        </section>

        <section>
          <SectionTitle title="Recent Trophies" action="See all" />
          <TrophyShelf trophies={trophies} />
        </section>

        <section>
          <SectionTitle title="Friends" />
          <FriendsCard />
        </section>

        <section>
          <RankingCard />
        </section>

        <section>
          <SectionTitle title="Your Statistics" />
          <StatsGrid />
        </section>
      </main>

      <BottomNav />
    </div>
  )
}
