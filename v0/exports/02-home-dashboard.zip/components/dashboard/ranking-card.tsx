import Image from "next/image"
import { Crown, ChevronRight } from "lucide-react"
import { leaderboard } from "@/lib/dashboard-data"

const medal: Record<number, string> = {
  1: "bg-gold-400 text-gold-600 ring-gold-300",
  2: "bg-slate-200 text-slate-500 ring-slate-300",
  3: "bg-orange-200 text-orange-700 ring-orange-300",
}

export function RankingCard() {
  return (
    <div className="rounded-3xl bg-card p-4 shadow-sm ring-1 ring-border">
      <div className="mb-3 flex items-center gap-2">
        <span className="grid h-9 w-9 place-items-center rounded-xl bg-gold-100">
          <Crown className="h-5 w-5 text-gold-600" fill="currentColor" />
        </span>
        <p className="text-base font-black text-foreground">Ranking</p>
      </div>

      <ul className="flex flex-col gap-2">
        {leaderboard.map((p) => (
          <li key={p.rank} className="flex items-center gap-3 rounded-2xl bg-muted/60 p-2">
            <span
              className={`grid h-8 w-8 place-items-center rounded-full text-sm font-black ring-2 ${medal[p.rank]}`}
            >
              {p.rank}
            </span>
            <span className="relative block h-9 w-9 overflow-hidden rounded-xl ring-2 ring-primary-100">
              <Image src={p.avatar || "/placeholder.svg"} alt={p.name} fill className="object-cover" />
            </span>
            <span className="flex-1 text-sm font-extrabold text-foreground">{p.name}</span>
            <span className="text-sm font-black text-primary-700">{p.xp.toLocaleString()}</span>
          </li>
        ))}
      </ul>

      <button className="mt-3 flex w-full items-center justify-center gap-1 rounded-2xl bg-primary py-3 text-sm font-extrabold text-primary-foreground transition active:scale-[0.97]">
        View Full Ranking
        <ChevronRight className="h-4 w-4" />
      </button>
    </div>
  )
}
