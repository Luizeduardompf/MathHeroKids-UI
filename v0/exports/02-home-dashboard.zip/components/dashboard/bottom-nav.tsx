"use client"

import { Home, Calendar, Swords, Users, Settings } from "lucide-react"
import { useState } from "react"

const tabs = [
  { id: "home", label: "Home", icon: Home },
  { id: "calendar", label: "Calendar", icon: Calendar },
  { id: "challenge", label: "Challenge", icon: Swords, primary: true },
  { id: "friends", label: "Friends", icon: Users },
  { id: "settings", label: "Settings", icon: Settings },
]

export function BottomNav() {
  const [active, setActive] = useState("home")

  return (
    <nav className="sticky bottom-0 z-30 border-t border-border bg-card/95 backdrop-blur">
      <ul className="mx-auto flex max-w-md items-end justify-between px-4 pb-2 pt-2">
        {tabs.map((t) => {
          const Icon = t.icon
          const isActive = active === t.id

          if (t.primary) {
            return (
              <li key={t.id} className="-mt-6">
                <button
                  onClick={() => setActive(t.id)}
                  className="flex flex-col items-center gap-1"
                  aria-label={t.label}
                >
                  <span className="grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-secondary-400 to-secondary-600 text-secondary-foreground shadow-lg ring-4 ring-card transition active:scale-95">
                    <Icon className="h-7 w-7" />
                  </span>
                  <span className="text-[10px] font-extrabold text-secondary-700">{t.label}</span>
                </button>
              </li>
            )
          }

          return (
            <li key={t.id}>
              <button
                onClick={() => setActive(t.id)}
                className="flex flex-col items-center gap-1 px-2 py-1"
                aria-label={t.label}
              >
                <Icon
                  className={`h-6 w-6 transition ${isActive ? "text-primary-600" : "text-muted-foreground"}`}
                />
                <span
                  className={`text-[10px] font-bold transition ${
                    isActive ? "text-primary-700" : "text-muted-foreground"
                  }`}
                >
                  {t.label}
                </span>
              </button>
            </li>
          )
        })}
      </ul>
    </nav>
  )
}
