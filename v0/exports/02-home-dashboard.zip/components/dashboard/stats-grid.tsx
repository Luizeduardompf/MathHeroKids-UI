import { CalendarCheck, CalendarRange, CalendarDays, Target } from "lucide-react"
import { stats } from "@/lib/dashboard-data"

const accentMap: Record<string, { bg: string; text: string; icon: typeof Target }> = {
  primary: { bg: "bg-primary-100", text: "text-primary-700", icon: CalendarCheck },
  secondary: { bg: "bg-secondary-100", text: "text-secondary-700", icon: CalendarRange },
  success: { bg: "bg-success-100", text: "text-success-700", icon: CalendarDays },
  warning: { bg: "bg-warning-100", text: "text-warning-700", icon: Target },
}

export function StatsGrid() {
  return (
    <div className="grid grid-cols-2 gap-3">
      {stats.map((s) => {
        const a = accentMap[s.accent]
        const Icon = a.icon
        return (
          <div key={s.label} className="rounded-3xl bg-card p-4 shadow-sm ring-1 ring-border">
            <span className={`grid h-10 w-10 place-items-center rounded-2xl ${a.bg}`}>
              <Icon className={`h-5 w-5 ${a.text}`} />
            </span>
            <p className="mt-2 text-3xl font-black leading-none text-foreground">{s.value}</p>
            <p className="mt-1 text-xs font-bold text-muted-foreground">{s.label}</p>
          </div>
        )
      })}
    </div>
  )
}
