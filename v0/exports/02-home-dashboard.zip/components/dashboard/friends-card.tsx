import Image from "next/image"
import { Users, UserPlus, ChevronRight } from "lucide-react"
import { friends } from "@/lib/dashboard-data"

export function FriendsCard() {
  return (
    <div className="rounded-3xl bg-card p-4 shadow-sm ring-1 ring-border">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-primary-100">
            <Users className="h-5 w-5 text-primary-600" />
          </span>
          <div>
            <p className="text-base font-black leading-none text-foreground">{friends.total} Friends</p>
            <p className="text-xs font-bold text-muted-foreground">Top players you follow</p>
          </div>
        </div>
        <button className="relative inline-flex items-center gap-1 rounded-full bg-secondary-100 px-3 py-1.5 text-xs font-extrabold text-secondary-700">
          <UserPlus className="h-3.5 w-3.5" />
          Requests
          <span className="grid h-5 min-w-5 place-items-center rounded-full bg-secondary px-1 text-[10px] font-black text-secondary-foreground">
            {friends.requests}
          </span>
        </button>
      </div>

      <ul className="mt-3 flex flex-col gap-2">
        {friends.top.map((f, idx) => (
          <li key={f.name} className="flex items-center gap-3 rounded-2xl bg-muted/60 p-2">
            <span className="text-sm font-black text-muted-foreground w-4 text-center">{idx + 1}</span>
            <span className="relative block h-9 w-9 overflow-hidden rounded-xl ring-2 ring-primary-100">
              <Image src={f.avatar || "/placeholder.svg"} alt={f.name} fill className="object-cover" />
            </span>
            <span className="flex-1">
              <span className="block text-sm font-extrabold text-foreground">{f.name}</span>
              <span className="block text-xs font-bold text-muted-foreground">Level {f.level}</span>
            </span>
            <span className="text-sm font-black text-primary-700">{f.xp.toLocaleString()} XP</span>
            <ChevronRight className="h-4 w-4 text-muted-foreground" />
          </li>
        ))}
      </ul>
    </div>
  )
}
