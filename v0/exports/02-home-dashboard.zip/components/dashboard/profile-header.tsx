"use client"

import Image from "next/image"
import { ChevronDown, Plus, Check } from "lucide-react"
import { useState } from "react"
import { type Profile } from "@/lib/dashboard-data"

export function ProfileHeader({
  profiles,
  active,
  onSelect,
}: {
  profiles: Profile[]
  active: Profile
  onSelect: (p: Profile) => void
}) {
  const [open, setOpen] = useState(false)
  const xpPct = Math.min(100, Math.round((active.xp / active.xpForNext) * 100))

  return (
    <div className="relative">
      <div className="flex items-center gap-3">
        <button
          onClick={() => setOpen((v) => !v)}
          className="flex items-center gap-3 rounded-3xl bg-card p-2 pr-3 shadow-sm ring-1 ring-border active:scale-[0.98] transition"
          aria-label="Switch profile"
        >
          <span className="relative block h-12 w-12 overflow-hidden rounded-2xl ring-2 ring-primary-200">
            <Image src={active.avatar || "/placeholder.svg"} alt={active.name} fill className="object-cover" />
          </span>
          <span className="text-left">
            <span className="flex items-center gap-1 text-base font-extrabold leading-tight text-foreground">
              {active.name}
              <ChevronDown className={`h-4 w-4 text-muted-foreground transition ${open ? "rotate-180" : ""}`} />
            </span>
            <span className="text-xs font-semibold text-muted-foreground">Level {active.level}</span>
          </span>
        </button>

        <div className="flex-1">
          <div className="mb-1 flex items-center justify-between text-xs font-bold">
            <span className="text-primary-700">{active.xp.toLocaleString()} XP</span>
            <span className="text-muted-foreground">{active.xpForNext.toLocaleString()}</span>
          </div>
          <div className="h-3 w-full overflow-hidden rounded-full bg-primary-100">
            <div
              className="h-full rounded-full bg-gradient-to-r from-primary-400 to-primary-600"
              style={{ width: `${xpPct}%` }}
            />
          </div>
        </div>
      </div>

      {open && (
        <>
          <button className="fixed inset-0 z-10 cursor-default" aria-hidden onClick={() => setOpen(false)} />
          <div className="absolute left-0 top-[58px] z-20 w-60 rounded-3xl bg-card p-2 shadow-xl ring-1 ring-border">
            {profiles.map((p) => {
              const selected = p.id === active.id
              return (
                <button
                  key={p.id}
                  onClick={() => {
                    onSelect(p)
                    setOpen(false)
                  }}
                  className={`flex w-full items-center gap-3 rounded-2xl p-2 text-left transition active:scale-[0.98] ${
                    selected ? "bg-primary-50" : "hover:bg-muted"
                  }`}
                >
                  <span className="relative block h-10 w-10 overflow-hidden rounded-xl ring-2 ring-primary-100">
                    <Image src={p.avatar || "/placeholder.svg"} alt={p.name} fill className="object-cover" />
                  </span>
                  <span className="flex-1">
                    <span className="block text-sm font-bold text-foreground">{p.name}</span>
                    <span className="block text-xs font-semibold text-muted-foreground">Level {p.level}</span>
                  </span>
                  {selected && (
                    <span className="grid h-6 w-6 place-items-center rounded-full bg-primary text-primary-foreground">
                      <Check className="h-4 w-4" />
                    </span>
                  )}
                </button>
              )
            })}
            <button className="mt-1 flex w-full items-center gap-3 rounded-2xl border-2 border-dashed border-primary-200 p-2 text-primary-700 transition hover:bg-primary-50 active:scale-[0.98]">
              <span className="grid h-10 w-10 place-items-center rounded-xl bg-primary-100">
                <Plus className="h-5 w-5" />
              </span>
              <span className="text-sm font-extrabold">Add Child</span>
            </button>
          </div>
        </>
      )}
    </div>
  )
}
