"use client"

import Image from "next/image"
import { useEffect, useState } from "react"

export function MiloBanner({ messages }: { messages: string[] }) {
  const [i, setI] = useState(0)

  useEffect(() => {
    const t = setInterval(() => setI((v) => (v + 1) % messages.length), 4000)
    return () => clearInterval(t)
  }, [messages.length])

  return (
    <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-primary-500 to-primary-700 p-4 shadow-lg">
      <div className="pointer-events-none absolute -right-6 -top-6 h-24 w-24 rounded-full bg-primary-400/40" />
      <div className="pointer-events-none absolute -bottom-8 right-12 h-16 w-16 rounded-full bg-primary-300/30" />
      <div className="relative flex items-center gap-3">
        <div className="relative h-20 w-20 shrink-0 overflow-hidden rounded-full bg-white shadow-md ring-4 ring-primary-300/50">
          <Image
            src="/milo/milo-encouraging.png"
            alt="Milo the mascot"
            fill
            className="animate-float object-contain"
          />
        </div>
        <div className="flex-1">
          <p className="text-[11px] font-bold uppercase tracking-wide text-primary-100">Milo says</p>
          <div className="relative mt-1 rounded-2xl rounded-bl-sm bg-card p-3 shadow-md">
            <p key={i} className="animate-pop text-sm font-extrabold leading-snug text-foreground text-balance">
              {messages[i]}
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
