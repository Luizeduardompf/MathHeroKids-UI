import { Play, Sparkles } from "lucide-react"
import { type ChallengeStatus } from "@/lib/dashboard-data"

const statusMap: Record<ChallengeStatus, { label: string; cta: string }> = {
  "not-started": { label: "Not Started", cta: "Start Challenge" },
  "in-progress": { label: "In Progress", cta: "Continue Challenge" },
  completed: { label: "Completed", cta: "Play Again" },
}

export function ChallengeCard({
  title,
  subtitle,
  status,
  questionsDone,
  questionsTotal,
  rewardXp,
}: {
  title: string
  subtitle: string
  status: ChallengeStatus
  questionsDone: number
  questionsTotal: number
  rewardXp: number
}) {
  const s = statusMap[status]
  const pct = Math.round((questionsDone / questionsTotal) * 100)

  return (
    <div className="relative overflow-hidden rounded-[2rem] bg-gradient-to-br from-success-500 to-success-700 p-5 shadow-xl">
      <div className="pointer-events-none absolute -right-8 -top-8 h-32 w-32 rounded-full bg-white/10" />
      <div className="pointer-events-none absolute -bottom-10 -left-6 h-28 w-28 rounded-full bg-white/10" />

      <div className="relative">
        <div className="flex items-center justify-between">
          <span className="inline-flex items-center gap-1 rounded-full bg-white/25 px-3 py-1 text-xs font-extrabold uppercase tracking-wide text-white">
            <Sparkles className="h-3.5 w-3.5" />
            {s.label}
          </span>
          <span className="inline-flex items-center gap-1 rounded-full bg-gold-400 px-3 py-1 text-xs font-black text-gold-600 ring-2 ring-white/40">
            +{rewardXp} XP
          </span>
        </div>

        <p className="mt-3 text-sm font-bold text-success-100">{title}</p>
        <h2 className="text-2xl font-black leading-tight text-white text-balance">{subtitle}</h2>

        {status === "in-progress" && (
          <div className="mt-3">
            <div className="mb-1 flex justify-between text-xs font-bold text-success-100">
              <span>
                {questionsDone} / {questionsTotal} questions
              </span>
              <span>{pct}%</span>
            </div>
            <div className="h-2.5 w-full overflow-hidden rounded-full bg-white/30">
              <div className="h-full rounded-full bg-white" style={{ width: `${pct}%` }} />
            </div>
          </div>
        )}

        <button className="mt-4 flex w-full items-center justify-center gap-2 rounded-2xl bg-white py-4 text-lg font-black text-success-700 shadow-md transition active:scale-[0.97]">
          <Play className="h-5 w-5" fill="currentColor" />
          {s.cta}
        </button>
      </div>
    </div>
  )
}
