import { Trophy, Lock } from "lucide-react"
import { type TrophyTier } from "@/lib/dashboard-data"

const accentMap: Record<string, { ring: string; bg: string; icon: string }> = {
  gold: { ring: "ring-gold-400", bg: "bg-gold-100", icon: "text-gold-600" },
  silver: { ring: "ring-slate-300", bg: "bg-slate-100", icon: "text-slate-400" },
  diamond: { ring: "ring-diamond", bg: "bg-cyan-50", icon: "text-teal-500" },
}

export function TrophyShelf({
  trophies,
}: {
  trophies: { tier: TrophyTier; label: string; earned: boolean; accent: string }[]
}) {
  return (
    <div className="grid grid-cols-3 gap-3">
      {trophies.map((t) => {
        const a = accentMap[t.accent]
        return (
          <div
            key={t.tier}
            className={`flex flex-col items-center rounded-3xl bg-card p-3 text-center shadow-sm ring-1 ${
              t.earned ? a.ring : "ring-border"
            }`}
          >
            <span
              className={`grid h-14 w-14 place-items-center rounded-2xl ${t.earned ? a.bg : "bg-muted"}`}
            >
              {t.earned ? (
                <Trophy className={`h-7 w-7 ${a.icon}`} fill="currentColor" />
              ) : (
                <Lock className="h-6 w-6 text-muted-foreground" />
              )}
            </span>
            <span className="mt-2 text-[11px] font-extrabold leading-tight text-foreground">{t.label}</span>
            <span className="text-[10px] font-bold text-muted-foreground">{t.earned ? "Earned" : "Locked"}</span>
          </div>
        )
      })}
    </div>
  )
}
